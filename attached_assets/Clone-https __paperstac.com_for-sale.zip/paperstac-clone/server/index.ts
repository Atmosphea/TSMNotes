import express from 'express';
import cors from 'cors';
import path from 'path';
import cookieParser from 'cookie-parser';
import { testConnection } from './db';
import notesRoutes from './routes/notes';
import authRoutes from './routes/auth';
import usersRoutes from './routes/users';
import inquiriesRouter from './routes/inquiries'; // Added inquiries router
import config from './config';

// Create Express app
const app = express();
const PORT = config.server.port;

// Middleware
app.use(cors({
  origin: config.server.frontendUrl,
  credentials: true,
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

// Static files
app.use('/uploads', express.static(path.join(process.cwd(), 'uploads')));

// Test database connection
testConnection();

// Routes
app.use('/api/auth', authRoutes); // Updated to use authRoutes
app.use('/api/users', usersRoutes); // Updated to use usersRoutes
app.use('/api/notes', notesRoutes); // Updated to use notesRoutes
app.use('/api/inquiries', inquiriesRouter); // Added inquiries route

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({ status: 'ok' });
});

// API documentation route
app.get('/api', (req, res) => {
  res.json({
    message: 'Paperstac API',
    version: '1.0.0',
    endpoints: {
      '/api/auth': 'Authentication endpoints (register, login, etc.)',
      '/api/users': 'User profile management',
      '/api/notes': 'Mortgage note listings',
      '/api/inquiries': 'Inquiries management', // Added inquiries endpoint
    },
  });
});

// Error handling middleware
app.use((err: Error, req: express.Request, res: express.Response, next: express.NextFunction) => {
  console.error(err.stack);

  // Check if error has a status code
  const statusCode = (err as any).statusCode || 500;

  res.status(statusCode).json({
    error: {
      message: err.message || 'Something went wrong!',
      status: statusCode,
    }
  });
});

// Start server
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
  console.log(`API URL: ${config.server.apiUrl}`);
  console.log(`Frontend URL: ${config.server.frontendUrl}`);
  console.log(`Environment: ${config.isDevelopment ? 'Development' : 'Production'}`);
});

export default app;
