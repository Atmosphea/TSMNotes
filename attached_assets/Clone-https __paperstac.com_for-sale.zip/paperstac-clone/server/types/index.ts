// Availability types
export type Availability = 'available' | 'on_hold' | 'pending_sale' | 'sold';

// Listing types
export type ListingType = 'single_asset' | 'asset_pool';

// Lien position types
export type LienPosition = '1st' | '2nd';

// Performance types
export type Performance = 'performing' | 'non_performing';

// Property types
export type PropertyType = 'commercial' | 'condominium' | 'land' | 'multi_family' | 'single_family' | 'other';

// Note types
export type NoteType = 'deed_of_trust' | 'mortgage' | 'contract_for_deed' | 'community_lands' | 'texas_secured_notes' | 'other';

// State types
export type StateType = 'judicial' | 'non_judicial';

// Notification frequency
export type NotificationFrequency = 'instant' | 'daily' | 'weekly';

// User role type
export type UserRole = 'investor' | 'seller' | 'buyer' | 'admin';

// User status type
export type UserStatus = 'active' | 'inactive' | 'pending' | 'banned';

// User type
export interface User {
  id: number;
  email: string;
  firstName: string;
  lastName: string;
  companyName?: string;
  phoneNumber?: string;
  profileImageUrl?: string;
  bio?: string;
  address?: string;
  city?: string;
  state?: string;
  zipCode?: string;
  role: UserRole;
  status: UserStatus;
  lastLogin?: Date;
  isEmailVerified: boolean;
  createdAt: Date;
  updatedAt: Date;
}

// Note listing type
export interface Note {
  id: number;
  sellerId?: number;
  title: string;
  description: string;
  price: number;
  isBestOffer: boolean;
  isFirmPrice: boolean;
  noteType: NoteType;
  lienPosition: LienPosition;
  performance: Performance;
  listingType: ListingType;
  availability: Availability;

  // Financial metrics
  yield?: number;
  itb?: number;
  itv?: number;
  ltv?: number;

  // Property details
  propertyType: PropertyType;
  propertyAddress?: string;
  propertyCity?: string;
  propertyState?: string;
  propertyZip?: string;
  propertySquareFeet?: number;
  propertyBedrooms?: number;
  propertyBathrooms?: number;
  propertyAcres?: number;
  propertyValue?: number;

  // Foreclosure status
  hasForeclosure: boolean;
  stateType?: StateType;

  // Images
  mainImageUrl?: string;

  createdAt: Date;
  updatedAt: Date;
}

// Note image type
export interface NoteImage {
  id: number;
  noteId: number;
  imageUrl: string;
  displayOrder: number;
  createdAt: Date;
}

// Query parameters for filtering notes
export interface NoteFilterParams {
  availability?: Availability;
  listingType?: ListingType;
  lienPosition?: LienPosition;
  performance?: Performance;
  noteType?: NoteType;
  seller?: string;
  minPrice?: number;
  maxPrice?: number;
  propertyType?: PropertyType;
  minYield?: number;
  maxYield?: number;
  minLtv?: number;
  maxLtv?: number;
  hasForeclosure?: boolean;
  stateType?: StateType;
  page?: number;
  limit?: number;
  sortBy?: string;
  sortDirection?: 'asc' | 'desc';
}

// Saved search type
export interface SavedSearch {
  id: number;
  userId: number;
  name: string;

  // Sharing settings
  isPublic?: boolean;
  shareToken?: string;

  // Notification settings
  isEmailEnabled?: boolean;
  notificationFrequency?: NotificationFrequency;
  lastNotificationSentAt?: Date;

  // Search filters
  noteType?: NoteType;
  lienPosition?: LienPosition;
  performance?: Performance;
  listingType?: ListingType;

  minPrice?: number;
  maxPrice?: number;

  minYield?: number;
  maxYield?: number;

  minLtv?: number;
  maxLtv?: number;

  minInterestRate?: number;
  maxInterestRate?: number;

  propertyType?: PropertyType;
  stateType?: StateType;

  hasForeclosure?: boolean;

  // Legacy notification field
  isNotificationEnabled?: boolean;

  createdAt: Date;
  updatedAt: Date;
}

// Shared search view analytics
export interface SharedSearchView {
  id: number;
  searchId: number;
  viewerIp?: string;
  userAgent?: string;
  referrer?: string;
  viewedAt: Date;
}

// Document template type
export interface DocumentTemplate {
  id: number;
  name: string;
  description?: string;
  documentUrl: string;
  isDefault: boolean;
  createdAt: Date;
  updatedAt: Date;
}

// Note Transaction History type
export interface NoteTransactionHistory {
  id: number;
  noteId: number;
  status: Availability;
  buyerId?: number;
  reason?: string;
  expiresAt?: Date;
  createdAt: Date;
  createdBy: number;
}

// Update parameters to place a note on hold
export interface PlaceNoteOnHoldParams {
  noteId: number;
  buyerId: number;
  reason?: string;
  durationHours?: number; // Default to 48 hours if not specified
}

// Update parameters to complete a transaction
export interface CompleteTransactionParams {
  noteId: number;
  buyerId: number;
  sellerId: number;
  soldPrice?: number; // If different from the listing price
}

// Saved search analytics action types
export type SavedSearchAction = 'view' | 'execute' | 'create_alert' | 'modify' | 'share' | 'export';

// Saved search analytics type
export interface SavedSearchAnalytics {
  id: number;
  searchId: number;
  userId: number;
  action: SavedSearchAction;
  countMatches?: number;
  executionTimeMs?: number;
  ipAddress?: string;
  userAgent?: string;
  createdAt: Date;
}

// Saved search analytics summary
export interface SavedSearchAnalyticsSummary {
  searchId: number;
  totalUsage: number;
  usageByAction: Record<SavedSearchAction, number>;
  matchRates: {
    avgMatches: number;
    maxMatches: number;
    totalMatches: number;
  };
  usageByDate: Record<string, number>;
  lastUsed: Date;
}

// Saved search analytics query parameters
export interface SavedSearchAnalyticsParams {
  searchId?: number;
  userId?: number;
  action?: SavedSearchAction;
  startDate?: Date;
  endDate?: Date;
  limit?: number;
  page?: number;
}
