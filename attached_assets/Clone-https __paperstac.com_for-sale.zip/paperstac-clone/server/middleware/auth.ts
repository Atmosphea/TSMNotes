import { Request, Response, NextFunction } from 'express';
import { verifyJwtToken } from '../utils/auth';
import { db } from '../db';
import { users } from '../db/schema';
import { eq } from 'drizzle-orm';

// Extend Express Request type
declare global {
  namespace Express {
    interface Request {
      user?: {
        id: number;
        email: string;
        role: string;
      };
    }
  }
}

// Middleware to check if user is authenticated
export const isAuthenticated = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  // Get token from Authorization header
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ message: 'Authentication required. No valid token provided.' });
  }

  const token = authHeader.split(' ')[1];
  if (!token) {
    return res.status(401).json({ message: 'Authentication required. No valid token provided.' });
  }

  // Verify token
  const payload = verifyJwtToken(token);
  if (!payload) {
    return res.status(401).json({ message: 'Authentication failed. Token is invalid or expired.' });
  }

  // Check if user exists
  const [user] = await db
    .select({
      id: users.id,
      email: users.email,
      role: users.role,
      status: users.status,
    })
    .from(users)
    .where(eq(users.id, payload.userId))
    .execute();

  if (!user) {
    return res.status(401).json({ message: 'Authentication failed. User not found.' });
  }

  // Check if user is active
  if (user.status !== 'active') {
    return res.status(403).json({
      message: 'Account is not active. Please verify your email or contact support.'
    });
  }

  // Set user info in request object
  req.user = {
    id: user.id,
    email: user.email,
    role: user.role,
  };

  next();
};

// Middleware to check if user has required role
export const hasRole = (roles: string | string[]) => {
  const allowedRoles = Array.isArray(roles) ? roles : [roles];

  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.user) {
      return res.status(401).json({ message: 'Authentication required.' });
    }

    if (!allowedRoles.includes(req.user.role)) {
      return res.status(403).json({
        message: 'Access denied. You do not have permission to access this resource.'
      });
    }

    next();
  };
};

// Middleware to check if user is the owner of a resource
export const isResourceOwner = (
  resourceId: string,
  resourceType: string = 'user'
) => {
  return async (req: Request, res: Response, next: NextFunction) => {
    if (!req.user) {
      return res.status(401).json({ message: 'Authentication required.' });
    }

    const id = req.params[resourceId];
    if (!id) {
      return res.status(400).json({ message: 'Resource ID is required.' });
    }

    // Admin can access any resource
    if (req.user.role === 'admin') {
      return next();
    }

    // For user resources, check if user is accessing their own resource
    if (resourceType === 'user' && parseInt(id) === req.user.id) {
      return next();
    }

    // For other resources, query the database to check ownership
    // We'll implement specific checks for different resource types as needed

    return res.status(403).json({
      message: 'Access denied. You do not have permission to access this resource.'
    });
  };
};

// Log user activity
export const logActivity = (activityType: string) => {
  return async (req: Request, res: Response, next: NextFunction) => {
    // Store original end method
    const originalEnd = res.end;

    // Override end method
    res.end = function(chunk?: any, encoding?: any) {
      // Restore original end method
      res.end = originalEnd;

      // Log activity only if operation was successful
      if (res.statusCode >= 200 && res.statusCode < 300 && req.user) {
        // We'll implement activity logging in a separate module
        // For now, just log to console
        console.log(`User ${req.user.id} performed ${activityType}`);
      }

      // Call original end method
      return res.end(chunk, encoding);
    };

    next();
  };
};
