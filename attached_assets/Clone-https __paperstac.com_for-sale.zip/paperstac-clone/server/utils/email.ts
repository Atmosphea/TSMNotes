import nodemailer from 'nodemailer';
import config from '../config';

// Create a transporter object
let transporter: nodemailer.Transporter;

// Initialize email transport
const initializeTransport = () => {
  // If SMTP configuration is available, use it
  if (config.email.host && config.email.port && config.email.user && config.email.pass) {
    transporter = nodemailer.createTransport({
      host: config.email.host,
      port: config.email.port,
      secure: config.email.port === 465, // true for 465, false for other ports
      auth: {
        user: config.email.user,
        pass: config.email.pass,
      },
    });
  } else {
    // For development, use a test account
    if (config.isDevelopment) {
      console.log('No SMTP configuration found. Using nodemailer testing account.');

      // Create a test account on ethereal.email
      nodemailer.createTestAccount().then((testAccount) => {
        transporter = nodemailer.createTransport({
          host: 'smtp.ethereal.email',
          port: 587,
          secure: false,
          auth: {
            user: testAccount.user,
            pass: testAccount.pass,
          },
        });
      });
    } else {
      console.error('No SMTP configuration found for production environment.');
    }
  }
};

// Initialize transport when module is loaded
initializeTransport();

// Email templates
const emailTemplates = {
  verification: (firstName: string, verificationUrl: string) => ({
    subject: 'Verify Your Email Address - Paperstac',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2>Welcome to Paperstac!</h2>
        <p>Hi ${firstName},</p>
        <p>Thank you for registering with Paperstac. To complete your registration and access all features, please verify your email address by clicking the button below:</p>
        <div style="text-align: center; margin: 30px 0;">
          <a href="${verificationUrl}" style="background-color: #3182ce; color: white; padding: 10px 20px; text-decoration: none; border-radius: 4px; font-weight: bold;">Verify Email</a>
        </div>
        <p>If the button doesn't work, you can also copy and paste the following link into your browser:</p>
        <p>${verificationUrl}</p>
        <p>This verification link will expire in 24 hours.</p>
        <p>If you didn't create an account on Paperstac, please ignore this email.</p>
        <p>Thanks,<br>The Paperstac Team</p>
      </div>
    `,
  }),

  passwordReset: (firstName: string, resetUrl: string) => ({
    subject: 'Reset Your Password - Paperstac',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2>Password Reset</h2>
        <p>Hi ${firstName},</p>
        <p>We received a request to reset your password for your Paperstac account. To proceed with the password reset, please click the button below:</p>
        <div style="text-align: center; margin: 30px 0;">
          <a href="${resetUrl}" style="background-color: #3182ce; color: white; padding: 10px 20px; text-decoration: none; border-radius: 4px; font-weight: bold;">Reset Password</a>
        </div>
        <p>If the button doesn't work, you can also copy and paste the following link into your browser:</p>
        <p>${resetUrl}</p>
        <p>This password reset link will expire in 1 hour.</p>
        <p>If you didn't request a password reset, please ignore this email or contact support if you have concerns.</p>
        <p>Thanks,<br>The Paperstac Team</p>
      </div>
    `,
  }),

  welcome: (firstName: string, loginUrl: string) => ({
    subject: 'Welcome to Paperstac!',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2>Welcome to Paperstac!</h2>
        <p>Hi ${firstName},</p>
        <p>Your email has been verified, and your account is now active. Thank you for joining Paperstac - the trusted platform for buying and selling mortgage notes.</p>
        <p>You can now:</p>
        <ul>
          <li>Browse mortgage notes for sale</li>
          <li>Save your search preferences</li>
          <li>Contact sellers and make offers</li>
          <li>List your own notes for sale</li>
        </ul>
        <div style="text-align: center; margin: 30px 0;">
          <a href="${loginUrl}" style="background-color: #3182ce; color: white; padding: 10px 20px; text-decoration: none; border-radius: 4px; font-weight: bold;">Login to Your Account</a>
        </div>
        <p>If you have any questions or need assistance, please don't hesitate to contact our support team.</p>
        <p>Thanks,<br>The Paperstac Team</p>
      </div>
    `,
  }),

  newNoteNotification: (firstName: string, noteName: string, noteUrl: string) => ({
    subject: 'New Note Matching Your Criteria - Paperstac',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2>New Note Alert</h2>
        <p>Hi ${firstName},</p>
        <p>Good news! A new note has been listed that matches your saved search criteria:</p>
        <div style="background-color: #f7fafc; padding: 15px; border-radius: 5px; margin: 20px 0;">
          <h3 style="margin-top: 0;">${noteName}</h3>
        </div>
        <p>To view this note and get more details, click the button below:</p>
        <div style="text-align: center; margin: 30px 0;">
          <a href="${noteUrl}" style="background-color: #3182ce; color: white; padding: 10px 20px; text-decoration: none; border-radius: 4px; font-weight: bold;">View Note</a>
        </div>
        <p>If you no longer wish to receive these notifications, you can update your preferences in your account settings.</p>
        <p>Thanks,<br>The Paperstac Team</p>
      </div>
    `,
  }),
};

// Email sending functions
export const sendEmail = async (
  to: string,
  subject: string,
  html: string
): Promise<boolean> => {
  try {
    if (!transporter) {
      console.error('Email transporter not initialized');
      return false;
    }

    const info = await transporter.sendMail({
      from: `"Paperstac" <${config.email.from}>`,
      to,
      subject,
      html,
    });

    // Log email link for development environment
    if (config.isDevelopment && info.messageId) {
      console.log('Email sent: %s', info.messageId);
      // For ethereal.email temporary accounts
      if (info.messageId.includes('ethereal.email')) {
        console.log('Preview URL: %s', nodemailer.getTestMessageUrl(info));
      }
    }

    return true;
  } catch (error) {
    console.error('Error sending email:', error);
    return false;
  }
};

export const sendVerificationEmail = async (
  email: string,
  firstName: string,
  token: string
): Promise<boolean> => {
  const verificationUrl = `${config.server.frontendUrl}/verify-email?token=${token}`;
  const { subject, html } = emailTemplates.verification(firstName, verificationUrl);
  return sendEmail(email, subject, html);
};

export const sendPasswordResetEmail = async (
  email: string,
  firstName: string,
  token: string
): Promise<boolean> => {
  const resetUrl = `${config.server.frontendUrl}/reset-password?token=${token}`;
  const { subject, html } = emailTemplates.passwordReset(firstName, resetUrl);
  return sendEmail(email, subject, html);
};

export const sendWelcomeEmail = async (
  email: string,
  firstName: string
): Promise<boolean> => {
  const loginUrl = `${config.server.frontendUrl}/login`;
  const { subject, html } = emailTemplates.welcome(firstName, loginUrl);
  return sendEmail(email, subject, html);
};

export const sendNewNoteNotification = async (
  email: string,
  firstName: string,
  noteName: string,
  noteId: number
): Promise<boolean> => {
  const noteUrl = `${config.server.frontendUrl}/note/${noteId}`;
  const { subject, html } = emailTemplates.newNoteNotification(firstName, noteName, noteUrl);
  return sendEmail(email, subject, html);
};

// Add SendGrid for saved search notifications
// IMPORTANT: This is a placeholder API key - replace with your actual SendGrid API key
const SENDGRID_API_KEY = 'SG.YOUR_SENDGRID_API_KEY'; // TODO: Replace with environment variable

// Function to check if a note matches saved search criteria
export const doesNoteMatchSavedSearch = (note: any, savedSearch: any): boolean => {
  // Check all filters that are set in the saved search
  if (savedSearch.noteType && note.noteType !== savedSearch.noteType) {
    return false;
  }

  if (savedSearch.lienPosition && note.lienPosition !== savedSearch.lienPosition) {
    return false;
  }

  if (savedSearch.performance && note.performance !== savedSearch.performance) {
    return false;
  }

  if (savedSearch.listingType && note.listingType !== savedSearch.listingType) {
    return false;
  }

  if (savedSearch.propertyType && note.propertyType !== savedSearch.propertyType) {
    return false;
  }

  if (savedSearch.stateType && note.stateType !== savedSearch.stateType) {
    return false;
  }

  if (savedSearch.hasForeclosure !== undefined && note.hasForeclosure !== savedSearch.hasForeclosure) {
    return false;
  }

  // Check numeric ranges
  if (savedSearch.minPrice !== null && savedSearch.minPrice !== undefined) {
    if (note.price < savedSearch.minPrice) {
      return false;
    }
  }

  if (savedSearch.maxPrice !== null && savedSearch.maxPrice !== undefined) {
    if (note.price > savedSearch.maxPrice) {
      return false;
    }
  }

  if (savedSearch.minYield !== null && savedSearch.minYield !== undefined && note.yield !== null) {
    if (note.yield < savedSearch.minYield) {
      return false;
    }
  }

  if (savedSearch.maxYield !== null && savedSearch.maxYield !== undefined && note.yield !== null) {
    if (note.yield > savedSearch.maxYield) {
      return false;
    }
  }

  if (savedSearch.minLtv !== null && savedSearch.minLtv !== undefined && note.ltv !== null) {
    if (note.ltv < savedSearch.minLtv) {
      return false;
    }
  }

  if (savedSearch.maxLtv !== null && savedSearch.maxLtv !== undefined && note.ltv !== null) {
    if (note.ltv > savedSearch.maxLtv) {
      return false;
    }
  }

  // If all checks pass, the note matches the saved search criteria
  return true;
};

// Function to create email content for saved search notifications
export const createSavedSearchEmailContent = (
  user: any,
  savedSearch: any,
  note: any,
  baseUrl: string
): { subject: string; html: string; text: string } => {
  const subject = `New Note Listing Matching Your Saved Search: ${savedSearch.name}`;

  // Format price and other values for display
  const formattedPrice = new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
  }).format(note.price);

  const noteUrl = `${baseUrl}/note/${note.id}`;
  const unsubscribeUrl = `${baseUrl}/account/notifications?searchId=${savedSearch.id}`;

  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <h2 style="color: #2c3e50;">New Note Listing Alert</h2>
      <p>Hello ${user.firstName},</p>
      <p>A new note has been listed that matches your saved search criteria "${savedSearch.name}":</p>

      <div style="background-color: #f8f9fa; border: 1px solid #dee2e6; border-radius: 5px; padding: 15px; margin: 20px 0;">
        <h3 style="margin-top: 0; color: #2c3e50;">${note.title}</h3>
        <p style="margin-bottom: 5px;"><strong>Price:</strong> ${formattedPrice}</p>
        <p style="margin-bottom: 5px;"><strong>Note Type:</strong> ${note.noteType.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}</p>
        <p style="margin-bottom: 5px;"><strong>Property Type:</strong> ${note.propertyType.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}</p>
        <p>${note.description.length > 150 ? note.description.substring(0, 150) + '...' : note.description}</p>
        <a href="${noteUrl}" style="display: inline-block; background-color: #3498db; color: white; padding: 10px 15px; text-decoration: none; border-radius: 5px; margin-top: 10px;">View Note</a>
      </div>

      <p>This email was sent based on your notification preferences. You can manage your notification settings in your account dashboard.</p>
      <p><small><a href="${unsubscribeUrl}">Unsubscribe from this search alert</a></small></p>
    </div>
  `;

  const text = `
    New Note Listing Alert

    Hello ${user.firstName},

    A new note has been listed that matches your saved search criteria "${savedSearch.name}":

    ${note.title}
    Price: ${formattedPrice}
    Note Type: ${note.noteType.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
    Property Type: ${note.propertyType.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}

    ${note.description.length > 150 ? note.description.substring(0, 150) + '...' : note.description}

    View Note: ${noteUrl}

    This email was sent based on your notification preferences. You can manage your notification settings in your account dashboard.

    Unsubscribe from this search alert: ${unsubscribeUrl}
  `;

  return { subject, html, text };
};

// Function to send email notifications for new listings that match saved searches
export const sendMatchingNoteNotifications = async (note: any, db: any, config: any): Promise<void> => {
  try {
    console.log(`Checking saved searches for matches with new note listing: ${note.id}`);

    // Get all active saved searches with email notifications enabled
    const activeSearches = await db
      .select({
        search: db.ref('savedSearches'),
        user: db.ref('users'),
      })
      .from('savedSearches')
      .leftJoin('users', 'savedSearches.userId', 'users.id')
      .where(({ or, and, eq }) =>
        and(
          eq('savedSearches.isEmailEnabled', true),
          eq('users.status', 'active'),
          eq('users.isEmailVerified', true)
        )
      )
      .execute();

    console.log(`Found ${activeSearches.length} active saved searches with email notifications enabled`);

    // For each saved search, check if the note matches
    const matchingSearches = activeSearches.filter(({ search }) =>
      doesNoteMatchSavedSearch(note, search)
    );

    console.log(`Found ${matchingSearches.length} saved searches matching this note`);

    // For each matching search, send an email notification
    for (const { search, user } of matchingSearches) {
      // Check if we should send a notification based on frequency
      // If instant, send immediately
      // If daily/weekly, we'll handle that in a separate scheduled job
      if (search.notificationFrequency !== 'instant') {
        console.log(`Skipping immediate notification for search ${search.id} (frequency: ${search.notificationFrequency})`);
        continue;
      }

      console.log(`Sending email notification to user ${user.id} for search ${search.id}`);

      try {
        // Create email content
        const { subject, html, text } = createSavedSearchEmailContent(
          user,
          search,
          note,
          config.baseUrl
        );

        // Send the email
        // TODO: Replace with actual SendGrid implementation
        console.log(`Would send email to ${user.email} with subject: ${subject}`);
        console.log('Email content (text version):', text);

        // Update the last notification sent timestamp
        await db
          .update('savedSearches')
          .set({ lastNotificationSentAt: new Date() })
          .where('id', '=', search.id)
          .execute();

        // Log the activity
        await db
          .insert('activityLogs')
          .values({
            userId: user.id,
            activityType: 'notification_sent',
            details: `Email notification sent for saved search "${search.name}" matching note "${note.title}" (ID: ${note.id})`,
          })
          .execute();
      } catch (emailError) {
        console.error(`Failed to send email notification for search ${search.id}:`, emailError);
      }
    }
  } catch (error) {
    console.error('Error sending saved search notifications:', error);
  }
};

// Function for sending daily/weekly digest emails (to be called by a scheduled job)
export const sendSavedSearchDigests = async (frequency: 'daily' | 'weekly', db: any, config: any): Promise<void> => {
  try {
    console.log(`Sending ${frequency} saved search digest emails`);

    // Determine the time threshold
    const now = new Date();
    let timeThreshold = new Date();

    if (frequency === 'daily') {
      timeThreshold.setDate(now.getDate() - 1); // 24 hours ago
    } else {
      timeThreshold.setDate(now.getDate() - 7); // 7 days ago
    }

    // Get all saved searches with the specified frequency
    const searches = await db
      .select({
        search: db.ref('savedSearches'),
        user: db.ref('users'),
      })
      .from('savedSearches')
      .leftJoin('users', 'savedSearches.userId', 'users.id')
      .where(({ and, eq, or, isNull, lt }) =>
        and(
          eq('savedSearches.isEmailEnabled', true),
          eq('savedSearches.notificationFrequency', frequency),
          eq('users.status', 'active'),
          eq('users.isEmailVerified', true),
          or(
            isNull('savedSearches.lastNotificationSentAt'),
            lt('savedSearches.lastNotificationSentAt', timeThreshold)
          )
        )
      )
      .execute();

    console.log(`Found ${searches.length} ${frequency} saved searches to process`);

    // For each search, find matching notes created since the last notification
    for (const { search, user } of searches) {
      const lastSent = search.lastNotificationSentAt || new Date(0);

      // Get notes created since the last notification that match this search
      const recentNotes = await db
        .select()
        .from('notes')
        .where('createdAt', '>', lastSent)
        .where('availability', '=', 'available')
        .execute();

      // Filter notes that match the search criteria
      const matchingNotes = recentNotes.filter(note =>
        doesNoteMatchSavedSearch(note, search)
      );

      if (matchingNotes.length === 0) {
        console.log(`No matching notes found for search ${search.id}`);
        continue;
      }

      console.log(`Found ${matchingNotes.length} matching notes for search ${search.id}`);

      // Create digest email with all matching notes
      // TODO: Implement digest email template
      console.log(`Would send digest email to ${user.email} with ${matchingNotes.length} notes`);

      // Update the last notification sent timestamp
      await db
        .update('savedSearches')
        .set({ lastNotificationSentAt: new Date() })
        .where('id', '=', search.id)
        .execute();

      // Log the activity
      await db
        .insert('activityLogs')
        .values({
          userId: user.id,
          activityType: 'notification_sent',
          details: `${frequency} digest email sent for saved search "${search.name}" with ${matchingNotes.length} matching notes`,
        })
        .execute();
    }
  } catch (error) {
    console.error(`Error sending ${frequency} digest emails:`, error);
  }
};

// Function to send buyer inquiry notification emails
export const sendBuyerInquiryNotification = async (inquiry: any, sellerId: number, db: any, config: any) => {
  try {
    // Get seller info
    const [seller] = await db
      .select({
        email: users.email,
        firstName: users.firstName,
        lastName: users.lastName,
      })
      .from(users)
      .where(eq(users.id, sellerId))
      .execute();

    if (!seller) {
      console.error(`Seller with ID ${sellerId} not found`);
      return;
    }

    // Get note info
    const [note] = await db
      .select({
        id: notes.id,
        title: notes.title,
      })
      .from(notes)
      .where(eq(notes.id, inquiry.noteId))
      .execute();

    if (!note) {
      console.error(`Note with ID ${inquiry.noteId} not found`);
      return;
    }

    // Get buyer info
    const [buyer] = await db
      .select({
        firstName: users.firstName,
        lastName: users.lastName,
        companyName: users.companyName,
      })
      .from(users)
      .where(eq(users.id, inquiry.buyerId))
      .execute();

    if (!buyer) {
      console.error(`Buyer with ID ${inquiry.buyerId} not found`);
      return;
    }

    // Check notification preferences
    const [notificationPref] = await db
      .select()
      .from(notificationPreferences)
      .where(
        and(
          eq(notificationPreferences.userId, sellerId),
          eq(notificationPreferences.notificationType, 'buyer_inquiry')
        )
      )
      .execute();

    // Default to email enabled if no preference exists
    const shouldSendEmail = !notificationPref || notificationPref.email;

    if (shouldSendEmail) {
      const buyerName = buyer.companyName
        ? `${buyer.firstName} ${buyer.lastName} (${buyer.companyName})`
        : `${buyer.firstName} ${buyer.lastName}`;

      const emailData = {
        subject: `New inquiry for your note: ${note.title}`,
        recipientEmail: seller.email,
        recipientName: `${seller.firstName} ${seller.lastName}`,
        templateData: {
          recipientName: seller.firstName,
          noteTitle: note.title,
          buyerName,
          inquirySubject: inquiry.subject,
          inquiryMessage: inquiry.message,
          inquiryLink: `${config.clientUrl}/dashboard/inquiries/${inquiry.id}`,
          phoneNumberRequested: inquiry.phoneNumberRequested ? 'Yes' : 'No',
          ctaText: 'View Inquiry',
          ctaLink: `${config.clientUrl}/dashboard/inquiries/${inquiry.id}`,
        },
      };

      await sendEmail('buyer-inquiry', emailData);

      // Create notification record
      await db.insert(notifications).values({
        userId: sellerId,
        type: 'buyer_inquiry',
        title: 'New buyer inquiry',
        message: `${buyerName} sent an inquiry about your note: ${note.title}`,
        isRead: false,
        relatedEntityType: 'inquiry',
        relatedEntityId: inquiry.id,
        data: {
          noteId: note.id,
          noteTitle: note.title,
          inquirySubject: inquiry.subject,
        },
      }).execute();
    }
  } catch (error) {
    console.error('Error sending buyer inquiry notification:', error);
  }
};
