import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import crypto from 'crypto';
import config from '../config';
import { db } from '../db';
import { authTokens, users } from '../db/schema';
import { and, eq } from 'drizzle-orm';

// Types
interface TokenPayload {
  userId: number;
  email: string;
  role: string;
}

interface JwtTokens {
  accessToken: string;
  refreshToken: string;
}

// Password utilities
export const hashPassword = async (password: string): Promise<string> => {
  const salt = await bcrypt.genSalt(12);
  return bcrypt.hash(password, salt);
};

export const comparePassword = async (password: string, hashedPassword: string): Promise<boolean> => {
  return bcrypt.compare(password, hashedPassword);
};

export const validatePasswordStrength = (password: string): { isValid: boolean; message: string } => {
  const { minLength, requireUppercase, requireLowercase, requireNumbers, requireSymbols } = config.passwordPolicy;

  if (password.length < minLength) {
    return {
      isValid: false,
      message: `Password must be at least ${minLength} characters long.`
    };
  }

  if (requireUppercase && !/[A-Z]/.test(password)) {
    return {
      isValid: false,
      message: 'Password must contain at least one uppercase letter.'
    };
  }

  if (requireLowercase && !/[a-z]/.test(password)) {
    return {
      isValid: false,
      message: 'Password must contain at least one lowercase letter.'
    };
  }

  if (requireNumbers && !/\d/.test(password)) {
    return {
      isValid: false,
      message: 'Password must contain at least one number.'
    };
  }

  if (requireSymbols && !/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(password)) {
    return {
      isValid: false,
      message: 'Password must contain at least one special character.'
    };
  }

  return { isValid: true, message: 'Password is valid.' };
};

// Token utilities
export const generateJwtTokens = async (payload: TokenPayload): Promise<JwtTokens> => {
  const accessToken = jwt.sign(payload, config.auth.jwtSecret, {
    expiresIn: config.auth.jwtExpiresIn,
  });

  const refreshToken = jwt.sign(payload, config.auth.jwtSecret, {
    expiresIn: config.auth.jwtRefreshExpiresIn,
  });

  // Save refresh token to database
  const expiresAt = new Date();
  expiresAt.setDate(expiresAt.getDate() + 7); // 7 days

  await db.insert(authTokens).values({
    userId: payload.userId,
    token: refreshToken,
    expiresAt,
  });

  return { accessToken, refreshToken };
};

export const verifyJwtToken = (token: string): TokenPayload | null => {
  try {
    return jwt.verify(token, config.auth.jwtSecret) as TokenPayload;
  } catch (error) {
    return null;
  }
};

export const refreshTokens = async (refreshToken: string): Promise<JwtTokens | null> => {
  // Verify the token is valid
  const payload = verifyJwtToken(refreshToken);
  if (!payload) {
    return null;
  }

  // Check if token exists in database and is not revoked
  const [tokenRecord] = await db
    .select()
    .from(authTokens)
    .where(and(eq(authTokens.token, refreshToken), eq(authTokens.isRevoked, false)))
    .execute();

  if (!tokenRecord) {
    return null;
  }

  // Check if token is expired
  if (new Date() > new Date(tokenRecord.expiresAt)) {
    // Revoke the expired token
    await db
      .update(authTokens)
      .set({ isRevoked: true })
      .where(eq(authTokens.id, tokenRecord.id))
      .execute();

    return null;
  }

  // Generate new tokens
  const [user] = await db
    .select()
    .from(users)
    .where(eq(users.id, payload.userId))
    .execute();

  if (!user) {
    return null;
  }

  // Revoke the used refresh token
  await db
    .update(authTokens)
    .set({ isRevoked: true })
    .where(eq(authTokens.id, tokenRecord.id))
    .execute();

  // Generate new tokens
  return generateJwtTokens({
    userId: user.id,
    email: user.email,
    role: user.role,
  });
};

export const revokeToken = async (token: string): Promise<boolean> => {
  const result = await db
    .update(authTokens)
    .set({ isRevoked: true })
    .where(eq(authTokens.token, token))
    .execute();

  return result.length > 0;
};

export const revokeAllUserTokens = async (userId: number): Promise<void> => {
  await db
    .update(authTokens)
    .set({ isRevoked: true })
    .where(eq(authTokens.userId, userId))
    .execute();
};

// Token generation for email verification and password reset
export const generateToken = (length = 32): string => {
  return crypto.randomBytes(length).toString('hex');
};

export const generateVerificationToken = async (userId: number): Promise<string> => {
  const token = generateToken();
  const expiryDate = new Date();
  expiryDate.setTime(expiryDate.getTime() + config.verificationTokenExpiry);

  await db
    .update(users)
    .set({
      verificationToken: token,
      verificationTokenExpiry: expiryDate,
    })
    .where(eq(users.id, userId))
    .execute();

  return token;
};

export const generatePasswordResetToken = async (userId: number): Promise<string> => {
  const token = generateToken();
  const expiryDate = new Date();
  expiryDate.setTime(expiryDate.getTime() + config.resetPasswordTokenExpiry);

  await db
    .update(users)
    .set({
      resetPasswordToken: token,
      resetPasswordTokenExpiry: expiryDate,
    })
    .where(eq(users.id, userId))
    .execute();

  return token;
};
