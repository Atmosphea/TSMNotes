import { S3 } from 'aws-sdk';
import multer from 'multer';
import multerS3 from 'multer-s3';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';
import config from '../config';

// Create S3 instance
const s3 = new S3({
  accessKeyId: config.aws.accessKeyId,
  secretAccessKey: config.aws.secretAccessKey,
  region: config.aws.region,
});

// Ensure upload directory exists for local storage
const uploadDir = path.join(process.cwd(), 'uploads');
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

// Create subdirectories for different types of uploads
const profileImagesDir = path.join(uploadDir, 'profile-images');
const documentsDir = path.join(uploadDir, 'documents');

if (!fs.existsSync(profileImagesDir)) {
  fs.mkdirSync(profileImagesDir, { recursive: true });
}

if (!fs.existsSync(documentsDir)) {
  fs.mkdirSync(documentsDir, { recursive: true });
}

// Generate unique filename
const generateUniqueFilename = (originalname: string): string => {
  const timestamp = Date.now();
  const randomString = crypto.randomBytes(8).toString('hex');
  const extension = path.extname(originalname);
  const sanitizedName = path.basename(originalname, extension)
    .replace(/[^a-zA-Z0-9]/g, '-')
    .toLowerCase();

  return `${sanitizedName}-${timestamp}-${randomString}${extension}`;
};

// Configure S3 storage if available
const getS3Storage = (folderName: string) => {
  if (!config.aws.s3Bucket || !config.aws.accessKeyId || !config.aws.secretAccessKey) {
    return null;
  }

  return multerS3({
    s3,
    bucket: config.aws.s3Bucket,
    acl: 'public-read',
    contentType: multerS3.AUTO_CONTENT_TYPE,
    key: (req, file, cb) => {
      const uniqueFilename = generateUniqueFilename(file.originalname);
      cb(null, `${folderName}/${uniqueFilename}`);
    },
  });
};

// Configure local storage
const getLocalStorage = (folderName: string) => {
  return multer.diskStorage({
    destination: (req, file, cb) => {
      let destinationDir: string;

      switch (folderName) {
        case 'profile-images':
          destinationDir = profileImagesDir;
          break;
        case 'documents':
          destinationDir = documentsDir;
          break;
        default:
          destinationDir = uploadDir;
      }

      cb(null, destinationDir);
    },
    filename: (req, file, cb) => {
      const uniqueFilename = generateUniqueFilename(file.originalname);
      cb(null, uniqueFilename);
    },
  });
};

// Configure file filter for allowed file types
const fileFilter = (allowedMimetypes: string[]) => (
  req: Express.Request,
  file: Express.Multer.File,
  cb: multer.FileFilterCallback
) => {
  if (allowedMimetypes.includes(file.mimetype)) {
    cb(null, true);
  } else {
    cb(new Error(`File type not allowed. Allowed types: ${allowedMimetypes.join(', ')}`));
  }
};

// Create multer upload configurations
export const profileImageUpload = multer({
  storage: getS3Storage('profile-images') || getLocalStorage('profile-images'),
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB
  },
  fileFilter: fileFilter([
    'image/jpeg',
    'image/png',
    'image/gif',
    'image/webp',
  ]),
});

export const documentUpload = multer({
  storage: getS3Storage('documents') || getLocalStorage('documents'),
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB
  },
  fileFilter: fileFilter([
    'application/pdf',
    'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/vnd.ms-excel',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'text/plain',
  ]),
});

// Function to get file URL
export const getFileUrl = (file: Express.Multer.File): string => {
  if (file.location) {
    // S3 upload
    return file.location;
  } else {
    // Local upload
    const relativePath = path.relative(uploadDir, file.path).replace(/\\/g, '/');
    return `${config.server.apiUrl}/uploads/${relativePath}`;
  }
};

// Function to delete a file
export const deleteFile = async (fileUrl: string): Promise<boolean> => {
  try {
    if (fileUrl.includes('s3.amazonaws.com')) {
      // S3 file
      const key = fileUrl.split('/').slice(3).join('/');
      await s3.deleteObject({
        Bucket: config.aws.s3Bucket!,
        Key: key,
      }).promise();
    } else {
      // Local file
      const localPath = fileUrl.replace(`${config.server.apiUrl}/uploads/`, '');
      const absolutePath = path.join(uploadDir, localPath);

      if (fs.existsSync(absolutePath)) {
        fs.unlinkSync(absolutePath);
      }
    }

    return true;
  } catch (error) {
    console.error('Error deleting file:', error);
    return false;
  }
};
