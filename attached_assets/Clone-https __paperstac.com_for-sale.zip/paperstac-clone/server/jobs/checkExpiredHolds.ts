import { db } from '../db';
import { notes, noteTransactionHistory } from '../db/schema';
import { eq, and, lt } from 'drizzle-orm';
import { config } from '../config';

export async function checkExpiredHolds() {
  try {
    console.log('Checking for expired note holds...');

    const now = new Date();

    // Find notes that are on hold but the hold period has expired
    const expiredHolds = await db
      .select()
      .from(notes)
      .where(
        and(
          eq(notes.availability, 'on_hold'),
          lt(notes.onHoldUntil, now)
        )
      )
      .execute();

    console.log(`Found ${expiredHolds.length} expired holds to process`);

    // Process each expired hold
    for (const note of expiredHolds) {
      console.log(`Processing expired hold for note ID: ${note.id}`);

      // Update the note back to available
      await db
        .update(notes)
        .set({
          availability: 'available',
          onHoldUntil: null,
          onHoldForBuyerId: null,
          onHoldReason: null,
          updatedAt: now,
        })
        .where(eq(notes.id, note.id))
        .execute();

      // Record the status change in transaction history
      await db
        .insert(noteTransactionHistory)
        .values({
          noteId: note.id,
          status: 'available',
          reason: 'Hold period expired',
          createdBy: note.sellerId, // Use seller ID as the creator of this automatic action
        })
        .execute();

      console.log(`Note ID ${note.id} has been returned to available status`);

      // Consider sending notifications here to both buyer and seller
    }

    console.log('Expired holds check completed successfully');
  } catch (error) {
    console.error('Error checking expired holds:', error);
  }
}

// If running this file directly
if (require.main === module) {
  checkExpiredHolds()
    .then(() => {
      console.log('Expired holds check script completed');
      process.exit(0);
    })
    .catch((error) => {
      console.error('Error running expired holds check:', error);
      process.exit(1);
    });
}
