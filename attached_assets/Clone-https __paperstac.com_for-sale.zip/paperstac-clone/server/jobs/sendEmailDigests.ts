import { db } from '../db';
import { config } from '../config';
import { sendSavedSearchDigests } from '../utils/email';

/**
 * Script to send daily/weekly digest emails for saved searches
 * Should be scheduled to run via cron job or similar scheduler
 *
 * Usage:
 * $ bun run server/jobs/sendEmailDigests.ts --frequency=daily
 * or
 * $ bun run server/jobs/sendEmailDigests.ts --frequency=weekly
 */

async function main() {
  // Parse command line arguments
  const args = process.argv.slice(2);
  const frequencyArg = args.find(arg => arg.startsWith('--frequency='));
  const frequency = frequencyArg ? frequencyArg.split('=')[1] : 'daily';

  if (frequency !== 'daily' && frequency !== 'weekly') {
    console.error('Invalid frequency. Use --frequency=daily or --frequency=weekly');
    process.exit(1);
  }

  console.log(`Starting ${frequency} digest job at ${new Date().toISOString()}`);

  try {
    await sendSavedSearchDigests(frequency as 'daily' | 'weekly', db, config);
    console.log(`Completed ${frequency} digest job at ${new Date().toISOString()}`);
  } catch (error) {
    console.error(`Error running ${frequency} digest job:`, error);
    process.exit(1);
  }

  process.exit(0);
}

// Run the job
main();
