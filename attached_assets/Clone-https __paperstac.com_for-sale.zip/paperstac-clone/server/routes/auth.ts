import express from 'express';
import { z } from 'zod';
import { db } from '../db';
import { users, activityLogs } from '../db/schema';
import { eq, and } from 'drizzle-orm';
import {
  hashPassword,
  comparePassword,
  validatePasswordStrength,
  generateJwtTokens,
  generateVerificationToken,
  generatePasswordResetToken,
  revokeAllUserTokens
} from '../utils/auth';
import { sendVerificationEmail, sendPasswordResetEmail, sendWelcomeEmail } from '../utils/email';
import { isAuthenticated, logActivity } from '../middleware/auth';

const router = express.Router();

// Input validation schemas
const registerSchema = z.object({
  email: z.string().email('Invalid email address'),
  password: z.string().min(8, 'Password must be at least 8 characters long'),
  firstName: z.string().min(1, 'First name is required'),
  lastName: z.string().min(1, 'Last name is required'),
  companyName: z.string().optional(),
  phoneNumber: z.string().optional(),
  tosAccepted: z.boolean().refine(val => val === true, {
    message: 'You must accept the Terms of Service'
  }),
});

const loginSchema = z.object({
  email: z.string().email('Invalid email address'),
  password: z.string().min(1, 'Password is required'),
});

const resetPasswordRequestSchema = z.object({
  email: z.string().email('Invalid email address'),
});

const resetPasswordSchema = z.object({
  token: z.string().min(1, 'Token is required'),
  password: z.string().min(8, 'Password must be at least 8 characters long'),
});

const verifyEmailSchema = z.object({
  token: z.string().min(1, 'Token is required'),
});

const changePasswordSchema = z.object({
  currentPassword: z.string().min(1, 'Current password is required'),
  newPassword: z.string().min(8, 'New password must be at least 8 characters long'),
});

// Register a new user
router.post('/register', async (req, res) => {
  try {
    // Validate input
    const validationResult = registerSchema.safeParse(req.body);
    if (!validationResult.success) {
      return res.status(400).json({
        message: 'Validation failed',
        errors: validationResult.error.errors
      });
    }

    const { email, password, firstName, lastName, companyName, phoneNumber, tosAccepted } = validationResult.data;

    // Check password strength
    const passwordValidation = validatePasswordStrength(password);
    if (!passwordValidation.isValid) {
      return res.status(400).json({ message: passwordValidation.message });
    }

    // Check if email already exists
    const existingUser = await db
      .select({ id: users.id })
      .from(users)
      .where(eq(users.email, email))
      .execute();

    if (existingUser.length > 0) {
      return res.status(409).json({ message: 'Email already in use' });
    }

    // Hash password
    const hashedPassword = await hashPassword(password);

    // Create user
    const [newUser] = await db
      .insert(users)
      .values({
        email,
        passwordHash: hashedPassword,
        firstName,
        lastName,
        companyName,
        phoneNumber,
        tosAccepted,
        tosAcceptedDate: tosAccepted ? new Date() : undefined,
        status: 'pending',
      })
      .returning({ id: users.id })
      .execute();

    // Generate verification token
    const verificationToken = await generateVerificationToken(newUser.id);

    // Send verification email
    await sendVerificationEmail(email, firstName, verificationToken);

    // Log activity
    await db.insert(activityLogs).values({
      userId: newUser.id,
      activityType: 'login',
      details: 'User registered',
      ipAddress: req.ip,
      userAgent: req.headers['user-agent'],
    });

    res.status(201).json({
      message: 'Registration successful. Please check your email to verify your account.',
    });
  } catch (error) {
    console.error('Error registering user:', error);
    res.status(500).json({ message: 'Failed to register user' });
  }
});

// Verify email
router.post('/verify-email', async (req, res) => {
  try {
    // Validate input
    const validationResult = verifyEmailSchema.safeParse(req.body);
    if (!validationResult.success) {
      return res.status(400).json({
        message: 'Validation failed',
        errors: validationResult.error.errors
      });
    }

    const { token } = validationResult.data;

    // Find user with token
    const [user] = await db
      .select({
        id: users.id,
        email: users.email,
        firstName: users.firstName,
        verificationTokenExpiry: users.verificationTokenExpiry,
      })
      .from(users)
      .where(and(
        eq(users.verificationToken, token),
        eq(users.isEmailVerified, false)
      ))
      .execute();

    if (!user) {
      return res.status(400).json({ message: 'Invalid or expired verification token' });
    }

    // Check if token is expired
    if (user.verificationTokenExpiry && new Date() > new Date(user.verificationTokenExpiry)) {
      return res.status(400).json({ message: 'Verification token has expired' });
    }

    // Update user status
    await db
      .update(users)
      .set({
        status: 'active',
        isEmailVerified: true,
        emailVerifiedAt: new Date(),
        verificationToken: null,
        verificationTokenExpiry: null,
      })
      .where(eq(users.id, user.id))
      .execute();

    // Send welcome email
    await sendWelcomeEmail(user.email, user.firstName);

    // Log activity
    await db.insert(activityLogs).values({
      userId: user.id,
      activityType: 'account_settings_change',
      details: 'Email verified',
      ipAddress: req.ip,
      userAgent: req.headers['user-agent'],
    });

    res.status(200).json({ message: 'Email verification successful. You can now log in.' });
  } catch (error) {
    console.error('Error verifying email:', error);
    res.status(500).json({ message: 'Failed to verify email' });
  }
});

// Resend verification email
router.post('/resend-verification', async (req, res) => {
  try {
    // Validate input
    const { email } = req.body;
    if (!email) {
      return res.status(400).json({ message: 'Email is required' });
    }

    // Find user
    const [user] = await db
      .select({
        id: users.id,
        firstName: users.firstName,
        isEmailVerified: users.isEmailVerified,
        status: users.status,
      })
      .from(users)
      .where(eq(users.email, email))
      .execute();

    if (!user) {
      // For security reasons, don't reveal if email exists or not
      return res.status(200).json({ message: 'If your email is registered, a verification email will be sent.' });
    }

    // Check if email is already verified
    if (user.isEmailVerified) {
      return res.status(400).json({ message: 'Email is already verified' });
    }

    // Generate new verification token
    const verificationToken = await generateVerificationToken(user.id);

    // Send verification email
    await sendVerificationEmail(email, user.firstName, verificationToken);

    res.status(200).json({ message: 'Verification email sent. Please check your inbox.' });
  } catch (error) {
    console.error('Error resending verification email:', error);
    res.status(500).json({ message: 'Failed to resend verification email' });
  }
});

// Login
router.post('/login', async (req, res) => {
  try {
    // Validate input
    const validationResult = loginSchema.safeParse(req.body);
    if (!validationResult.success) {
      return res.status(400).json({
        message: 'Validation failed',
        errors: validationResult.error.errors
      });
    }

    const { email, password } = validationResult.data;

    // Find user
    const [user] = await db
      .select({
        id: users.id,
        email: users.email,
        passwordHash: users.passwordHash,
        firstName: users.firstName,
        role: users.role,
        status: users.status,
        isEmailVerified: users.isEmailVerified,
      })
      .from(users)
      .where(eq(users.email, email))
      .execute();

    if (!user) {
      return res.status(401).json({ message: 'Invalid email or password' });
    }

    // Check password
    const isPasswordValid = await comparePassword(password, user.passwordHash);
    if (!isPasswordValid) {
      return res.status(401).json({ message: 'Invalid email or password' });
    }

    // Check if email is verified
    if (!user.isEmailVerified) {
      return res.status(403).json({
        message: 'Email not verified. Please check your email for the verification link or request a new one.',
        needsVerification: true
      });
    }

    // Check if account is active
    if (user.status !== 'active') {
      return res.status(403).json({
        message: 'Your account is not active. Please contact support for assistance.'
      });
    }

    // Generate JWT tokens
    const tokens = await generateJwtTokens({
      userId: user.id,
      email: user.email,
      role: user.role,
    });

    // Update last login time
    await db
      .update(users)
      .set({ lastLogin: new Date() })
      .where(eq(users.id, user.id))
      .execute();

    // Log activity
    await db.insert(activityLogs).values({
      userId: user.id,
      activityType: 'login',
      details: 'User logged in',
      ipAddress: req.ip,
      userAgent: req.headers['user-agent'],
    });

    res.status(200).json({
      message: 'Login successful',
      user: {
        id: user.id,
        email: user.email,
        firstName: user.firstName,
        role: user.role,
      },
      tokens,
    });
  } catch (error) {
    console.error('Error logging in:', error);
    res.status(500).json({ message: 'Failed to log in' });
  }
});

// Logout
router.post('/logout', isAuthenticated, async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    const token = authHeader?.split(' ')[1];

    if (token && req.user) {
      // Revoke refresh token
      await revokeAllUserTokens(req.user.id);

      // Log activity
      await db.insert(activityLogs).values({
        userId: req.user.id,
        activityType: 'logout',
        details: 'User logged out',
        ipAddress: req.ip,
        userAgent: req.headers['user-agent'],
      });
    }

    res.status(200).json({ message: 'Logout successful' });
  } catch (error) {
    console.error('Error logging out:', error);
    res.status(500).json({ message: 'Failed to log out' });
  }
});

// Request password reset
router.post('/forgot-password', async (req, res) => {
  try {
    // Validate input
    const validationResult = resetPasswordRequestSchema.safeParse(req.body);
    if (!validationResult.success) {
      return res.status(400).json({
        message: 'Validation failed',
        errors: validationResult.error.errors
      });
    }

    const { email } = validationResult.data;

    // Find user
    const [user] = await db
      .select({
        id: users.id,
        firstName: users.firstName,
      })
      .from(users)
      .where(eq(users.email, email))
      .execute();

    if (!user) {
      // For security reasons, don't reveal if email exists or not
      return res.status(200).json({ message: 'If your email is registered, a password reset link will be sent.' });
    }

    // Generate password reset token
    const resetToken = await generatePasswordResetToken(user.id);

    // Send password reset email
    await sendPasswordResetEmail(email, user.firstName, resetToken);

    res.status(200).json({ message: 'Password reset email sent. Please check your inbox.' });
  } catch (error) {
    console.error('Error requesting password reset:', error);
    res.status(500).json({ message: 'Failed to request password reset' });
  }
});

// Reset password
router.post('/reset-password', async (req, res) => {
  try {
    // Validate input
    const validationResult = resetPasswordSchema.safeParse(req.body);
    if (!validationResult.success) {
      return res.status(400).json({
        message: 'Validation failed',
        errors: validationResult.error.errors
      });
    }

    const { token, password } = validationResult.data;

    // Check password strength
    const passwordValidation = validatePasswordStrength(password);
    if (!passwordValidation.isValid) {
      return res.status(400).json({ message: passwordValidation.message });
    }

    // Find user with token
    const [user] = await db
      .select({
        id: users.id,
        email: users.email,
        resetPasswordTokenExpiry: users.resetPasswordTokenExpiry,
      })
      .from(users)
      .where(eq(users.resetPasswordToken, token))
      .execute();

    if (!user) {
      return res.status(400).json({ message: 'Invalid or expired password reset token' });
    }

    // Check if token is expired
    if (user.resetPasswordTokenExpiry && new Date() > new Date(user.resetPasswordTokenExpiry)) {
      return res.status(400).json({ message: 'Password reset token has expired' });
    }

    // Hash new password
    const hashedPassword = await hashPassword(password);

    // Update user password
    await db
      .update(users)
      .set({
        passwordHash: hashedPassword,
        resetPasswordToken: null,
        resetPasswordTokenExpiry: null,
      })
      .where(eq(users.id, user.id))
      .execute();

    // Revoke all user tokens
    await revokeAllUserTokens(user.id);

    // Log activity
    await db.insert(activityLogs).values({
      userId: user.id,
      activityType: 'password_change',
      details: 'Password reset',
      ipAddress: req.ip,
      userAgent: req.headers['user-agent'],
    });

    res.status(200).json({ message: 'Password reset successful. You can now log in with your new password.' });
  } catch (error) {
    console.error('Error resetting password:', error);
    res.status(500).json({ message: 'Failed to reset password' });
  }
});

// Change password (authenticated)
router.post('/change-password', isAuthenticated, logActivity('password_change'), async (req, res) => {
  try {
    // Validate input
    const validationResult = changePasswordSchema.safeParse(req.body);
    if (!validationResult.success) {
      return res.status(400).json({
        message: 'Validation failed',
        errors: validationResult.error.errors
      });
    }

    const { currentPassword, newPassword } = validationResult.data;
    const userId = req.user!.id;

    // Check password strength
    const passwordValidation = validatePasswordStrength(newPassword);
    if (!passwordValidation.isValid) {
      return res.status(400).json({ message: passwordValidation.message });
    }

    // Get current password hash
    const [user] = await db
      .select({ passwordHash: users.passwordHash })
      .from(users)
      .where(eq(users.id, userId))
      .execute();

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Verify current password
    const isPasswordValid = await comparePassword(currentPassword, user.passwordHash);
    if (!isPasswordValid) {
      return res.status(400).json({ message: 'Current password is incorrect' });
    }

    // Hash new password
    const hashedPassword = await hashPassword(newPassword);

    // Update password
    await db
      .update(users)
      .set({ passwordHash: hashedPassword })
      .where(eq(users.id, userId))
      .execute();

    // Revoke all user tokens except current
    await revokeAllUserTokens(userId);

    res.status(200).json({ message: 'Password changed successfully' });
  } catch (error) {
    console.error('Error changing password:', error);
    res.status(500).json({ message: 'Failed to change password' });
  }
});

export default router;
