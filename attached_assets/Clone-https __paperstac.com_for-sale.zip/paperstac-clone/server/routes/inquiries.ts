import express from 'express';
import { db } from '../db';
import { eq, and, desc } from 'drizzle-orm';
import { inquiries, inquiryReplies, users, notes } from '../db/schema';
import { requireAuth } from '../middleware/auth';
import { z } from 'zod';
import { sendBuyerInquiryNotification } from '../utils/email';
import { config } from '../config';

const router = express.Router();

// Input validation schema
const createInquirySchema = z.object({
  noteId: z.number().int().positive('Note ID is required'),
  subject: z.string().min(3, 'Subject is required'),
  message: z.string().min(3, 'Message is required'),
  phoneNumberRequested: z.boolean().default(false),
});

const replyInquirySchema = z.object({
  message: z.string().min(3, 'Message is required'),
});

// Get all inquiries for the authenticated user (both as buyer and seller)
router.get('/', requireAuth, async (req, res) => {
  try {
    const userId = req.user!.id;
    const role = req.query.role === 'seller' ? 'seller' : 'buyer';

    let result;

    if (role === 'seller') {
      // Fetch inquiries where the user is the seller of the note
      result = await db.query.inquiries.findMany({
        where: (inquiries, { eq, and, sql }) => {
          return and(
            // Join with notes to find notes where user is seller
            sql`${inquiries.noteId} IN (
              SELECT ${notes.id} FROM ${notes._.name}
              WHERE ${notes.sellerId} = ${userId}
            )`
          );
        },
        orderBy: [desc(inquiries.createdAt)],
        with: {
          buyer: {
            columns: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              phoneNumber: true,
              companyName: true,
              profileImageUrl: true,
            }
          },
          note: true
        }
      });
    } else {
      // Fetch inquiries where the user is the buyer
      result = await db.query.inquiries.findMany({
        where: (inquiries, { eq }) => eq(inquiries.buyerId, userId),
        orderBy: [desc(inquiries.createdAt)],
        with: {
          note: {
            with: {
              seller: {
                columns: {
                  id: true,
                  firstName: true,
                  lastName: true,
                  email: true,
                  phoneNumber: true,
                  companyName: true,
                  profileImageUrl: true,
                }
              }
            }
          }
        }
      });
    }

    res.json({ data: result });
  } catch (error) {
    console.error('Error fetching inquiries:', error);
    res.status(500).json({ error: 'Failed to fetch inquiries' });
  }
});

// Get a single inquiry with full details
router.get('/:id', requireAuth, async (req, res) => {
  try {
    const inquiryId = parseInt(req.params.id);
    const userId = req.user!.id;

    // Fetch the inquiry
    const inquiry = await db.query.inquiries.findFirst({
      where: (inquiries, { eq }) => eq(inquiries.id, inquiryId),
      with: {
        buyer: {
          columns: {
            id: true,
            firstName: true,
            lastName: true,
            email: true,
            phoneNumber: true,
            companyName: true,
            profileImageUrl: true,
          }
        },
        note: {
          with: {
            seller: {
              columns: {
                id: true,
                firstName: true,
                lastName: true,
                email: true,
                phoneNumber: true,
                companyName: true,
                profileImageUrl: true,
              }
            }
          }
        },
        replies: {
          orderBy: [inquiryReplies.createdAt],
          with: {
            user: {
              columns: {
                id: true,
                firstName: true,
                lastName: true,
                profileImageUrl: true,
              }
            }
          }
        }
      }
    });

    if (!inquiry) {
      return res.status(404).json({ error: 'Inquiry not found' });
    }

    // Check if the user is either the buyer or the seller
    const isBuyer = inquiry.buyerId === userId;
    const isSeller = inquiry.note.sellerId === userId;

    if (!isBuyer && !isSeller) {
      return res.status(403).json({ error: 'Unauthorized access' });
    }

    // Mark as read if the viewer is the recipient
    if ((isBuyer && inquiry.status === 'replied') || (isSeller && inquiry.status === 'new')) {
      await db
        .update(inquiries)
        .set({
          isRead: true,
          status: isSeller ? 'viewed' : inquiry.status
        })
        .where(eq(inquiries.id, inquiryId))
        .execute();
    }

    // Mark all replies as read for the viewer
    await db
      .update(inquiryReplies)
      .set({ isRead: true })
      .where(
        and(
          eq(inquiryReplies.inquiryId, inquiryId),
          eq(inquiryReplies.userId, userId)
        )
      )
      .execute();

    res.json({ data: inquiry });
  } catch (error) {
    console.error('Error fetching inquiry:', error);
    res.status(500).json({ error: 'Failed to fetch inquiry' });
  }
});

// Create a new inquiry
router.post('/', requireAuth, async (req, res) => {
  try {
    const buyerId = req.user!.id;

    // Validate input
    const validationResult = createInquirySchema.safeParse(req.body);
    if (!validationResult.success) {
      return res.status(400).json({
        message: 'Validation failed',
        errors: validationResult.error.errors
      });
    }

    const { noteId, subject, message, phoneNumberRequested } = validationResult.data;

    // Verify that the note exists
    const noteCheck = await db
      .select({ id: notes.id, sellerId: notes.sellerId })
      .from(notes)
      .where(eq(notes.id, noteId))
      .execute();

    if (noteCheck.length === 0) {
      return res.status(404).json({ error: 'Note not found' });
    }

    // Don't allow users to send inquiries to their own listings
    if (noteCheck[0].sellerId === buyerId) {
      return res.status(400).json({ error: 'You cannot send an inquiry to your own listing' });
    }

    // Create the inquiry
    const [inquiry] = await db
      .insert(inquiries)
      .values({
        buyerId,
        noteId,
        subject,
        message,
        status: 'new',
        isRead: false,
        phoneNumberRequested,
        phoneNumberRevealed: false,
      })
      .returning()
      .execute();

    // Update note inquiry count
    await db
      .update(notes)
      .set({
        inquiryCount: db.sql`${notes.inquiryCount} + 1`,
      })
      .where(eq(notes.id, noteId))
      .execute();

    // Send notification to seller (async)
    const sellerId = noteCheck[0].sellerId;
    setTimeout(() => {
      sendBuyerInquiryNotification(inquiry, sellerId, db, config)
        .catch(err => console.error('Error sending inquiry notification:', err));
    }, 0);

    res.status(201).json({ data: inquiry });
  } catch (error) {
    console.error('Error creating inquiry:', error);
    res.status(500).json({ error: 'Failed to create inquiry' });
  }
});

// Reply to an inquiry
router.post('/:id/reply', requireAuth, async (req, res) => {
  try {
    const inquiryId = parseInt(req.params.id);
    const userId = req.user!.id;

    // Validate input
    const validationResult = replyInquirySchema.safeParse(req.body);
    if (!validationResult.success) {
      return res.status(400).json({
        message: 'Validation failed',
        errors: validationResult.error.errors
      });
    }

    const { message } = validationResult.data;

    // Fetch the inquiry to check permissions
    const inquiry = await db.query.inquiries.findFirst({
      where: (inquiries, { eq }) => eq(inquiries.id, inquiryId),
      with: {
        note: {
          columns: {
            sellerId: true
          }
        }
      }
    });

    if (!inquiry) {
      return res.status(404).json({ error: 'Inquiry not found' });
    }

    // Check if the user is either the buyer or the seller
    const isBuyer = inquiry.buyerId === userId;
    const isSeller = inquiry.note.sellerId === userId;

    if (!isBuyer && !isSeller) {
      return res.status(403).json({ error: 'Unauthorized access' });
    }

    // Create the reply
    const [reply] = await db
      .insert(inquiryReplies)
      .values({
        inquiryId,
        userId,
        message,
        isRead: false,
      })
      .returning()
      .execute();

    // Update the inquiry status
    await db
      .update(inquiries)
      .set({
        status: isSeller ? 'replied' : inquiry.status,
        isRead: false,
        updatedAt: new Date(),
      })
      .where(eq(inquiries.id, inquiryId))
      .execute();

    res.status(201).json({ data: reply });
  } catch (error) {
    console.error('Error replying to inquiry:', error);
    res.status(500).json({ error: 'Failed to reply to inquiry' });
  }
});

// Reveal phone number for an inquiry
router.post('/:id/reveal-phone', requireAuth, async (req, res) => {
  try {
    const inquiryId = parseInt(req.params.id);
    const userId = req.user!.id;

    // Fetch the inquiry to check permissions
    const inquiry = await db.query.inquiries.findFirst({
      where: (inquiries, { eq }) => eq(inquiries.id, inquiryId),
      with: {
        note: {
          columns: {
            sellerId: true
          }
        }
      }
    });

    if (!inquiry) {
      return res.status(404).json({ error: 'Inquiry not found' });
    }

    // Only the seller can reveal their phone number
    if (inquiry.note.sellerId !== userId) {
      return res.status(403).json({ error: 'Only the seller can reveal their phone number' });
    }

    // Update the inquiry to mark phone number as revealed
    await db
      .update(inquiries)
      .set({
        phoneNumberRevealed: true,
        updatedAt: new Date(),
      })
      .where(eq(inquiries.id, inquiryId))
      .execute();

    // Get seller phone number
    const [seller] = await db
      .select({ phoneNumber: users.phoneNumber })
      .from(users)
      .where(eq(users.id, userId))
      .execute();

    res.json({
      message: 'Phone number revealed successfully',
      phoneNumber: seller?.phoneNumber || 'No phone number available'
    });
  } catch (error) {
    console.error('Error revealing phone number:', error);
    res.status(500).json({ error: 'Failed to reveal phone number' });
  }
});

export default router;
