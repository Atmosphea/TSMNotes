import express from 'express';
import { z } from 'zod';
import { db } from '../db';
import {
  users,
  activityLogs,
  notificationPreferences,
  savedSearches,
  sharedSearchViews,
  savedSearchAnalytics,
  notes // Assuming notes is imported from the schema
} from '../db/schema';
import { eq, and, desc, sql, count, inArray, gte, lte } from 'drizzle-orm';
import { isAuthenticated, isResourceOwner, logActivity, requireAuth } from '../middleware/auth';
import { profileImageUpload, getFileUrl, deleteFile } from '../utils/uploads';
import { SavedSearch } from '../types';
import * as crypto from 'crypto';

// Input validation schemas
const updateProfileSchema = z.object({
  firstName: z.string().min(1, 'First name is required'),
  lastName: z.string().min(1, 'Last name is required'),
  companyName: z.string().optional().nullable(),
  phoneNumber: z.string().optional().nullable(),
  bio: z.string().optional().nullable(),
  address: z.string().optional().nullable(),
  city: z.string().optional().nullable(),
  state: z.string().optional().nullable(),
  zipCode: z.string().optional().nullable(),
});

const updateNotificationPreferencesSchema = z.object({
  preferences: z.array(
    z.object({
      notificationType: z.enum([
        'new_listing',
        'buyer_inquiry',
        'account_update',
        'system_message',
      ]),
      email: z.boolean(),
      inApp: z.boolean(),
    })
  ),
});

// Generate a unique share token
const generateShareToken = (): string => {
  return crypto.randomBytes(32).toString('hex');
};

// Track saved search usage
const trackSavedSearchUsage = async (req, searchId, action, countMatches = null, executionTimeMs = null) => {
  try {
    if (!req.user?.id || !searchId) return;

    await db
      .insert(savedSearchAnalytics)
      .values({
        searchId,
        userId: req.user.id,
        action,
        countMatches,
        executionTimeMs,
        ipAddress: req.ip,
        userAgent: req.headers['user-agent'],
      })
      .execute();
  } catch (error) {
    console.error('Error tracking saved search usage:', error);
    // Don't throw - this is non-critical functionality
  }
};

// Get current user profile
const router = express.Router();

router.get('/me', isAuthenticated, async (req, res) => {
  try {
    const userId = req.user!.id;

    const [userProfile] = await db
      .select({
        id: users.id,
        email: users.email,
        firstName: users.firstName,
        lastName: users.lastName,
        companyName: users.companyName,
        phoneNumber: users.phoneNumber,
        profileImageUrl: users.profileImageUrl,
        bio: users.bio,
        address: users.address,
        city: users.city,
        state: users.state,
        zipCode: users.zipCode,
        role: users.role,
        status: users.status,
        lastLogin: users.lastLogin,
        isEmailVerified: users.isEmailVerified,
        emailVerifiedAt: users.emailVerifiedAt,
        createdAt: users.createdAt,
      })
      .from(users)
      .where(eq(users.id, userId))
      .execute();

    if (!userProfile) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Get notification preferences
    const notificationPrefs = await db
      .select()
      .from(notificationPreferences)
      .where(eq(notificationPreferences.userId, userId))
      .execute();

    res.status(200).json({
      user: userProfile,
      notificationPreferences: notificationPrefs,
    });
  } catch (error) {
    console.error('Error fetching user profile:', error);
    res.status(500).json({ message: 'Failed to fetch user profile' });
  }
});

// Get user by ID (admin only)
router.get('/:id', isAuthenticated, isResourceOwner('id', 'user'), async (req, res) => {
  try {
    const userId = parseInt(req.params.id);

    const [userProfile] = await db
      .select({
        id: users.id,
        email: users.email,
        firstName: users.firstName,
        lastName: users.lastName,
        companyName: users.companyName,
        phoneNumber: users.phoneNumber,
        profileImageUrl: users.profileImageUrl,
        bio: users.bio,
        address: users.address,
        city: users.city,
        state: users.state,
        zipCode: users.zipCode,
        role: users.role,
        status: users.status,
        lastLogin: users.lastLogin,
        isEmailVerified: users.isEmailVerified,
        emailVerifiedAt: users.emailVerifiedAt,
        createdAt: users.createdAt,
      })
      .from(users)
      .where(eq(users.id, userId))
      .execute();

    if (!userProfile) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Get notification preferences
    const notificationPrefs = await db
      .select()
      .from(notificationPreferences)
      .where(eq(notificationPreferences.userId, userId))
      .execute();

    res.status(200).json({
      user: userProfile,
      notificationPreferences: notificationPrefs,
    });
  } catch (error) {
    console.error('Error fetching user profile:', error);
    res.status(500).json({ message: 'Failed to fetch user profile' });
  }
});

// Update user profile
router.put('/me', isAuthenticated, logActivity('profile_update'), async (req, res) => {
  try {
    const userId = req.user!.id;

    // Validate input
    const validationResult = updateProfileSchema.safeParse(req.body);
    if (!validationResult.success) {
      return res.status(400).json({
        message: 'Validation failed',
        errors: validationResult.error.errors
      });
    }

    const {
      firstName,
      lastName,
      companyName,
      phoneNumber,
      bio,
      address,
      city,
      state,
      zipCode,
    } = validationResult.data;

    // Update user profile
    const [updatedUser] = await db
      .update(users)
      .set({
        firstName,
        lastName,
        companyName,
        phoneNumber,
        bio,
        address,
        city,
        state,
        zipCode,
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId))
      .returning({
        id: users.id,
        email: users.email,
        firstName: users.firstName,
        lastName: users.lastName,
        companyName: users.companyName,
        phoneNumber: users.phoneNumber,
        profileImageUrl: users.profileImageUrl,
        bio: users.bio,
        address: users.address,
        city: users.city,
        state: users.state,
        zipCode: users.zipCode,
      })
      .execute();

    res.status(200).json({
      message: 'Profile updated successfully',
      user: updatedUser,
    });
  } catch (error) {
    console.error('Error updating user profile:', error);
    res.status(500).json({ message: 'Failed to update user profile' });
  }
});

// Upload profile image
router.post(
  '/me/profile-image',
  isAuthenticated,
  logActivity('profile_update'),
  profileImageUpload.single('image'), // 'image' is the field name in the form
  async (req, res) => {
    try {
      const userId = req.user!.id;
      const file = req.file;

      if (!file) {
        return res.status(400).json({ message: 'No image file provided' });
      }

      // Get file URL
      const fileUrl = getFileUrl(file);

      // Get current profile image URL to delete later
      const [currentUser] = await db
        .select({ profileImageUrl: users.profileImageUrl })
        .from(users)
        .where(eq(users.id, userId))
        .execute();

      // Update user profile with new image URL
      const [updatedUser] = await db
        .update(users)
        .set({
          profileImageUrl: fileUrl,
          updatedAt: new Date(),
        })
        .where(eq(users.id, userId))
        .returning({
          id: users.id,
          profileImageUrl: users.profileImageUrl,
        })
        .execute();

      // Delete old profile image if it exists
      if (currentUser?.profileImageUrl) {
        await deleteFile(currentUser.profileImageUrl);
      }

      res.status(200).json({
        message: 'Profile image updated successfully',
        profileImageUrl: updatedUser.profileImageUrl,
      });
    } catch (error) {
      console.error('Error updating profile image:', error);
      res.status(500).json({ message: 'Failed to update profile image' });
    }
  }
);

// Delete profile image
router.delete(
  '/me/profile-image',
  isAuthenticated,
  logActivity('profile_update'),
  async (req, res) => {
    try {
      const userId = req.user!.id;

      // Get current profile image URL
      const [currentUser] = await db
        .select({ profileImageUrl: users.profileImageUrl })
        .from(users)
        .where(eq(users.id, userId))
        .execute();

      if (!currentUser?.profileImageUrl) {
        return res.status(400).json({ message: 'No profile image to delete' });
      }

      // Update user profile to remove image URL
      await db
        .update(users)
        .set({
          profileImageUrl: null,
          updatedAt: new Date(),
        })
        .where(eq(users.id, userId))
        .execute();

      // Delete profile image file
      await deleteFile(currentUser.profileImageUrl);

      res.status(200).json({
        message: 'Profile image deleted successfully',
      });
    } catch (error) {
      console.error('Error deleting profile image:', error);
      res.status(500).json({ message: 'Failed to delete profile image' });
    }
  }
);

// Update notification preferences
router.put(
  '/me/notification-preferences',
  isAuthenticated,
  logActivity('account_settings_change'),
  async (req, res) => {
    try {
      const userId = req.user!.id;

      // Validate input
      const validationResult = updateNotificationPreferencesSchema.safeParse(req.body);
      if (!validationResult.success) {
        return res.status(400).json({
          message: 'Validation failed',
          errors: validationResult.error.errors
        });
      }

      const { preferences } = validationResult.data;

      // Delete existing preferences
      await db
        .delete(notificationPreferences)
        .where(eq(notificationPreferences.userId, userId))
        .execute();

      // Insert new preferences
      const updatedPreferences = await Promise.all(
        preferences.map(async (pref) => {
          const [newPref] = await db
            .insert(notificationPreferences)
            .values({
              userId,
              notificationType: pref.notificationType,
              email: pref.email,
              inApp: pref.inApp,
            })
            .returning()
            .execute();

          return newPref;
        })
      );

      res.status(200).json({
        message: 'Notification preferences updated successfully',
        notificationPreferences: updatedPreferences,
      });
    } catch (error) {
      console.error('Error updating notification preferences:', error);
      res.status(500).json({ message: 'Failed to update notification preferences' });
    }
  }
);

// Deactivate account
router.post(
  '/me/deactivate',
  isAuthenticated,
  logActivity('account_settings_change'),
  async (req, res) => {
    try {
      const userId = req.user!.id;

      // Update user status
      await db
        .update(users)
        .set({
          status: 'inactive',
          updatedAt: new Date(),
        })
        .where(eq(users.id, userId))
        .execute();

      // Revoke all tokens
      // This is handled by the auth.ts utility

      res.status(200).json({
        message: 'Account deactivated successfully',
      });
    } catch (error) {
      console.error('Error deactivating account:', error);
      res.status(500).json({ message: 'Failed to deactivate account' });
    }
  }
);

// Delete account (this would typically be a "request deletion" that's processed later)
router.post(
  '/me/delete',
  isAuthenticated,
  logActivity('account_settings_change'),
  async (req, res) => {
    try {
      const userId = req.user!.id;

      // In a real app, we might not actually delete the account immediately
      // Instead, we might mark it for deletion or schedule it for deletion later
      await db
        .update(users)
        .set({
          status: 'inactive',
          // Mark data for deletion but keep it for a grace period
          // Additional fields might be added to track the deletion request
          updatedAt: new Date(),
        })
        .where(eq(users.id, userId))
        .execute();

      // Log the deletion request
      await db.insert(activityLogs).values({
        userId,
        activityType: 'account_settings_change',
        details: 'Account deletion requested',
        ipAddress: req.ip,
        userAgent: req.headers['user-agent'],
      });

      res.status(200).json({
        message: 'Account deletion requested. Your account will be permanently deleted within 30 days.',
      });
    } catch (error) {
      console.error('Error requesting account deletion:', error);
      res.status(500).json({ message: 'Failed to request account deletion' });
    }
  }
);

// Search preferences routes (protected by auth)
router.get('/saved-searches', requireAuth, async (req, res) => {
  try {
    const userId = req.user!.id;

    const userSavedSearches = await db
      .select()
      .from(savedSearches)
      .where(eq(savedSearches.userId, userId))
      .execute();

    // Track view action for all user's saved searches (asynchronously)
    userSavedSearches.forEach(search => {
      setTimeout(() => {
        trackSavedSearchUsage(req, search.id, 'view').catch(console.error);
      }, 0);
    });

    res.json({ data: userSavedSearches });
  } catch (error) {
    console.error('Error fetching saved searches:', error);
    res.status(500).json({ error: 'Failed to fetch saved searches' });
  }
});

router.post('/saved-searches', requireAuth, async (req, res) => {
  try {
    const userId = req.user!.id;
    const searchData = req.body as Omit<SavedSearch, 'id' | 'userId' | 'createdAt' | 'updatedAt'>;

    // Validate the search name
    if (!searchData.name || searchData.name.trim().length === 0) {
      return res.status(400).json({ error: 'Search name is required' });
    }

    // Check if user already has a saved search with this name
    const existingSearch = await db
      .select()
      .from(savedSearches)
      .where(
        and(
          eq(savedSearches.userId, userId),
          eq(savedSearches.name, searchData.name)
        )
      )
      .execute();

    if (existingSearch.length > 0) {
      return res.status(400).json({ error: 'A saved search with this name already exists' });
    }

    // Create the saved search
    const result = await db
      .insert(savedSearches)
      .values({
        userId,
        ...searchData,
      })
      .returning()
      .execute();

    // Track creation of the saved search
    const newSearch = result[0];
    if (newSearch) {
      setTimeout(() => {
        trackSavedSearchUsage(req, newSearch.id, 'create_alert').catch(console.error);
      }, 0);
    }

    res.status(201).json({ data: newSearch });
  } catch (error) {
    console.error('Error creating saved search:', error);
    res.status(500).json({ error: 'Failed to save search' });
  }
});

router.get('/saved-searches/:id', requireAuth, async (req, res) => {
  try {
    const userId = req.user!.id;
    const searchId = parseInt(req.params.id);

    const savedSearch = await db
      .select()
      .from(savedSearches)
      .where(
        and(
          eq(savedSearches.id, searchId),
          eq(savedSearches.userId, userId)
        )
      )
      .execute();

    if (savedSearch.length === 0) {
      return res.status(404).json({ error: 'Saved search not found' });
    }

    res.json({ data: savedSearch[0] });
  } catch (error) {
    console.error('Error fetching saved search:', error);
    res.status(500).json({ error: 'Failed to fetch saved search' });
  }
});

// Update saved search
router.put('/saved-searches/:id', requireAuth, async (req, res) => {
  try {
    const userId = req.user!.id;
    const searchId = parseInt(req.params.id);
    const searchData = req.body;

    // Check if the saved search belongs to the user
    const existingSearch = await db
      .select()
      .from(savedSearches)
      .where(
        and(
          eq(savedSearches.id, searchId),
          eq(savedSearches.userId, userId)
        )
      )
      .execute();

    if (existingSearch.length === 0) {
      return res.status(404).json({ error: 'Saved search not found' });
    }

    // Generate a share token if making the search public and it doesn't have one
    if (searchData.isPublic === true && !existingSearch[0].shareToken) {
      searchData.shareToken = generateShareToken();

      // Track sharing action
      setTimeout(() => {
        trackSavedSearchUsage(req, searchId, 'share').catch(console.error);
      }, 0);
    }

    // Update the saved search
    const result = await db
      .update(savedSearches)
      .set({
        ...searchData,
        updatedAt: new Date(),
      })
      .where(eq(savedSearches.id, searchId))
      .returning()
      .execute();

    // Track the modify action
    setTimeout(() => {
      trackSavedSearchUsage(req, searchId, 'modify').catch(console.error);
    }, 0);

    res.json({ data: result[0] });
  } catch (error) {
    console.error('Error updating saved search:', error);
    res.status(500).json({ error: 'Failed to update saved search' });
  }
});

router.delete('/saved-searches/:id', requireAuth, async (req, res) => {
  try {
    const userId = req.user!.id;
    const searchId = parseInt(req.params.id);

    // Check if the saved search belongs to the user
    const existingSearch = await db
      .select()
      .from(savedSearches)
      .where(
        and(
          eq(savedSearches.id, searchId),
          eq(savedSearches.userId, userId)
        )
      )
      .execute();

    if (existingSearch.length === 0) {
      return res.status(404).json({ error: 'Saved search not found' });
    }

    // Delete the saved search
    await db
      .delete(savedSearches)
      .where(eq(savedSearches.id, searchId))
      .execute();

    res.status(204).send();
  } catch (error) {
    console.error('Error deleting saved search:', error);
    res.status(500).json({ error: 'Failed to delete saved search' });
  }
});

// Public access to a shared search
router.get('/shared-searches/:token', async (req, res) => {
  try {
    const token = req.params.token;

    // Find the search by share token
    const search = await db
      .select()
      .from(savedSearches)
      .where(
        and(
          eq(savedSearches.shareToken, token),
          eq(savedSearches.isPublic, true)
        )
      )
      .execute();

    if (search.length === 0) {
      return res.status(404).json({ error: 'Shared search not found' });
    }

    // Record the view analytics
    if (req.ip || req.headers['user-agent']) {
      await db
        .insert(sharedSearchViews)
        .values({
          searchId: search[0].id,
          viewerIp: req.ip || null,
          userAgent: req.headers['user-agent'] || null,
          referrer: req.headers.referer || null,
        })
        .execute();
    }

    res.json({ data: search[0] });
  } catch (error) {
    console.error('Error fetching shared search:', error);
    res.status(500).json({ error: 'Failed to fetch shared search' });
  }
});

// Get analytics for shared searches (admin or search owner only)
router.get('/saved-searches/:id/analytics', requireAuth, async (req, res) => {
  try {
    const userId = req.user!.id;
    const searchId = parseInt(req.params.id);
    const isAdmin = req.user!.role === 'admin';

    // Check if the saved search belongs to the user or user is admin
    if (!isAdmin) {
      const searchOwner = await db
        .select()
        .from(savedSearches)
        .where(
          and(
            eq(savedSearches.id, searchId),
            eq(savedSearches.userId, userId)
          )
        )
        .execute();

      if (searchOwner.length === 0) {
        return res.status(403).json({ error: 'Access denied' });
      }
    }

    // Get analytics data
    const views = await db
      .select()
      .from(sharedSearchViews)
      .where(eq(sharedSearchViews.searchId, searchId))
      .orderBy(desc(sharedSearchViews.viewedAt))
      .execute();

    // Calculate some summary stats
    const totalViews = views.length;
    const uniqueViewers = new Set(views.filter(v => v.viewerIp).map(v => v.viewerIp)).size;
    const viewsByDate = views.reduce((acc: Record<string, number>, view) => {
      const date = new Date(view.viewedAt).toISOString().split('T')[0];
      acc[date] = (acc[date] || 0) + 1;
      return acc;
    }, {});

    res.json({
      data: {
        totalViews,
        uniqueViewers,
        viewsByDate,
        recentViews: views.slice(0, 20), // Return only the 20 most recent views
      },
    });
  } catch (error) {
    console.error('Error fetching shared search analytics:', error);
    res.status(500).json({ error: 'Failed to fetch shared search analytics' });
  }
});

// Add a new endpoint to get analytics for a saved search
router.get('/saved-searches/:id/analytics', requireAuth, async (req, res) => {
  try {
    const userId = req.user!.id;
    const searchId = parseInt(req.params.id);
    const isAdmin = req.user!.role === 'admin';

    // Check if the saved search belongs to the user or if the user is an admin
    if (!isAdmin) {
      const searchCheck = await db
        .select()
        .from(savedSearches)
        .where(
          and(
            eq(savedSearches.id, searchId),
            eq(savedSearches.userId, userId)
          )
        )
        .execute();

      if (searchCheck.length === 0) {
        return res.status(403).json({ error: 'Access denied' });
      }
    }

    // Get all analytics records for this search
    const analyticsRecords = await db
      .select()
      .from(savedSearchAnalytics)
      .where(eq(savedSearchAnalytics.searchId, searchId))
      .orderBy(desc(savedSearchAnalytics.createdAt))
      .execute();

    // Compute summary metrics
    const totalUsage = analyticsRecords.length;

    // Usage by action type
    const usageByAction: Record<string, number> = {};
    analyticsRecords.forEach(record => {
      usageByAction[record.action] = (usageByAction[record.action] || 0) + 1;
    });

    // Match stats
    const executeActions = analyticsRecords.filter(r =>
      r.action === 'execute' && r.countMatches !== null && r.countMatches !== undefined
    );

    const matchRates = {
      avgMatches: 0,
      maxMatches: 0,
      totalMatches: 0,
    };

    if (executeActions.length > 0) {
      const matches = executeActions.map(r => r.countMatches!);
      matchRates.avgMatches = matches.reduce((sum, val) => sum + val, 0) / matches.length;
      matchRates.maxMatches = Math.max(...matches);
      matchRates.totalMatches = matches.reduce((sum, val) => sum + val, 0);
    }

    // Usage by date
    const usageByDate: Record<string, number> = {};
    analyticsRecords.forEach(record => {
      const date = new Date(record.createdAt).toISOString().split('T')[0];
      usageByDate[date] = (usageByDate[date] || 0) + 1;
    });

    // Last used date
    const lastUsed = analyticsRecords.length > 0
      ? analyticsRecords[0].createdAt
      : new Date();

    // Get shared view analytics
    const sharedViews = await db
      .select()
      .from(sharedSearchViews)
      .where(eq(sharedSearchViews.searchId, searchId))
      .orderBy(desc(sharedSearchViews.viewedAt))
      .execute();

    const uniqueViewers = new Set(sharedViews.filter(v => v.viewerIp).map(v => v.viewerIp)).size;

    // Return detailed analytics and summary
    res.json({
      data: {
        summary: {
          searchId,
          totalUsage,
          usageByAction,
          matchRates,
          usageByDate,
          lastUsed,
        },
        recentActivity: analyticsRecords.slice(0, 20), // Limit to 20 most recent activities
        sharedViews: {
          totalViews: sharedViews.length,
          uniqueViewers,
          recentViews: sharedViews.slice(0, 10), // Limit to 10 most recent views
        }
      }
    });
  } catch (error) {
    console.error('Error fetching saved search analytics:', error);
    res.status(500).json({ error: 'Failed to fetch analytics' });
  }
});

// Add an endpoint to list most frequently used searches
router.get('/saved-searches/analytics/most-used', requireAuth, async (req, res) => {
  try {
    const userId = req.user!.id;
    const isAdmin = req.user!.role === 'admin';

    // For admins, get overall usage. For regular users, just their own searches.
    let query;

    if (isAdmin) {
      // Get overall analytics for all searches
      query = db
        .select({
          searchId: savedSearchAnalytics.searchId,
          usageCount: count(savedSearchAnalytics.id),
        })
        .from(savedSearchAnalytics)
        .groupBy(savedSearchAnalytics.searchId)
        .orderBy(desc(sql`count(*)`))
        .limit(10);
    } else {
      // Get analytics just for this user's searches
      query = db
        .select({
          searchId: savedSearchAnalytics.searchId,
          usageCount: count(savedSearchAnalytics.id),
        })
        .from(savedSearchAnalytics)
        .innerJoin(
          savedSearches,
          eq(savedSearchAnalytics.searchId, savedSearches.id)
        )
        .where(eq(savedSearches.userId, userId))
        .groupBy(savedSearchAnalytics.searchId)
        .orderBy(desc(sql`count(*)`))
        .limit(10);
    }

    const mostUsedSearchIds = await query.execute();

    // Fetch the actual saved search details for these IDs
    if (mostUsedSearchIds.length > 0) {
      const searchIds = mostUsedSearchIds.map(item => item.searchId);

      const searches = await db
        .select()
        .from(savedSearches)
        .where(inArray(savedSearches.id, searchIds))
        .execute();

      // Combine usage counts with search details
      const searchesWithAnalytics = searches.map(search => {
        const analytics = mostUsedSearchIds.find(a => a.searchId === search.id);
        return {
          ...search,
          usageCount: analytics?.usageCount || 0,
        };
      });

      // Sort by usage count (descending)
      searchesWithAnalytics.sort((a, b) => b.usageCount - a.usageCount);

      res.json({ data: searchesWithAnalytics });
    } else {
      res.json({ data: [] });
    }
  } catch (error) {
    console.error('Error fetching most used searches:', error);
    res.status(500).json({ error: 'Failed to fetch most used searches' });
  }
});

// Add an execute endpoint that tracks search execution and match count
router.post('/saved-searches/:id/execute', requireAuth, async (req, res) => {
  try {
    const userId = req.user!.id;
    const searchId = parseInt(req.params.id);

    // Check if the saved search belongs to the user
    const savedSearch = await db
      .select()
      .from(savedSearches)
      .where(
        and(
          eq(savedSearches.id, searchId),
          eq(savedSearches.userId, userId)
        )
      )
      .execute();

    if (savedSearch.length === 0) {
      return res.status(404).json({ error: 'Saved search not found' });
    }

    const search = savedSearch[0];

    // Build filter conditions for the search
    const searchConditions = [];

    // Note type filter
    if (search.noteType) {
      searchConditions.push(eq(notes.noteType, search.noteType));
    }

    // Lien position filter
    if (search.lienPosition) {
      searchConditions.push(eq(notes.lienPosition, search.lienPosition));
    }

    // Performance filter
    if (search.performance) {
      searchConditions.push(eq(notes.performance, search.performance));
    }

    // Listing type filter
    if (search.listingType) {
      searchConditions.push(eq(notes.listingType, search.listingType));
    }

    // Price range filter
    if (search.minPrice) {
      searchConditions.push(gte(notes.price, search.minPrice));
    }
    if (search.maxPrice) {
      searchConditions.push(lte(notes.price, search.maxPrice));
    }

    // Yield range filter
    if (search.minYield) {
      searchConditions.push(gte(notes.yield, search.minYield));
    }
    if (search.maxYield) {
      searchConditions.push(lte(notes.yield, search.maxYield));
    }

    // LTV range filter
    if (search.minLtv) {
      searchConditions.push(gte(notes.ltv, search.minLtv));
    }
    if (search.maxLtv) {
      searchConditions.push(lte(notes.ltv, search.maxLtv));
    }

    // Interest rate range filter
    if (search.minInterestRate) {
      searchConditions.push(gte(notes.interestRate, search.minInterestRate));
    }
    if (search.maxInterestRate) {
      searchConditions.push(lte(notes.interestRate, search.maxInterestRate));
    }

    // Property type filter
    if (search.propertyType) {
      searchConditions.push(eq(notes.propertyType, search.propertyType));
    }

    // Property state filter
    if (search.propertyState) {
      searchConditions.push(eq(notes.propertyState, search.propertyState));
    }

    // State type filter
    if (search.stateType) {
      searchConditions.push(eq(notes.stateType, search.stateType));
    }

    // Foreclosure filter
    if (search.hasForeclosure !== null && search.hasForeclosure !== undefined) {
      searchConditions.push(eq(notes.hasForeclosure, search.hasForeclosure));
    }

    // Only show available notes
    searchConditions.push(eq(notes.availability, 'available'));

    // Time the search execution
    const startTime = Date.now();

    // Execute the search query
    let query = db.select().from(notes);

    if (searchConditions.length > 0) {
      query = query.where(and(...searchConditions));
    }

    // Execute the query
    const results = await query.execute();

    // Calculate execution time
    const executionTimeMs = Date.now() - startTime;

    // Track the execution
    setTimeout(() => {
      trackSavedSearchUsage(req, searchId, 'execute', results.length, executionTimeMs).catch(console.error);
    }, 0);

    res.json({
      data: {
        results,
        count: results.length,
        executionTimeMs,
      }
    });
  } catch (error) {
    console.error('Error executing saved search:', error);
    res.status(500).json({ error: 'Failed to execute saved search' });
  }
});

export default router;
