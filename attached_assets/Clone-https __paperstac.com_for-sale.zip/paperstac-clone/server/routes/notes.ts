import express from 'express';
import { z } from 'zod';
import { eq, and, gte, lte, inArray, like, desc, asc, ne } from 'drizzle-orm';
import { db } from '../db';
import { notes, noteTransactionHistory } from '../db/schema';
import { NoteFilterParams, PlaceNoteOnHoldParams, CompleteTransactionParams } from '../types';
import { sendMatchingNoteNotifications } from '../utils/email';
import { config } from '../config';
import { requireAuth, isResourceOwner } from '../middleware/auth';

const router = express.Router();

// Validation schema for placing note on hold
const placeOnHoldSchema = z.object({
  noteId: z.number().int().positive(),
  buyerId: z.number().int().positive(),
  reason: z.string().optional(),
  durationHours: z.number().int().positive().default(48),
});

// Validation schema for completing a transaction
const completeTransactionSchema = z.object({
  noteId: z.number().int().positive(),
  buyerId: z.number().int().positive(),
  soldPrice: z.number().positive().optional(),
});

// Get all notes with filtering
router.get('/', async (req, res) => {
  try {
    const filters: NoteFilterParams = req.query;
    const page = parseInt(filters.page as string) || 1;
    const limit = parseInt(filters.limit as string) || 10;
    const offset = (page - 1) * limit;

    // Build filter conditions
    const conditions = [];

    // Availability filter
    if (filters.availability) {
      conditions.push(eq(notes.availability, filters.availability));
    }

    // Listing type filter
    if (filters.listingType) {
      conditions.push(eq(notes.listingType, filters.listingType));
    }

    // Lien position filter
    if (filters.lienPosition) {
      conditions.push(eq(notes.lienPosition, filters.lienPosition));
    }

    // Performance filter
    if (filters.performance) {
      conditions.push(eq(notes.performance, filters.performance));
    }

    // Note type filter
    if (filters.noteType) {
      conditions.push(eq(notes.noteType, filters.noteType));
    }

    // Property type filter
    if (filters.propertyType) {
      conditions.push(eq(notes.propertyType, filters.propertyType));
    }

    // Price range filter
    if (filters.minPrice) {
      conditions.push(gte(notes.price, parseFloat(filters.minPrice as string)));
    }
    if (filters.maxPrice) {
      conditions.push(lte(notes.price, parseFloat(filters.maxPrice as string)));
    }

    // Yield range filter
    if (filters.minYield) {
      conditions.push(gte(notes.yield, parseFloat(filters.minYield as string)));
    }
    if (filters.maxYield) {
      conditions.push(lte(notes.yield, parseFloat(filters.maxYield as string)));
    }

    // LTV range filter
    if (filters.minLtv) {
      conditions.push(gte(notes.ltv, parseFloat(filters.minLtv as string)));
    }
    if (filters.maxLtv) {
      conditions.push(lte(notes.ltv, parseFloat(filters.maxLtv as string)));
    }

    // Foreclosure filter
    if (filters.hasForeclosure) {
      conditions.push(eq(notes.hasForeclosure, filters.hasForeclosure === 'true'));
    }

    // State type filter
    if (filters.stateType) {
      conditions.push(eq(notes.stateType, filters.stateType));
    }

    // Execute the query with filters, sorting, and pagination
    let query = db.select().from(notes);

    if (conditions.length > 0) {
      query = query.where(and(...conditions));
    }

    // Sorting
    if (filters.sortBy) {
      const sortField = filters.sortBy as keyof typeof notes;

      if (sortField in notes) {
        if (filters.sortDirection === 'desc') {
          query = query.orderBy(desc(notes[sortField]));
        } else {
          query = query.orderBy(asc(notes[sortField]));
        }
      }
    } else {
      // Default sort by created date, newest first
      query = query.orderBy(desc(notes.createdAt));
    }

    // Execute count query for pagination
    const countQuery = db.select({ count: db.fn.count() }).from(notes);
    if (conditions.length > 0) {
      countQuery.where(and(...conditions));
    }
    const countResult = await countQuery.execute();
    const totalCount = parseInt(countResult[0].count.toString());

    // Execute the main query with pagination
    const result = await query.limit(limit).offset(offset).execute();

    res.json({
      data: result,
      pagination: {
        page,
        limit,
        totalCount,
        totalPages: Math.ceil(totalCount / limit),
      }
    });
  } catch (error) {
    console.error('Error fetching notes:', error);
    res.status(500).json({ error: 'Failed to fetch notes' });
  }
});

// Get a note by ID
router.get('/:id', async (req, res) => {
  try {
    const noteId = parseInt(req.params.id);
    const result = await db.select().from(notes).where(eq(notes.id, noteId)).execute();

    if (result.length === 0) {
      return res.status(404).json({ error: 'Note not found' });
    }

    res.json(result[0]);
  } catch (error) {
    console.error('Error fetching note:', error);
    res.status(500).json({ error: 'Failed to fetch note' });
  }
});

// Create a new note (protected route, would require authentication middleware)
router.post('/', async (req, res) => {
  try {
    const noteData = req.body;

    // Would normally validate seller identity from auth token
    // noteData.sellerId = req.user.id;

    const result = await db.insert(notes).values(noteData).returning().execute();
    const newNote = result[0];

    // Trigger email notifications for matching saved searches
    if (newNote.availability === 'available') {
      // Process notifications asynchronously
      setTimeout(() => {
        sendMatchingNoteNotifications(newNote, db, config)
          .catch(err => console.error('Error sending note notifications:', err));
      }, 0);
    }

    res.status(201).json(result[0]);
  } catch (error) {
    console.error('Error creating note:', error);
    res.status(500).json({ error: 'Failed to create note' });
  }
});

// Update a note (protected route)
router.put('/:id', async (req, res) => {
  try {
    const noteId = parseInt(req.params.id);
    const noteData = req.body;

    // Would normally validate ownership
    // const existingNote = await db.select().from(notes).where(eq(notes.id, noteId)).execute();
    // if (existingNote[0].sellerId !== req.user.id) {
    //   return res.status(403).json({ error: 'Not authorized to update this note' });
    // }

    const result = await db.update(notes)
      .set({ ...noteData, updatedAt: new Date() })
      .where(eq(notes.id, noteId))
      .returning()
      .execute();

    if (result.length === 0) {
      return res.status(404).json({ error: 'Note not found' });
    }

    res.json(result[0]);
  } catch (error) {
    console.error('Error updating note:', error);
    res.status(500).json({ error: 'Failed to update note' });
  }
});

// Delete a note (protected route)
router.delete('/:id', async (req, res) => {
  try {
    const noteId = parseInt(req.params.id);

    // Would normally validate ownership

    await db.delete(notes).where(eq(notes.id, noteId)).execute();

    res.status(204).send();
  } catch (error) {
    console.error('Error deleting note:', error);
    res.status(500).json({ error: 'Failed to delete note' });
  }
});

// Place a note on hold (time-limited offer)
router.post('/hold', requireAuth, async (req, res) => {
  try {
    const validationResult = placeOnHoldSchema.safeParse(req.body);
    if (!validationResult.success) {
      return res.status(400).json({
        message: 'Validation failed',
        errors: validationResult.error.errors
      });
    }

    const { noteId, buyerId, reason, durationHours } = validationResult.data;

    // Check if the note exists and is available
    const [noteCheck] = await db
      .select()
      .from(notes)
      .where(
        and(
          eq(notes.id, noteId),
          eq(notes.availability, 'available')
        )
      )
      .execute();

    if (!noteCheck) {
      return res.status(404).json({ error: 'Note not found or not available' });
    }

    // Verify that the current user is the seller
    if (noteCheck.sellerId !== req.user!.id) {
      return res.status(403).json({ error: 'Only the seller can place a note on hold' });
    }

    // Calculate hold expiration date (default 48 hours)
    const now = new Date();
    const expiresAt = new Date(now.getTime() + (durationHours * 60 * 60 * 1000));

    // Update the note status to on_hold
    const [updatedNote] = await db
      .update(notes)
      .set({
        availability: 'on_hold',
        onHoldUntil: expiresAt,
        onHoldForBuyerId: buyerId,
        onHoldReason: reason || `Reserved for buyer ${buyerId}`,
        updatedAt: now,
      })
      .where(eq(notes.id, noteId))
      .returning()
      .execute();

    // Record the transaction in history
    await db
      .insert(noteTransactionHistory)
      .values({
        noteId,
        status: 'on_hold',
        buyerId,
        reason: reason || `Reserved for buyer ${buyerId}`,
        expiresAt,
        createdBy: req.user!.id,
      })
      .execute();

    // TODO: Send notifications to the buyer

    res.status(200).json({
      message: 'Note successfully placed on hold',
      note: updatedNote
    });
  } catch (error) {
    console.error('Error placing note on hold:', error);
    res.status(500).json({ error: 'Failed to place note on hold' });
  }
});

// Release a note from hold (cancel the time-limited offer)
router.post('/release/:id', requireAuth, async (req, res) => {
  try {
    const noteId = parseInt(req.params.id);

    // Check if the note exists and is on hold
    const [noteCheck] = await db
      .select()
      .from(notes)
      .where(
        and(
          eq(notes.id, noteId),
          eq(notes.availability, 'on_hold')
        )
      )
      .execute();

    if (!noteCheck) {
      return res.status(404).json({ error: 'Note not found or not on hold' });
    }

    // Verify that the current user is either the seller or the buyer the note is held for
    if (noteCheck.sellerId !== req.user!.id && noteCheck.onHoldForBuyerId !== req.user!.id) {
      return res.status(403).json({ error: 'Only the seller or reserved buyer can release a hold' });
    }

    const now = new Date();

    // Update the note status back to available
    const [updatedNote] = await db
      .update(notes)
      .set({
        availability: 'available',
        onHoldUntil: null,
        onHoldForBuyerId: null,
        onHoldReason: null,
        updatedAt: now,
      })
      .where(eq(notes.id, noteId))
      .returning()
      .execute();

    // Record the transaction in history
    await db
      .insert(noteTransactionHistory)
      .values({
        noteId,
        status: 'available',
        reason: `Hold released by ${req.user!.id === noteCheck.sellerId ? 'seller' : 'buyer'}`,
        createdBy: req.user!.id,
      })
      .execute();

    res.status(200).json({
      message: 'Note successfully released from hold',
      note: updatedNote
    });
  } catch (error) {
    console.error('Error releasing note from hold:', error);
    res.status(500).json({ error: 'Failed to release note from hold' });
  }
});

// Complete a transaction (mark note as sold)
router.post('/complete-transaction', requireAuth, async (req, res) => {
  try {
    const validationResult = completeTransactionSchema.safeParse(req.body);
    if (!validationResult.success) {
      return res.status(400).json({
        message: 'Validation failed',
        errors: validationResult.error.errors
      });
    }

    const { noteId, buyerId, soldPrice } = validationResult.data;

    // Check if the note exists
    const [noteCheck] = await db
      .select()
      .from(notes)
      .where(eq(notes.id, noteId))
      .execute();

    if (!noteCheck) {
      return res.status(404).json({ error: 'Note not found' });
    }

    // Verify that the current user is the seller
    if (noteCheck.sellerId !== req.user!.id) {
      return res.status(403).json({ error: 'Only the seller can complete a transaction' });
    }

    const now = new Date();

    // Update the note status to sold
    const [updatedNote] = await db
      .update(notes)
      .set({
        availability: 'sold',
        soldDate: now,
        soldPrice: soldPrice || noteCheck.price,
        soldToUserId: buyerId,
        updatedAt: now,
      })
      .where(eq(notes.id, noteId))
      .returning()
      .execute();

    // Record the transaction in history
    await db
      .insert(noteTransactionHistory)
      .values({
        noteId,
        status: 'sold',
        buyerId,
        reason: `Note sold to buyer ${buyerId}`,
        createdBy: req.user!.id,
      })
      .execute();

    // TODO: Send notifications to the buyer

    res.status(200).json({
      message: 'Transaction successfully completed',
      note: updatedNote
    });
  } catch (error) {
    console.error('Error completing transaction:', error);
    res.status(500).json({ error: 'Failed to complete transaction' });
  }
});

// Get transaction history for a note
router.get('/:id/history', requireAuth, async (req, res) => {
  try {
    const noteId = parseInt(req.params.id);

    // Check if the note exists
    const [noteCheck] = await db
      .select()
      .from(notes)
      .where(eq(notes.id, noteId))
      .execute();

    if (!noteCheck) {
      return res.status(404).json({ error: 'Note not found' });
    }

    // Verify that the current user is either the seller or the buyer (if sold)
    const isSellerOrBuyer =
      noteCheck.sellerId === req.user!.id ||
      noteCheck.soldToUserId === req.user!.id ||
      noteCheck.onHoldForBuyerId === req.user!.id;

    if (!isSellerOrBuyer && req.user!.role !== 'admin') {
      return res.status(403).json({ error: 'Not authorized to view transaction history' });
    }

    // Get transaction history
    const history = await db
      .select()
      .from(noteTransactionHistory)
      .where(eq(noteTransactionHistory.noteId, noteId))
      .orderBy(desc(noteTransactionHistory.createdAt))
      .execute();

    res.json({ data: history });
  } catch (error) {
    console.error('Error fetching transaction history:', error);
    res.status(500).json({ error: 'Failed to fetch transaction history' });
  }
});

export default router;
