import { pgTable, serial, text, integer, decimal, boolean, timestamp, varchar, pgEnum, json, date } from 'drizzle-orm/pg-core';

// Enums
export const availabilityEnum = pgEnum('availability', ['available', 'pending_sale', 'on_hold', 'sold']);
export const listingTypeEnum = pgEnum('listing_type', ['single_asset', 'asset_pool']);
export const lienPositionEnum = pgEnum('lien_position', ['1st', '2nd']);
export const performanceEnum = pgEnum('performance', ['performing', 'non_performing']);
export const propertyTypeEnum = pgEnum('property_type', [
  'commercial',
  'condominium',
  'land',
  'multi_family',
  'single_family',
  'other',
]);
export const noteTypeEnum = pgEnum('note_type', [
  'deed_of_trust',
  'mortgage',
  'contract_for_deed',
  'community_lands',
  'texas_secured_notes',
  'other',
]);
export const stateTypeEnum = pgEnum('state_type', ['judicial', 'non_judicial']);
export const userRoleEnum = pgEnum('user_role', ['investor', 'seller', 'buyer', 'admin']);
export const userStatusEnum = pgEnum('user_status', ['active', 'inactive', 'pending', 'banned']);
export const notificationTypeEnum = pgEnum('notification_type', [
  'new_listing',
  'buyer_inquiry',
  'account_update',
  'system_message',
]);
export const activityTypeEnum = pgEnum('activity_type', [
  'login',
  'logout',
  'profile_update',
  'password_change',
  'listing_view',
  'listing_create',
  'listing_update',
  'listing_delete',
  'search',
  'document_upload',
  'document_download',
  'account_settings_change',
]);
export const inquiryStatusEnum = pgEnum('inquiry_status', [
  'new',
  'viewed',
  'replied',
  'closed',
]);

// Notification frequency type
export const notificationFrequencyEnum = pgEnum('notification_frequency', ['instant', 'daily', 'weekly']);

// Users table
export const users = pgTable('users', {
  id: serial('id').primaryKey(),
  email: varchar('email', { length: 255 }).notNull().unique(),
  passwordHash: varchar('password_hash', { length: 255 }).notNull(),
  firstName: varchar('first_name', { length: 100 }).notNull(),
  lastName: varchar('last_name', { length: 100 }).notNull(),
  companyName: varchar('company_name', { length: 255 }),
  phoneNumber: varchar('phone_number', { length: 20 }),
  profileImageUrl: varchar('profile_image_url', { length: 255 }),
  bio: text('bio'),
  address: varchar('address', { length: 255 }),
  city: varchar('city', { length: 100 }),
  state: varchar('state', { length: 50 }),
  zipCode: varchar('zip_code', { length: 20 }),
  role: userRoleEnum('role').default('investor').notNull(),
  status: userStatusEnum('status').default('pending').notNull(),
  lastLogin: timestamp('last_login'),
  verificationToken: varchar('verification_token', { length: 255 }),
  verificationTokenExpiry: timestamp('verification_token_expiry'),
  resetPasswordToken: varchar('reset_password_token', { length: 255 }),
  resetPasswordTokenExpiry: timestamp('reset_password_token_expiry'),
  twoFactorEnabled: boolean('two_factor_enabled').default(false),
  twoFactorSecret: varchar('two_factor_secret', { length: 255 }),
  tosAccepted: boolean('tos_accepted').default(false),
  tosAcceptedDate: timestamp('tos_accepted_date'),
  isEmailVerified: boolean('is_email_verified').default(false),
  emailVerifiedAt: timestamp('email_verified_at'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

// User notification preferences
export const notificationPreferences = pgTable('notification_preferences', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id).notNull(),
  notificationType: notificationTypeEnum('notification_type').notNull(),
  email: boolean('email').default(true),
  inApp: boolean('in_app').default(true),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

// User notifications
export const notifications = pgTable('notifications', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id).notNull(),
  type: notificationTypeEnum('type').notNull(),
  title: varchar('title', { length: 255 }).notNull(),
  message: text('message').notNull(),
  isRead: boolean('is_read').default(false),
  relatedEntityType: varchar('related_entity_type', { length: 50 }),
  relatedEntityId: integer('related_entity_id'),
  data: json('data'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

// User activity logs
export const activityLogs = pgTable('activity_logs', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id).notNull(),
  activityType: activityTypeEnum('activity_type').notNull(),
  details: text('details'),
  ipAddress: varchar('ip_address', { length: 50 }),
  userAgent: varchar('user_agent', { length: 255 }),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

// Authentication tokens (for JWT refresh)
export const authTokens = pgTable('auth_tokens', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id).notNull(),
  token: varchar('token', { length: 255 }).notNull().unique(),
  expiresAt: timestamp('expires_at').notNull(),
  isRevoked: boolean('is_revoked').default(false),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

// Note listings table
export const notes = pgTable('notes', {
  id: serial('id').primaryKey(),
  sellerId: integer('seller_id').references(() => users.id).notNull(),
  title: varchar('title', { length: 255 }).notNull(),
  description: text('description').notNull(),

  // Basic note details
  price: decimal('price', { precision: 12, scale: 2 }).notNull(),
  originalAmount: decimal('original_amount', { precision: 12, scale: 2 }),
  remainingBalance: decimal('remaining_balance', { precision: 12, scale: 2 }),
  monthlyPayment: decimal('monthly_payment', { precision: 10, scale: 2 }),
  interestRate: decimal('interest_rate', { precision: 5, scale: 3 }),
  loanTerm: integer('loan_term_months'), // Term in months
  loanOriginationDate: date('loan_origination_date'),
  paymentsMade: integer('payments_made'),
  remainingPayments: integer('remaining_payments'),
  nextPaymentDue: date('next_payment_due'),
  balloonPayment: decimal('balloon_payment', { precision: 12, scale: 2 }),
  balloonDate: date('balloon_date'),
  servicerName: varchar('servicer_name', { length: 255 }),
  isPaperOnly: boolean('is_paper_only').default(false), // No electronic records

  // Pricing options
  isBestOffer: boolean('is_best_offer').default(false),
  isFirmPrice: boolean('is_firm_price').default(false),
  minimumInvestment: decimal('minimum_investment', { precision: 12, scale: 2 }),
  partialInvestmentAllowed: boolean('partial_investment_allowed').default(false),

  // Classification
  noteType: noteTypeEnum('note_type').notNull(),
  lienPosition: lienPositionEnum('lien_position').notNull(),
  performance: performanceEnum('performance').notNull(),
  listingType: listingTypeEnum('listing_type').default('single_asset'),
  availability: availabilityEnum('availability').default('available'),

  // Time-limited offer fields
  onHoldUntil: timestamp('on_hold_until'),
  onHoldForBuyerId: integer('on_hold_for_buyer_id').references(() => users.id),
  onHoldReason: varchar('on_hold_reason', { length: 255 }),

  // Financial metrics
  yield: decimal('yield', { precision: 5, scale: 2 }),
  itb: decimal('itb', { precision: 5, scale: 2 }),
  itv: decimal('itv', { precision: 5, scale: 2 }),
  ltv: decimal('ltv', { precision: 5, scale: 2 }),

  // Borrower information (masked/anonymous)
  borrowerCreditScore: varchar('borrower_credit_score', { length: 50 }),
  borrowerOccupancyType: varchar('borrower_occupancy_type', { length: 50 }),
  borrowerBackgroundInfo: text('borrower_background_info'),

  // Property details
  propertyType: propertyTypeEnum('property_type').notNull(),
  propertyAddress: varchar('property_address', { length: 255 }),
  propertyCity: varchar('property_city', { length: 100 }),
  propertyState: varchar('property_state', { length: 50 }),
  propertyZip: varchar('property_zip', { length: 20 }),
  propertyCounty: varchar('property_county', { length: 100 }),
  propertySquareFeet: integer('property_square_feet'),
  propertyBedrooms: integer('property_bedrooms'),
  propertyBathrooms: decimal('property_bathrooms', { precision: 3, scale: 1 }),
  propertyAcres: decimal('property_acres', { precision: 10, scale: 2 }),
  propertyBuildYear: integer('property_build_year'),
  propertyCondition: varchar('property_condition', { length: 50 }),
  propertyValue: decimal('property_value', { precision: 12, scale: 2 }),
  propertyValueSource: varchar('property_value_source', { length: 100 }),
  propertyValueDate: date('property_value_date'),
  propertyAppraisedValue: decimal('property_appraised_value', { precision: 12, scale: 2 }),
  propertyAppraisalDate: date('property_appraisal_date'),
  propertyTaxAssessedValue: decimal('property_tax_assessed_value', { precision: 12, scale: 2 }),

  // Foreclosure status
  hasForeclosure: boolean('has_foreclosure').default(false),
  stateType: stateTypeEnum('state_type'),
  foreclosureStatus: varchar('foreclosure_status', { length: 100 }),
  foreclosureStartDate: date('foreclosure_start_date'),

  // Due diligence information
  dueDiligenceDocs: json('due_diligence_docs'), // Array of document IDs or URLs
  hasAppraisal: boolean('has_appraisal').default(false),
  hasBrokerPriceOpinion: boolean('has_broker_price_opinion').default(false),
  hasTitle: boolean('has_title').default(false),
  hasInsurance: boolean('has_insurance').default(false),

  // Images
  mainImageUrl: varchar('main_image_url', { length: 255 }),

  // Analytics
  viewCount: integer('view_count').default(0),
  favoriteCount: integer('favorite_count').default(0),
  inquiryCount: integer('inquiry_count').default(0),

  // Timestamps and audit fields
  listedDate: timestamp('listed_date').defaultNow().notNull(),
  lastUpdatedDate: timestamp('last_updated_date').defaultNow().notNull(),
  expirationDate: timestamp('expiration_date'),
  soldDate: timestamp('sold_date'),
  soldPrice: decimal('sold_price', { precision: 12, scale: 2 }),
  soldToUserId: integer('sold_to_user_id').references(() => users.id),

  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

// Note images
export const noteImages = pgTable('note_images', {
  id: serial('id').primaryKey(),
  noteId: integer('note_id').references(() => notes.id).notNull(),
  imageUrl: varchar('image_url', { length: 255 }).notNull(),
  displayOrder: integer('display_order').default(0),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

// User favorite notes
export const userFavorites = pgTable('user_favorites', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id).notNull(),
  noteId: integer('note_id').references(() => notes.id).notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

// Buyer inquiries
export const inquiries = pgTable('inquiries', {
  id: serial('id').primaryKey(),
  buyerId: integer('buyer_id').references(() => users.id).notNull(),
  noteId: integer('note_id').references(() => notes.id).notNull(),
  subject: varchar('subject', { length: 255 }).notNull(),
  message: text('message').notNull(),
  status: inquiryStatusEnum('status').default('new').notNull(),
  isRead: boolean('is_read').default(false),
  phoneNumberRequested: boolean('phone_number_requested').default(false),
  phoneNumberRevealed: boolean('phone_number_revealed').default(false),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

// Inquiry replies
export const inquiryReplies = pgTable('inquiry_replies', {
  id: serial('id').primaryKey(),
  inquiryId: integer('inquiry_id').references(() => inquiries.id).notNull(),
  userId: integer('user_id').references(() => users.id).notNull(),
  message: text('message').notNull(),
  isRead: boolean('is_read').default(false),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

// Saved searches (for user notifications)
export const savedSearches = pgTable('saved_searches', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id).notNull(),
  name: varchar('name', { length: 100 }).notNull(),

  // Sharing settings
  isPublic: boolean('is_public').default(false),
  shareToken: varchar('share_token', { length: 64 }),

  // Notification settings
  isEmailEnabled: boolean('is_email_enabled').default(false),
  notificationFrequency: notificationFrequencyEnum('notification_frequency').default('daily'),
  lastNotificationSentAt: timestamp('last_notification_sent_at'),

  // Search filters
  noteType: noteTypeEnum('note_type'),
  lienPosition: lienPositionEnum('lien_position'),
  performance: performanceEnum('performance'),
  listingType: listingTypeEnum('listing_type'),

  minPrice: decimal('min_price', { precision: 12, scale: 2 }),
  maxPrice: decimal('max_price', { precision: 12, scale: 2 }),

  minYield: decimal('min_yield', { precision: 5, scale: 2 }),
  maxYield: decimal('max_yield', { precision: 5, scale: 2 }),

  minLtv: decimal('min_ltv', { precision: 5, scale: 2 }),
  maxLtv: decimal('max_ltv', { precision: 5, scale: 2 }),

  minInterestRate: decimal('min_interest_rate', { precision: 5, scale: 2 }),
  maxInterestRate: decimal('max_interest_rate', { precision: 5, scale: 2 }),

  propertyType: propertyTypeEnum('property_type'),
  propertyState: varchar('property_state', { length: 50 }),
  stateType: stateTypeEnum('state_type'),

  hasForeclosure: boolean('has_foreclosure'),

  // Legacy notification settings - keeping for backward compatibility
  isNotificationEnabled: boolean('is_notification_enabled').default(true),

  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

// Document templates (for contracts)
export const documentTemplates = pgTable('document_templates', {
  id: serial('id').primaryKey(),
  name: varchar('name', { length: 100 }).notNull(),
  description: text('description'),
  documentUrl: varchar('document_url', { length: 255 }).notNull(),
  isDefault: boolean('is_default').default(false),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

// User documents
export const userDocuments = pgTable('user_documents', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id).notNull(),
  noteId: integer('note_id').references(() => notes.id),
  name: varchar('name', { length: 255 }).notNull(),
  description: text('description'),
  documentUrl: varchar('document_url', { length: 255 }).notNull(),
  documentType: varchar('document_type', { length: 50 }).notNull(),
  fileSize: integer('file_size').notNull(),
  mimeType: varchar('mime_type', { length: 100 }).notNull(),
  isPublic: boolean('is_public').default(false),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

// New table for shared search views (to track usage analytics)
export const sharedSearchViews = pgTable('shared_search_views', {
  id: serial('id').primaryKey(),
  searchId: integer('search_id').references(() => savedSearches.id).notNull(),
  viewerIp: varchar('viewer_ip', { length: 50 }),
  userAgent: varchar('user_agent', { length: 255 }),
  referrer: varchar('referrer', { length: 255 }),
  viewedAt: timestamp('viewed_at').defaultNow().notNull(),
});

// New table for transaction status history
export const noteTransactionHistory = pgTable('note_transaction_history', {
  id: serial('id').primaryKey(),
  noteId: integer('note_id').references(() => notes.id).notNull(),
  status: availabilityEnum('status').notNull(),
  buyerId: integer('buyer_id').references(() => users.id),
  reason: varchar('reason', { length: 255 }),
  expiresAt: timestamp('expires_at'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  createdBy: integer('created_by').references(() => users.id).notNull(),
});

// Add usage analytics for saved searches
export const savedSearchAnalytics = pgTable('saved_search_analytics', {
  id: serial('id').primaryKey(),
  searchId: integer('search_id').references(() => savedSearches.id).notNull(),
  userId: integer('user_id').references(() => users.id).notNull(),
  action: varchar('action', { length: 50 }).notNull(), // e.g., 'view', 'execute', 'create_alert', 'modify'
  countMatches: integer('count_matches'), // Number of matches found when search is executed
  executionTimeMs: integer('execution_time_ms'), // Time taken to execute the search
  ipAddress: varchar('ip_address', { length: 50 }),
  userAgent: varchar('user_agent', { length: 255 }),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});
