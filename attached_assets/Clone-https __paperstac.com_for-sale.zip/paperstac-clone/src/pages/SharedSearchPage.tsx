import { useEffect, useState } from 'react';
import { useRoute } from 'wouter';
import Layout from '../components/layout/Layout';
import NoteCard from '../components/notes/NoteCard';
import Pagination from '../components/ui/Pagination';
import SearchExport from '../components/notes/SearchExport';
import { useSavedSearches } from '../hooks/useSavedSearches';
import { useNotes } from '../hooks/useNotes';
import { FilterState, Note } from '../types';
import { useFilters } from '../hooks/useFilters';

const SharedSearchPage = () => {
  const [, params] = useRoute('/shared-search/:token');
  const token = params?.token || '';

  const [error, setError] = useState<string | null>(null);
  const [searchName, setSearchName] = useState<string>('');

  // Initialize filter hooks
  const {
    filters,
    pagination,
    queryParams,
    updateFilters,
    updatePage,
  } = useFilters({
    initialPage: 1,
    initialLimit: 12,
  });

  // Get the shared search
  const { useSharedSearch, applySavedSearch } = useSavedSearches();
  const {
    data: sharedSearch,
    isLoading: isLoadingSearch,
    isError: isErrorSearch,
    error: searchError,
  } = useSharedSearch(token);

  // Fetch notes based on the search filters
  const {
    notes,
    isLoading: isLoadingNotes,
    isError: isErrorNotes,
    pagination: resultPagination,
    fetchAllNotes,
  } = useNotes(queryParams);

  // Apply the shared search filters when they load
  useEffect(() => {
    if (sharedSearch) {
      const newFilters = applySavedSearch(sharedSearch);
      updateFilters(newFilters);
      setSearchName(sharedSearch.name);
    }
  }, [sharedSearch, applySavedSearch, updateFilters]);

  // Handle errors
  useEffect(() => {
    if (isErrorSearch && searchError) {
      setError('The shared search could not be found or has been deleted.');
    } else if (isErrorNotes) {
      setError('Failed to load notes for this search.');
    } else {
      setError(null);
    }
  }, [isErrorSearch, searchError, isErrorNotes]);

  const isLoading = isLoadingSearch || isLoadingNotes;

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        <h1 className="mb-2 text-3xl font-bold">Shared Search</h1>

        {searchName && (
          <p className="mb-6 text-lg text-gray-600">
            "{searchName}"
          </p>
        )}

        {/* Error state */}
        {error && (
          <div className="mb-6 rounded-lg bg-red-50 p-6 text-center">
            <h3 className="text-lg font-semibold text-red-800">Something went wrong</h3>
            <p className="mt-2 text-red-700">
              {error}
            </p>
          </div>
        )}

        {/* Loading state */}
        {isLoading && !error && (
          <div className="my-12 flex justify-center">
            <div className="h-12 w-12 animate-spin rounded-full border-4 border-blue-600 border-t-transparent"></div>
          </div>
        )}

        {/* Results */}
        {!isLoading && !error && (
          <div className="mt-6">
            <div className="flex flex-col gap-8 lg:flex-row">
              {/* Sidebar with export */}
              <div className="w-full lg:w-1/4">
                <div className="mb-4 rounded-lg border border-gray-200 bg-white p-4 shadow-sm">
                  <h3 className="mb-2 font-medium">About this shared search</h3>
                  <p className="mb-4 text-sm text-gray-600">
                    This is a search filter that someone has shared with you.
                    You can view the results and export them if needed.
                  </p>

                  {sharedSearch && (
                    <div className="space-y-2 rounded-md bg-gray-50 p-3 text-sm">
                      <div>
                        <span className="font-medium">Created by:</span> {sharedSearch.userId}
                      </div>
                      <div>
                        <span className="font-medium">Created:</span> {new Date(sharedSearch.createdAt).toLocaleDateString()}
                      </div>
                      <div>
                        <span className="font-medium">Updated:</span> {new Date(sharedSearch.updatedAt).toLocaleDateString()}
                      </div>
                    </div>
                  )}
                </div>

                {/* Export component */}
                {notes.length > 0 && (
                  <SearchExport
                    notes={notes}
                    totalCount={resultPagination?.totalCount || 0}
                    onExportAll={fetchAllNotes}
                    isLoading={isLoading}
                  />
                )}
              </div>

              {/* Main content */}
              <div className="w-full lg:w-3/4">
                {/* Empty state */}
                {!isLoading && notes.length === 0 && (
                  <div className="rounded-lg bg-gray-50 p-6 text-center">
                    <h3 className="text-lg font-semibold text-gray-800">No notes found</h3>
                    <p className="mt-2 text-gray-600">
                      This search doesn't match any current listings.
                    </p>
                  </div>
                )}

                {/* Notes grid */}
                {notes.length > 0 && (
                  <>
                    <div className="mb-4 flex items-center justify-between">
                      <p className="text-sm text-gray-600">
                        {resultPagination?.totalCount || 0} listings found
                      </p>
                    </div>

                    <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
                      {notes.map((note: Note) => (
                        <NoteCard key={note.id} note={note} />
                      ))}
                    </div>

                    {/* Pagination */}
                    {resultPagination && resultPagination.totalPages > 1 && (
                      <div className="mt-6">
                        <Pagination
                          currentPage={pagination.page}
                          totalPages={resultPagination.totalPages}
                          onPageChange={updatePage}
                        />
                      </div>
                    )}
                  </>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
};

export default SharedSearchPage;
