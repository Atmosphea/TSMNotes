import { useRoute, Link } from 'wouter';
import DashboardLayout from '../../components/layout/DashboardLayout';
import InquiryDetailsCard from '../../components/inquiries/InquiryDetailsCard';
import NoteTransactionActions from '../../components/notes/NoteTransactionActions';
import NoteTransactionHistory from '../../components/notes/NoteTransactionHistory';
import { useInquiry } from '../../hooks/useInquiries';
import { useNoteTransactionHistory } from '../../hooks/useNoteTransactions';
import { useAuth } from '../../context/AuthContext';

const InquiryDetailPage = () => {
  const [match, params] = useRoute<{ id: string }>('/dashboard/inquiries/:id');
  const inquiryId = params?.id ? parseInt(params.id, 10) : 0;
  const { user } = useAuth();

  const { inquiry, isLoading, isError, refetch } = useInquiry(inquiryId);
  const noteId = inquiry?.note?.id;
  const { history, isLoading: isLoadingHistory } = useNoteTransactionHistory(noteId || 0);

  const isSeller = user?.id === inquiry?.note?.sellerId;
  const buyerUser = inquiry?.buyer;

  return (
    <DashboardLayout>
      <div className="container mx-auto py-6 px-4">
        <div className="mb-6">
          <Link
            href="/dashboard/inquiries"
            className="inline-flex items-center text-sm text-blue-600 hover:text-blue-800"
          >
            <svg
              className="mr-2 h-4 w-4"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M10 19l-7-7m0 0l7-7m-7 7h18"
              />
            </svg>
            Back to All Inquiries
          </Link>
        </div>

        <div className="mb-6 flex items-center justify-between">
          <h1 className="text-2xl font-bold text-gray-900">Inquiry Details</h1>
        </div>

        <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
          <div className="lg:col-span-2 space-y-6">
            {isLoading ? (
              <div className="flex h-64 items-center justify-center">
                <div className="h-8 w-8 animate-spin rounded-full border-b-2 border-blue-600"></div>
              </div>
            ) : isError ? (
              <div className="rounded-lg bg-red-50 p-4 text-center">
                <h3 className="mb-2 text-lg font-medium text-red-800">Error loading inquiry</h3>
                <p className="text-red-700">
                  We couldn't load this inquiry. It might not exist or you don't have permission to view it.
                </p>
                <button
                  onClick={() => refetch()}
                  className="mt-4 rounded-md bg-red-100 px-4 py-2 font-medium text-red-800 hover:bg-red-200"
                >
                  Try Again
                </button>
              </div>
            ) : inquiry ? (
              <InquiryDetailsCard inquiry={inquiry} onReplySuccess={refetch} />
            ) : (
              <div className="rounded-lg bg-gray-50 p-4 text-center">
                <p className="text-gray-700">No inquiry found with ID: {inquiryId}</p>
              </div>
            )}

            {noteId && (
              <div className="mt-6">
                <NoteTransactionHistory history={history} isLoading={isLoadingHistory} />
              </div>
            )}
          </div>

          <div>
            {inquiry?.note && isSeller && buyerUser && (
              <div className="sticky top-6 space-y-4">
                <div className="rounded-lg border border-gray-200 bg-white p-5 shadow-sm">
                  <h3 className="mb-4 text-lg font-medium text-gray-900">Transaction Options</h3>
                  <NoteTransactionActions
                    note={inquiry.note}
                    buyer={buyerUser}
                    onSuccess={refetch}
                  />
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
};

export default InquiryDetailPage;
