import { useState } from 'react';
import DashboardLayout from '../../components/layout/DashboardLayout';
import InquiriesList from '../../components/inquiries/InquiriesList';
import { useInquiries } from '../../hooks/useInquiries';

const InquiriesPage = () => {
  const [activeTab, setActiveTab] = useState<'sent' | 'received'>('sent');
  const sentInquiries = useInquiries('buyer');
  const receivedInquiries = useInquiries('seller');

  const isLoading = activeTab === 'sent' ? sentInquiries.isLoading : receivedInquiries.isLoading;
  const inquiries = activeTab === 'sent' ? sentInquiries.inquiries : receivedInquiries.inquiries;

  return (
    <DashboardLayout>
      <div className="container mx-auto py-6 px-4">
        <div className="mb-6 flex items-center justify-between">
          <h1 className="text-2xl font-bold text-gray-900">Messages</h1>
        </div>

        <div className="mb-6">
          <div className="mb-4 border-b border-gray-200">
            <nav className="-mb-px flex space-x-8">
              <button
                onClick={() => setActiveTab('sent')}
                className={`inline-flex items-center border-b-2 py-4 px-1 text-sm font-medium ${
                  activeTab === 'sent'
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700'
                }`}
              >
                <span>Sent</span>
                {sentInquiries.inquiries.length > 0 && (
                  <span className="ml-3 rounded-full bg-gray-100 px-2.5 py-0.5 text-xs font-medium text-gray-900">
                    {sentInquiries.inquiries.length}
                  </span>
                )}
              </button>

              <button
                onClick={() => setActiveTab('received')}
                className={`inline-flex items-center border-b-2 py-4 px-1 text-sm font-medium ${
                  activeTab === 'received'
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700'
                }`}
              >
                <span>Received</span>
                {receivedInquiries.inquiries.length > 0 && (
                  <span className="ml-3 rounded-full bg-gray-100 px-2.5 py-0.5 text-xs font-medium text-gray-900">
                    {receivedInquiries.inquiries.length}
                  </span>
                )}
              </button>
            </nav>
          </div>

          <InquiriesList
            inquiries={inquiries}
            role={activeTab === 'sent' ? 'buyer' : 'seller'}
            isLoading={isLoading}
          />
        </div>
      </div>
    </DashboardLayout>
  );
};

export default InquiriesPage;
