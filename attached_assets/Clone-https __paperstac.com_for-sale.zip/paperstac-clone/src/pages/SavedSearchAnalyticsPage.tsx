import { useRoute, Link } from 'wouter';
import DashboardLayout from '../components/layout/DashboardLayout';
import { useSavedSearch } from '../hooks/useSavedSearches';
import SavedSearchAnalytics from '../components/notes/SavedSearchAnalytics';

const SavedSearchAnalyticsPage = () => {
  const [match, params] = useRoute<{ id: string }>('/dashboard/saved-searches/:id/analytics');
  const searchId = params?.id ? parseInt(params.id, 10) : 0;

  const { data: savedSearch, isLoading, isError } = useSavedSearch(searchId);

  return (
    <DashboardLayout>
      <div className="container mx-auto px-4 py-6">
        <div className="mb-6">
          <Link
            href="/dashboard/saved-searches"
            className="inline-flex items-center text-sm text-blue-600 hover:text-blue-800"
          >
            <svg
              className="mr-2 h-4 w-4"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M10 19l-7-7m0 0l7-7m-7 7h18"
              />
            </svg>
            Back to Saved Searches
          </Link>
        </div>

        {isLoading ? (
          <div className="flex h-64 items-center justify-center">
            <div className="h-8 w-8 animate-spin rounded-full border-b-2 border-blue-600"></div>
          </div>
        ) : isError ? (
          <div className="rounded-lg bg-red-50 p-4 text-center">
            <h3 className="mb-2 text-lg font-medium text-red-800">Error</h3>
            <p className="text-red-700">Failed to load saved search data.</p>
          </div>
        ) : savedSearch ? (
          <>
            <div className="mb-6 flex items-center justify-between">
              <h1 className="text-2xl font-bold text-gray-900">
                {savedSearch.name} <span className="ml-2 text-lg font-medium text-gray-500">Analytics</span>
              </h1>

              <div className="flex space-x-3">
                <Link
                  href={`/for-sale?search=${searchId}`}
                  className="rounded-lg bg-blue-100 px-4 py-2 font-medium text-blue-700 hover:bg-blue-200"
                >
                  Run Search
                </Link>
                <Link
                  href={`/dashboard/saved-searches/${searchId}/edit`}
                  className="rounded-lg bg-gray-100 px-4 py-2 font-medium text-gray-700 hover:bg-gray-200"
                >
                  Edit Search
                </Link>
              </div>
            </div>

            <SavedSearchAnalytics searchId={searchId} />
          </>
        ) : (
          <div className="rounded-lg bg-gray-50 p-4 text-center">
            <p className="text-gray-700">No saved search found with ID: {searchId}</p>
          </div>
        )}
      </div>
    </DashboardLayout>
  );
};

export default SavedSearchAnalyticsPage;
