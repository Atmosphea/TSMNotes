import { useRoute, Link } from 'wouter';
import Layout from '../components/layout/Layout';
import { useNote } from '../hooks/useNotes';
import { formatNoteType, formatPercentage, formatPrice, formatPriceLabel, formatPropertyType } from '../utils/formatters';
import { Note } from '../types';
import ContactSellerForm from '../components/notes/ContactSellerForm';
import { useState } from 'react';

const NoteDetailsPage = () => {
  const [match, params] = useRoute<{ id: string }>('/note/:id');
  const id = params?.id ? parseInt(params.id, 10) : 0;
  const [showMakeOffer, setShowMakeOffer] = useState(false);

  const { data: noteData, isLoading, isError } = useNote(id);

  if (isLoading) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-12">
          <div className="flex h-64 items-center justify-center">
            <div className="h-8 w-8 animate-spin rounded-full border-b-2 border-blue-600"></div>
          </div>
        </div>
      </Layout>
    );
  }

  if (isError || !noteData) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-12">
          <div className="rounded-lg bg-red-50 p-6 text-center">
            <h3 className="text-lg font-semibold text-red-800">Note not found</h3>
            <p className="mt-2 text-red-700">
              The note you're looking for doesn't exist or has been removed.
            </p>
            <Link href="/for-sale" className="mt-4 inline-block rounded-md bg-blue-600 px-4 py-2 font-medium text-white hover:bg-blue-700">
              Back to Notes For Sale
            </Link>
          </div>
        </div>
      </Layout>
    );
  }

  // Cast to Note type and provide default values
  const note = noteData as Note;

  const {
    title,
    description,
    price,
    isBestOffer,
    isFirmPrice,
    noteType,
    lienPosition,
    performance,
    yield: yieldValue,
    itb,
    itv,
    ltv,
    propertyType,
    mainImageUrl,
    hasForeclosure
  } = note;

  // These properties might not exist, access them safely
  const propertyAddress = (note as any).propertyAddress;
  const propertyCity = (note as any).propertyCity;
  const propertyState = (note as any).propertyState;
  const propertyZip = (note as any).propertyZip;
  const propertySquareFeet = (note as any).propertySquareFeet;
  const propertyBedrooms = (note as any).propertyBedrooms;
  const propertyBathrooms = (note as any).propertyBathrooms;
  const propertyAcres = (note as any).propertyAcres;
  const propertyValue = (note as any).propertyValue;
  const stateType = (note as any).stateType;

  // Format values for display
  const formattedPrice = formatPriceLabel(price, isBestOffer, isFirmPrice);
  const formattedYield = yieldValue !== null && yieldValue !== undefined ? formatPercentage(yieldValue) : 'N/A';
  const formattedITB = itb !== null && itb !== undefined ? formatPercentage(itb) : 'N/A';
  const formattedITV = itv !== null && itv !== undefined ? formatPercentage(itv) : 'N/A';
  const formattedLTV = ltv !== null && ltv !== undefined ? formatPercentage(ltv) : 'N/A';
  const formattedNoteType = formatNoteType(noteType);
  const formattedPropertyType = propertyType ? formatPropertyType(propertyType) : 'N/A';
  const formattedPropertyValue = propertyValue ? formatPrice(propertyValue) : 'N/A';

  // For display in address section
  const fullAddress = [
    propertyAddress,
    propertyCity && propertyState ? `${propertyCity}, ${propertyState}` : propertyCity || propertyState,
    propertyZip,
  ]
    .filter(Boolean)
    .join(', ');

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        <div className="mb-6">
          <Link href="/for-sale" className="flex items-center text-sm text-blue-600 hover:text-blue-800">
            <svg
              className="mr-2 h-4 w-4"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M10 19l-7-7m0 0l7-7m-7 7h18"
              />
            </svg>
            Back to Notes For Sale
          </Link>
        </div>

        <div className="grid grid-cols-1 gap-12 lg:grid-cols-3">
          {/* Left column: Image and details */}
          <div className="lg:col-span-2">
            <div className="overflow-hidden rounded-lg">
              {mainImageUrl ? (
                <img
                  src={mainImageUrl}
                  alt={title}
                  className="h-auto w-full object-cover"
                />
              ) : (
                <div className="flex h-96 w-full items-center justify-center bg-gray-200 text-gray-400">
                  No Image Available
                </div>
              )}
            </div>

            {/* Property details section */}
            <div className="mt-8">
              <h2 className="mb-4 text-xl font-bold">Property Details</h2>
              <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
                <div className="rounded-lg border border-gray-200 p-4">
                  <h3 className="mb-2 text-lg font-semibold">Location</h3>
                  {fullAddress ? (
                    <p>{fullAddress}</p>
                  ) : (
                    <p className="text-gray-500">Address not provided</p>
                  )}
                </div>

                <div className="rounded-lg border border-gray-200 p-4">
                  <h3 className="mb-2 text-lg font-semibold">Property Specifications</h3>
                  <ul className="space-y-1">
                    <li>
                      <span className="font-medium">Type:</span> {formattedPropertyType}
                    </li>
                    {propertySquareFeet && (
                      <li>
                        <span className="font-medium">Square Feet:</span> {propertySquareFeet.toLocaleString()}
                      </li>
                    )}
                    {propertyBedrooms && (
                      <li>
                        <span className="font-medium">Bedrooms:</span> {propertyBedrooms}
                      </li>
                    )}
                    {propertyBathrooms && (
                      <li>
                        <span className="font-medium">Bathrooms:</span> {propertyBathrooms}
                      </li>
                    )}
                    {propertyAcres && (
                      <li>
                        <span className="font-medium">Acreage:</span> {propertyAcres}
                      </li>
                    )}
                    {propertyValue && (
                      <li>
                        <span className="font-medium">Estimated Value:</span> {formattedPropertyValue}
                      </li>
                    )}
                  </ul>
                </div>
              </div>
            </div>

            {/* Note description */}
            <div className="mt-8">
              <h2 className="mb-4 text-xl font-bold">Note Description</h2>
              <div className="rounded-lg border border-gray-200 p-6">
                <p className="whitespace-pre-line text-gray-700">{description}</p>
              </div>
            </div>
          </div>

          {/* Right column: Price and metrics */}
          <div>
            <div className="sticky top-6 rounded-lg border border-gray-200 bg-white p-6 shadow-sm">
              <div className="mb-4 border-b border-gray-100 pb-4">
                <h1 className="mb-2 text-2xl font-bold">{title}</h1>
                <div className="mb-2 flex flex-wrap items-center gap-2">
                  <span className="rounded-full bg-blue-100 px-3 py-1 text-xs font-semibold text-blue-800">
                    {formattedNoteType}
                  </span>
                  <span className="rounded-full bg-gray-100 px-3 py-1 text-xs font-semibold text-gray-800">
                    {lienPosition} Lien
                  </span>
                  <span className="rounded-full bg-gray-100 px-3 py-1 text-xs font-semibold text-gray-800">
                    {performance === 'performing' ? 'Performing' : 'Non-Performing'}
                  </span>
                </div>
                {hasForeclosure && (
                  <div className="mb-2">
                    <span className="rounded-full bg-yellow-100 px-3 py-1 text-xs font-semibold text-yellow-800">
                      Foreclosure
                    </span>
                    {stateType && (
                      <span className="ml-2 text-xs text-gray-600">
                        ({stateType === 'judicial' ? 'Judicial State' : 'Non-Judicial State'})
                      </span>
                    )}
                  </div>
                )}
              </div>

              <div className="mb-6">
                <div className="mb-2 text-3xl font-bold">{formattedPrice}</div>
              </div>

              <div className="mb-6 grid grid-cols-2 gap-4">
                <div className="rounded-lg bg-gray-50 p-3 text-center">
                  <div className="text-sm text-gray-500">Yield</div>
                  <div className="text-lg font-bold">{formattedYield}</div>
                </div>
                <div className="rounded-lg bg-gray-50 p-3 text-center">
                  <div className="text-sm text-gray-500">ITB</div>
                  <div className="text-lg font-bold">{formattedITB}</div>
                </div>
                <div className="rounded-lg bg-gray-50 p-3 text-center">
                  <div className="text-sm text-gray-500">ITV</div>
                  <div className="text-lg font-bold">{formattedITV}</div>
                </div>
                <div className="rounded-lg bg-gray-50 p-3 text-center">
                  <div className="text-sm text-gray-500">LTV</div>
                  <div className="text-lg font-bold">{formattedLTV}</div>
                </div>
              </div>

              <div className="space-y-3">
                <ContactSellerForm noteId={id} />

                {isBestOffer && (
                  <button
                    onClick={() => setShowMakeOffer(prev => !prev)}
                    className="w-full rounded-lg border border-blue-600 py-3 font-semibold text-blue-600 hover:bg-blue-50"
                  >
                    Make an Offer
                  </button>
                )}
              </div>

              {/* Make Offer Form */}
              {showMakeOffer && isBestOffer && (
                <div className="mt-4 border-t border-gray-100 pt-4">
                  <ContactSellerForm
                    noteId={id}
                    onSuccess={() => setShowMakeOffer(false)}
                  />
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default NoteDetailsPage;
