import Layout from '../components/layout/Layout';
import FilterSidebar from '../components/notes/FilterSidebar';
import NoteCard from '../components/notes/NoteCard';
import Pagination from '../components/ui/Pagination';
import SearchExport from '../components/notes/SearchExport';
import { useFilters } from '../hooks/useFilters';
import { useNotes } from '../hooks/useNotes';
import { FilterState, Note } from '../types';

const ForSalePage = () => {
  // Initialize filter state
  const {
    filters,
    pagination,
    queryParams,
    updateFilter,
    updateFilters,  // Added for applying saved searches
    resetFilters,
    updatePage,
  } = useFilters({
    initialFilters: {
      availability: 'available',
    },
    initialPage: 1,
    initialLimit: 12,
  });

  // Fetch notes data
  const {
    notes,
    isLoading,
    isError,
    pagination: resultPagination,
    fetchAllNotes,
  } = useNotes(queryParams);

  // Handle applying a saved search (all filters at once)
  const handleUpdateFilters = (newFilters: FilterState) => {
    updateFilters(newFilters);
  };

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        <h1 className="mb-8 text-3xl font-bold">Mortgage Notes For Sale</h1>

        <div className="flex flex-col gap-8 lg:flex-row">
          {/* Sidebar */}
          <div className="w-full lg:w-1/4">
            <FilterSidebar
              filters={filters}
              onFilterChange={updateFilter}
              onFilterReset={resetFilters}
              onUpdateFilters={handleUpdateFilters}
            />

            {/* Export component */}
            {!isLoading && !isError && notes.length > 0 && (
              <SearchExport
                notes={notes}
                totalCount={resultPagination?.totalCount || 0}
                onExportAll={fetchAllNotes}
                isLoading={isLoading}
              />
            )}
          </div>

          {/* Main content */}
          <div className="w-full lg:w-3/4">
            {/* Loading state */}
            {isLoading && (
              <div className="flex h-64 items-center justify-center">
                <div className="h-8 w-8 animate-spin rounded-full border-b-2 border-blue-600"></div>
              </div>
            )}

            {/* Error state */}
            {isError && !isLoading && (
              <div className="rounded-lg bg-red-50 p-6 text-center">
                <h3 className="text-lg font-semibold text-red-800">Something went wrong</h3>
                <p className="mt-2 text-red-700">
                  We couldn't load the notes. Please try again later.
                </p>
              </div>
            )}

            {/* Empty state */}
            {!isLoading && !isError && notes.length === 0 && (
              <div className="rounded-lg bg-gray-50 p-6 text-center">
                <h3 className="text-lg font-semibold text-gray-800">No notes found</h3>
                <p className="mt-2 text-gray-600">
                  Try adjusting your filters to find more results.
                </p>
                <button
                  onClick={resetFilters}
                  className="mt-4 rounded-md bg-blue-600 px-4 py-2 font-medium text-white hover:bg-blue-700"
                >
                  Reset filters
                </button>
              </div>
            )}

            {/* Notes grid */}
            {!isLoading && !isError && notes.length > 0 && (
              <>
                <div className="mb-4 flex items-center justify-between">
                  <p className="text-sm text-gray-600">
                    {resultPagination?.totalCount || 0} listings found
                  </p>
                  <div className="flex items-center space-x-2">
                    <label htmlFor="sort" className="text-sm text-gray-600">
                      Sort By:
                    </label>
                    <select
                      id="sort"
                      className="rounded-md border border-gray-300 px-3 py-1 text-sm"
                    >
                      <option value="default">Default</option>
                      <option value="price-asc">Price: Low to High</option>
                      <option value="price-desc">Price: High to Low</option>
                      <option value="date-desc">Newest First</option>
                      <option value="date-asc">Oldest First</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
                  {notes.map((note: Note) => (
                    <NoteCard key={note.id} note={note} />
                  ))}
                </div>

                {/* Pagination */}
                {resultPagination && resultPagination.totalPages > 1 && (
                  <Pagination
                    currentPage={pagination.page}
                    totalPages={resultPagination.totalPages}
                    onPageChange={updatePage}
                  />
                )}
              </>
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default ForSalePage;
