import { useState, useEffect } from 'react';
import { Link } from 'wouter';
import DashboardLayout from '../../components/layout/DashboardLayout';
import DashboardCard from '../../components/dashboard/DashboardCard';
import StatCard from '../../components/dashboard/StatCard';
import { formatCurrency, formatDate } from '../../utils/formatters';

// Mock data for development - would be replaced with API calls
const MOCK_USERS = [
  {
    id: 1,
    firstName: 'John',
    lastName: 'Smith',
    email: 'john.smith@example.com',
    role: 'seller',
    status: 'active',
    createdAt: '2023-04-15T10:30:00Z',
    lastLogin: '2023-05-22T08:45:00Z',
  },
  {
    id: 2,
    firstName: 'Jane',
    lastName: 'Doe',
    email: 'jane.doe@example.com',
    role: 'buyer',
    status: 'active',
    createdAt: '2023-03-20T14:15:00Z',
    lastLogin: '2023-05-21T11:30:00Z',
  },
  {
    id: 3,
    firstName: 'Robert',
    lastName: 'Johnson',
    email: 'robert.j@example.com',
    role: 'seller',
    status: 'pending',
    createdAt: '2023-05-18T09:20:00Z',
    lastLogin: null,
  },
  {
    id: 4,
    firstName: 'Sarah',
    lastName: 'Williams',
    email: 'sarah.w@example.com',
    role: 'buyer',
    status: 'active',
    createdAt: '2023-02-10T16:45:00Z',
    lastLogin: '2023-05-19T13:15:00Z',
  },
  {
    id: 5,
    firstName: 'Michael',
    lastName: 'Brown',
    email: 'michael.b@example.com',
    role: 'seller',
    status: 'inactive',
    createdAt: '2023-01-05T11:10:00Z',
    lastLogin: '2023-04-15T10:20:00Z',
  },
];

const MOCK_NOTES = [
  {
    id: 1,
    title: 'Partial Deed of Trust Note',
    price: 12300,
    noteType: 'deed_of_trust',
    sellerName: 'John Smith',
    status: 'available',
    createdAt: '2023-04-15T10:30:00Z',
    viewCount: 28,
    inquiryCount: 3,
  },
  {
    id: 2,
    title: 'Mortgage Note with Kicker',
    price: 23500,
    noteType: 'mortgage',
    sellerName: 'Michael Brown',
    status: 'pending_sale',
    createdAt: '2023-05-20T14:45:00Z',
    viewCount: 42,
    inquiryCount: 5,
  },
  {
    id: 3,
    title: 'Deed of Trust for Section 8 Housing',
    price: 20000,
    noteType: 'deed_of_trust',
    sellerName: 'John Smith',
    status: 'sold',
    createdAt: '2023-03-10T09:15:00Z',
    soldDate: '2023-04-05T16:20:00Z',
    soldPrice: 19000,
    viewCount: 31,
    inquiryCount: 2,
  },
];

const MOCK_ACTIVITY = [
  {
    id: 1,
    userId: 1,
    userName: 'John Smith',
    activityType: 'login',
    details: 'User logged in from IP 192.168.1.1',
    createdAt: '2023-05-22T08:45:00Z',
  },
  {
    id: 2,
    userId: 1,
    userName: 'John Smith',
    activityType: 'listing_create',
    details: 'Created new listing: Partial Deed of Trust Note',
    createdAt: '2023-05-22T09:10:00Z',
  },
  {
    id: 3,
    userId: 2,
    userName: 'Jane Doe',
    activityType: 'login',
    details: 'User logged in from IP 192.168.1.2',
    createdAt: '2023-05-21T11:30:00Z',
  },
  {
    id: 4,
    userId: 2,
    userName: 'Jane Doe',
    activityType: 'search',
    details: 'Searched for mortgage notes in Texas',
    createdAt: '2023-05-21T11:45:00Z',
  },
  {
    id: 5,
    userId: 4,
    userName: 'Sarah Williams',
    activityType: 'login',
    details: 'User logged in from IP 192.168.1.3',
    createdAt: '2023-05-19T13:15:00Z',
  },
];

const AdminDashboardPage = () => {
  const [users, setUsers] = useState([]);
  const [notes, setNotes] = useState([]);
  const [activity, setActivity] = useState([]);
  const [stats, setStats] = useState({
    totalUsers: 0,
    activeUsers: 0,
    pendingUsers: 0,
    totalListings: 0,
    activeListings: 0,
    soldListings: 0,
    revenue: 0,
  });
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Simulate API call
    const fetchData = async () => {
      try {
        setIsLoading(true);
        // In a real app, this would be an API call
        await new Promise(resolve => setTimeout(resolve, 600));

        // Process mock data
        setUsers(MOCK_USERS);
        setNotes(MOCK_NOTES);
        setActivity(MOCK_ACTIVITY);

        // Calculate stats
        const totalUsers = MOCK_USERS.length;
        const activeUsers = MOCK_USERS.filter(u => u.status === 'active').length;
        const pendingUsers = MOCK_USERS.filter(u => u.status === 'pending').length;
        const totalListings = MOCK_NOTES.length;
        const activeListings = MOCK_NOTES.filter(n => n.status === 'available').length;
        const soldListings = MOCK_NOTES.filter(n => n.status === 'sold').length;
        const revenue = MOCK_NOTES
          .filter(n => n.status === 'sold')
          .reduce((sum, n) => sum + (n.soldPrice || 0), 0);

        setStats({
          totalUsers,
          activeUsers,
          pendingUsers,
          totalListings,
          activeListings,
          soldListings,
          revenue,
        });
      } catch (error) {
        console.error('Error fetching admin dashboard data:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, []);

  const getSidebarLinks = () => [
    {
      to: '/admin/dashboard',
      label: 'Dashboard',
      icon: (
        <svg className="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
        </svg>
      ),
    },
    {
      to: '/admin/users',
      label: 'User Management',
      icon: (
        <svg className="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
        </svg>
      ),
    },
    {
      to: '/admin/listings',
      label: 'Listing Management',
      icon: (
        <svg className="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" />
        </svg>
      ),
    },
    {
      to: '/admin/settings',
      label: 'System Settings',
      icon: (
        <svg className="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
        </svg>
      ),
    },
    {
      to: '/admin/cms',
      label: 'CMS',
      icon: (
        <svg className="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
        </svg>
      ),
    },
  ];

  const getRoleBadgeClass = (role) => {
    switch (role) {
      case 'admin':
        return 'bg-purple-100 text-purple-800';
      case 'seller':
        return 'bg-blue-100 text-blue-800';
      case 'buyer':
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusBadgeClass = (status) => {
    switch (status) {
      case 'active':
        return 'bg-green-100 text-green-800';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'inactive':
        return 'bg-gray-100 text-gray-800';
      case 'banned':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getActivityTypeIcon = (type) => {
    switch (type) {
      case 'login':
        return (
          <svg className="h-5 w-5 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1" />
          </svg>
        );
      case 'listing_create':
        return (
          <svg className="h-5 w-5 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 13h6m-3-3v6m5 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
          </svg>
        );
      case 'search':
        return (
          <svg className="h-5 w-5 text-purple-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
          </svg>
        );
      default:
        return (
          <svg className="h-5 w-5 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
        );
    }
  };

  return (
    <DashboardLayout title="Admin Dashboard" links={getSidebarLinks()}>
      {isLoading ? (
        <div className="flex h-64 items-center justify-center">
          <div className="h-8 w-8 animate-spin rounded-full border-b-2 border-blue-600"></div>
        </div>
      ) : (
        <>
          <h1 className="mb-6 text-2xl font-bold text-gray-900">Admin Dashboard</h1>

          {/* Stats Row */}
          <div className="mb-6 grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-4">
            <StatCard
              title="Total Users"
              value={stats.totalUsers}
              change={{ value: '+3 this week', type: 'increase' }}
              icon={
                <svg className="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
                </svg>
              }
            />

            <StatCard
              title="Active Listings"
              value={stats.activeListings}
              change={{ value: '+2 this week', type: 'increase' }}
              icon={
                <svg className="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
              }
            />

            <StatCard
              title="Pending Users"
              value={stats.pendingUsers}
              change={{ value: '+1 this week', type: 'increase' }}
              icon={
                <svg className="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              }
            />

            <StatCard
              title="Revenue"
              value={formatCurrency(stats.revenue)}
              change={{ value: '+12% this month', type: 'increase' }}
              icon={
                <svg className="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              }
            />
          </div>

          {/* Recent Users */}
          <DashboardCard
            title="Recent Users"
            action={
              <Link href="/admin/users">
                <a className="text-sm font-medium text-blue-600 hover:text-blue-800">
                  View All
                </a>
              </Link>
            }
            className="mb-6"
          >
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500">
                      Name
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500">
                      Email
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500">
                      Role
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500">
                      Status
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500">
                      Last Login
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200 bg-white">
                  {users.map((user) => (
                    <tr key={user.id}>
                      <td className="whitespace-nowrap px-6 py-4 text-sm font-medium text-gray-900">
                        {user.firstName} {user.lastName}
                      </td>
                      <td className="whitespace-nowrap px-6 py-4 text-sm text-gray-500">
                        {user.email}
                      </td>
                      <td className="whitespace-nowrap px-6 py-4 text-sm">
                        <span className={`inline-flex rounded-full px-2 py-1 text-xs font-semibold ${getRoleBadgeClass(user.role)}`}>
                          {user.role}
                        </span>
                      </td>
                      <td className="whitespace-nowrap px-6 py-4 text-sm">
                        <span className={`inline-flex rounded-full px-2 py-1 text-xs font-semibold ${getStatusBadgeClass(user.status)}`}>
                          {user.status}
                        </span>
                      </td>
                      <td className="whitespace-nowrap px-6 py-4 text-sm text-gray-500">
                        {user.lastLogin ? formatDate(user.lastLogin) : 'Never'}
                      </td>
                      <td className="whitespace-nowrap px-6 py-4 text-sm">
                        <div className="flex space-x-2">
                          <Link href={`/admin/users/${user.id}`}>
                            <a className="text-blue-600 hover:text-blue-900">View</a>
                          </Link>
                          <Link href={`/admin/users/${user.id}/edit`}>
                            <a className="text-indigo-600 hover:text-indigo-900">Edit</a>
                          </Link>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </DashboardCard>

          {/* Recent Activity */}
          <DashboardCard
            title="Recent Activity"
            action={
              <Link href="/admin/activity">
                <a className="text-sm font-medium text-blue-600 hover:text-blue-800">
                  View All
                </a>
              </Link>
            }
            className="mb-6"
          >
            <div className="flow-root">
              <ul className="-mb-8 mt-2">
                {activity.map((item, index) => (
                  <li key={item.id}>
                    <div className="relative pb-8">
                      {index !== activity.length - 1 ? (
                        <span className="absolute left-5 top-5 -ml-px h-full w-0.5 bg-gray-200" aria-hidden="true" />
                      ) : null}
                      <div className="relative flex items-start space-x-3">
                        <div className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-full bg-gray-100">
                          {getActivityTypeIcon(item.activityType)}
                        </div>
                        <div className="min-w-0 flex-1">
                          <div>
                            <div className="text-sm">
                              <a href={`/admin/users/${item.userId}`} className="font-medium text-gray-900">
                                {item.userName}
                              </a>
                            </div>
                            <p className="mt-0.5 text-sm text-gray-500">
                              {item.activityType.replace(/_/g, ' ')}
                            </p>
                          </div>
                          <div className="mt-2 text-sm text-gray-700">
                            <p>{item.details}</p>
                          </div>
                          <div className="mt-1 text-xs text-gray-500">
                            {formatDate(item.createdAt)}
                          </div>
                        </div>
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          </DashboardCard>

          {/* Performance Metrics */}
          <DashboardCard title="Performance Metrics">
            <div className="text-center">
              <p className="text-gray-500">
                Detailed analytics and performance metrics will be displayed here.
              </p>
              <div className="mt-4">
                <Link href="/admin/analytics">
                  <a className="rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white shadow-sm hover:bg-blue-700">
                    View Analytics
                  </a>
                </Link>
              </div>
            </div>
          </DashboardCard>
        </>
      )}
    </DashboardLayout>
  );
};

export default AdminDashboardPage;
