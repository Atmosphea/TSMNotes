import { useState, useEffect } from 'react';
import { Link } from 'wouter';
import DashboardLayout from '../../components/layout/DashboardLayout';
import DashboardCard from '../../components/dashboard/DashboardCard';
import StatCard from '../../components/dashboard/StatCard';
import { formatCurrency, formatDate } from '../../utils/formatters';

// Mock data for development - would be replaced with API calls
const MOCK_SAVED_SEARCHES = [
  {
    id: 1,
    name: 'Texas Mortgage Notes',
    noteType: 'mortgage',
    propertyState: 'TX',
    minPrice: 10000,
    maxPrice: 30000,
    notificationFrequency: 'daily',
    isEmailEnabled: true,
    createdAt: '2023-05-12T09:30:00Z',
    matchCount: 12,
    lastNotificationSentAt: '2023-05-15T14:20:00Z',
  },
  {
    id: 2,
    name: 'California Commercial Properties',
    propertyType: 'commercial',
    propertyState: 'CA',
    minLtv: 50,
    maxLtv: 75,
    notificationFrequency: 'weekly',
    isEmailEnabled: true,
    createdAt: '2023-04-23T15:45:00Z',
    matchCount: 5,
    lastNotificationSentAt: '2023-05-14T08:10:00Z',
  },
  {
    id: 3,
    name: 'High Yield Investments',
    minYield: 8,
    performance: 'performing',
    notificationFrequency: 'instant',
    isEmailEnabled: true,
    createdAt: '2023-05-20T11:20:00Z',
    matchCount: 8,
    lastNotificationSentAt: null,
  },
];

const MOCK_INQUIRIES = [
  {
    id: 1,
    noteId: 101,
    noteTitle: 'Partial Deed of Trust Note',
    subject: 'Interest in your listing',
    message: 'I am interested in learning more about this note. Can you provide additional details?',
    status: 'new',
    hasSellerResponse: false,
    createdAt: '2023-05-18T10:15:00Z',
  },
  {
    id: 2,
    noteId: 102,
    noteTitle: 'Mortgage Note with Kicker',
    subject: 'Questions about payment history',
    message: 'Could you share the payment history for this note? Is there any risk of default?',
    status: 'viewed',
    hasSellerResponse: true,
    lastResponseAt: '2023-05-19T14:30:00Z',
    createdAt: '2023-05-19T09:45:00Z',
  },
];

const MOCK_FAVORITES = [
  {
    id: 1,
    noteId: 101,
    title: 'Partial Deed of Trust Note',
    price: 12300,
    noteType: 'deed_of_trust',
    status: 'available',
    addedAt: '2023-05-10T08:20:00Z',
  },
  {
    id: 2,
    noteId: 103,
    title: 'Houston Commercial Property Note',
    price: 45000,
    noteType: 'mortgage',
    status: 'available',
    addedAt: '2023-05-15T16:40:00Z',
  },
];

const BuyerDashboardPage = () => {
  const [savedSearches, setSavedSearches] = useState([]);
  const [inquiries, setInquiries] = useState([]);
  const [favorites, setFavorites] = useState([]);
  const [stats, setStats] = useState({
    activeSearches: 0,
    totalMatches: 0,
    openInquiries: 0,
    favoriteListings: 0,
  });
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Simulate API call
    const fetchData = async () => {
      try {
        setIsLoading(true);
        // In a real app, this would be an API call
        await new Promise(resolve => setTimeout(resolve, 600));

        // Process mock data
        setSavedSearches(MOCK_SAVED_SEARCHES);
        setInquiries(MOCK_INQUIRIES);
        setFavorites(MOCK_FAVORITES);

        // Calculate stats
        const activeSearches = MOCK_SAVED_SEARCHES.length;
        const totalMatches = MOCK_SAVED_SEARCHES.reduce((sum, s) => sum + s.matchCount, 0);
        const openInquiries = MOCK_INQUIRIES.filter(i => i.status !== 'closed').length;
        const favoriteListings = MOCK_FAVORITES.length;

        setStats({
          activeSearches,
          totalMatches,
          openInquiries,
          favoriteListings,
        });
      } catch (error) {
        console.error('Error fetching buyer dashboard data:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, []);

  const getSidebarLinks = () => [
    {
      to: '/buyer/dashboard',
      label: 'Dashboard',
      icon: (
        <svg className="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
        </svg>
      ),
    },
    {
      to: '/buyer/saved-searches',
      label: 'Saved Searches',
      icon: (
        <svg className="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
        </svg>
      ),
    },
    {
      to: '/buyer/inquiries',
      label: 'My Inquiries',
      icon: (
        <svg className="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
        </svg>
      ),
    },
    {
      to: '/buyer/favorites',
      label: 'Favorites',
      icon: (
        <svg className="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
        </svg>
      ),
    },
  ];

  return (
    <DashboardLayout title="Buyer Dashboard" links={getSidebarLinks()}>
      {isLoading ? (
        <div className="flex h-64 items-center justify-center">
          <div className="h-8 w-8 animate-spin rounded-full border-b-2 border-blue-600"></div>
        </div>
      ) : (
        <>
          <h1 className="mb-6 text-2xl font-bold text-gray-900">Dashboard Overview</h1>

          {/* Stats Row */}
          <div className="mb-6 grid grid-cols-1 gap-6 lg:grid-cols-4">
            <StatCard
              title="Active Searches"
              value={stats.activeSearches}
              icon={
                <svg className="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
              }
            />

            <StatCard
              title="Matching Notes"
              value={stats.totalMatches}
              icon={
                <svg className="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                </svg>
              }
            />

            <StatCard
              title="Open Inquiries"
              value={stats.openInquiries}
              icon={
                <svg className="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
                </svg>
              }
            />

            <StatCard
              title="Favorite Listings"
              value={stats.favoriteListings}
              icon={
                <svg className="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                </svg>
              }
            />
          </div>

          {/* Saved Searches */}
          <DashboardCard
            title="Recent Saved Searches"
            action={
              <Link href="/buyer/saved-searches">
                <a className="text-sm font-medium text-blue-600 hover:text-blue-800">
                  View All
                </a>
              </Link>
            }
            className="mb-6"
          >
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500">
                      Name
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500">
                      Matches
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500">
                      Notifications
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500">
                      Last Notification
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200 bg-white">
                  {savedSearches.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="px-6 py-4 text-center text-sm text-gray-500">
                        No saved searches found. <Link href="/for-sale"><a className="text-blue-600 hover:text-blue-800">Create your first search</a></Link>
                      </td>
                    </tr>
                  ) : (
                    savedSearches.map((search) => (
                      <tr key={search.id}>
                        <td className="whitespace-nowrap px-6 py-4 text-sm font-medium text-gray-900">
                          {search.name}
                        </td>
                        <td className="whitespace-nowrap px-6 py-4 text-sm text-gray-500">
                          {search.matchCount} notes
                        </td>
                        <td className="whitespace-nowrap px-6 py-4 text-sm">
                          <span className={`inline-flex rounded-full px-2 text-xs font-semibold leading-5 ${
                            search.isEmailEnabled
                              ? 'bg-green-100 text-green-800'
                              : 'bg-gray-100 text-gray-800'
                          }`}>
                            {search.isEmailEnabled
                              ? search.notificationFrequency
                              : 'Disabled'}
                          </span>
                        </td>
                        <td className="whitespace-nowrap px-6 py-4 text-sm text-gray-500">
                          {search.lastNotificationSentAt
                            ? formatDate(search.lastNotificationSentAt)
                            : 'Never'}
                        </td>
                        <td className="whitespace-nowrap px-6 py-4 text-sm">
                          <div className="flex space-x-2">
                            <Link href={`/buyer/search-results?search=${search.id}`}>
                              <a className="text-blue-600 hover:text-blue-900">View Results</a>
                            </Link>
                            <Link href={`/buyer/saved-searches/${search.id}/edit`}>
                              <a className="text-indigo-600 hover:text-indigo-900">Edit</a>
                            </Link>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </DashboardCard>

          {/* Recent Inquiries */}
          <DashboardCard
            title="Recent Inquiries"
            action={
              <Link href="/buyer/inquiries">
                <a className="text-sm font-medium text-blue-600 hover:text-blue-800">
                  View All
                </a>
              </Link>
            }
            className="mb-6"
          >
            {inquiries.length === 0 ? (
              <p className="text-center text-gray-500">
                You haven't made any inquiries yet.
              </p>
            ) : (
              <div className="space-y-4">
                {inquiries.map((inquiry) => (
                  <div
                    key={inquiry.id}
                    className="rounded-lg border border-gray-200 p-4 transition-colors hover:bg-gray-50"
                  >
                    <div className="mb-2 flex items-center justify-between">
                      <h4 className="text-base font-medium text-gray-900">
                        <Link href={`/note/${inquiry.noteId}`}>
                          <a className="hover:text-blue-600">{inquiry.noteTitle}</a>
                        </Link>
                      </h4>
                      <span className={`inline-flex rounded-full px-2 text-xs font-semibold leading-5 ${
                        inquiry.status === 'new'
                          ? 'bg-blue-100 text-blue-800'
                          : inquiry.status === 'viewed'
                            ? 'bg-yellow-100 text-yellow-800'
                            : inquiry.status === 'replied'
                              ? 'bg-green-100 text-green-800'
                              : 'bg-gray-100 text-gray-800'
                      }`}>
                        {inquiry.status.charAt(0).toUpperCase() + inquiry.status.slice(1)}
                      </span>
                    </div>
                    <p className="text-sm font-medium text-gray-700">{inquiry.subject}</p>
                    <p className="text-sm text-gray-500 line-clamp-2">{inquiry.message}</p>
                    <div className="mt-2 flex items-center justify-between">
                      <span className="text-xs text-gray-500">
                        {formatDate(inquiry.createdAt)}
                      </span>
                      <Link href={`/buyer/inquiries/${inquiry.id}`}>
                        <a className="text-xs font-medium text-blue-600 hover:text-blue-800">
                          {inquiry.hasSellerResponse ? 'View Response' : 'View Details'}
                        </a>
                      </Link>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </DashboardCard>

          {/* Favorite Listings */}
          <DashboardCard
            title="Favorite Listings"
            action={
              <Link href="/buyer/favorites">
                <a className="text-sm font-medium text-blue-600 hover:text-blue-800">
                  View All
                </a>
              </Link>
            }
          >
            {favorites.length === 0 ? (
              <p className="text-center text-gray-500">
                You haven't added any listings to your favorites yet.
              </p>
            ) : (
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                {favorites.map((favorite) => (
                  <div
                    key={favorite.id}
                    className="rounded-lg border border-gray-200 p-4 transition-shadow hover:shadow-md"
                  >
                    <h4 className="mb-2 text-base font-medium text-gray-900">
                      <Link href={`/note/${favorite.noteId}`}>
                        <a className="hover:text-blue-600">{favorite.title}</a>
                      </Link>
                    </h4>
                    <div className="mb-1 flex items-center justify-between">
                      <span className="text-sm text-gray-700">
                        {formatCurrency(favorite.price)}
                      </span>
                      <span className="text-xs text-gray-500">
                        Added {formatDate(favorite.addedAt)}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-gray-500">
                        {favorite.noteType.replace(/_/g, ' ')}
                      </span>
                      <button className="text-xs text-red-600 hover:text-red-800">
                        Remove
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </DashboardCard>
        </>
      )}
    </DashboardLayout>
  );
};

export default BuyerDashboardPage;
