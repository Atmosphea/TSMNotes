import { useQuery } from '@tanstack/react-query';
import { notesApi } from '../api';
import { NoteFilterParams, Note } from '../types';

interface UseNotesOptions {
  enabled?: boolean;
}

interface UseNotesResult {
  notes: Note[];
  isLoading: boolean;
  isError: boolean;
  error: Error | null;
  pagination: {
    page: number;
    limit: number;
    totalCount: number;
    totalPages: number;
  } | null;
  refetch: () => Promise<void>;
  fetchAllNotes: () => Promise<Note[]>;
}

/**
 * Hook for fetching and filtering notes
 */
export const useNotes = (
  filters: NoteFilterParams = {},
  options: UseNotesOptions = {}
): UseNotesResult => {
  const { enabled = true } = options;

  const {
    data,
    isLoading,
    isError,
    error,
    refetch: refetchQuery,
  } = useQuery({
    queryKey: ['notes', filters],
    queryFn: () => notesApi.getNotes(filters),
    enabled,
  });

  // Convert the refetch function to a more convenient format
  const refetch = async (): Promise<void> => {
    await refetchQuery();
  };

  // Function to fetch all notes (for export)
  const fetchAllNotes = async (): Promise<Note[]> => {
    // Create a copy of the filters but remove pagination
    const exportFilters = { ...filters };
    delete exportFilters.page;
    delete exportFilters.limit;

    // Set limit to a high value to get all notes in one request
    // Note: In a real production app, you might want to do pagination in batches
    // if the total count is very large
    const allNotesResult = await notesApi.getNotes({
      ...exportFilters,
      limit: 1000, // Use a large limit to get all notes
    });

    return allNotesResult.data as Note[];
  };

  return {
    // Type assertion to allow for mock data that might not perfectly match the Note type
    notes: (data?.data || []) as Note[],
    isLoading,
    isError,
    error: error as Error | null,
    pagination: data?.pagination || null,
    refetch,
    fetchAllNotes,
  };
};

/**
 * Hook for fetching a single note by ID
 */
export const useNote = (id: number, options: UseNotesOptions = {}) => {
  const { enabled = true } = options;

  return useQuery({
    queryKey: ['note', id],
    queryFn: () => notesApi.getNoteById(id),
    enabled: enabled && !!id,
  });
};
