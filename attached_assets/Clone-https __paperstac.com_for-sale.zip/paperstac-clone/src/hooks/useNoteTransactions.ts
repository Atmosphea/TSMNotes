import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  placeNoteOnHold,
  releaseNoteHold,
  completeTransaction,
  getNoteTransactionHistory
} from '../api';
import { NoteTransactionHistory } from '../types';

export const useNoteTransactionHistory = (noteId: number) => {
  const { data, isLoading, isError, error, refetch } = useQuery(
    ['noteHistory', noteId],
    () => getNoteTransactionHistory(noteId),
    {
      enabled: !!noteId,
      staleTime: 2 * 60 * 1000, // 2 minutes
    }
  );

  return {
    history: data?.data as NoteTransactionHistory[] || [],
    isLoading,
    isError,
    error,
    refetch,
  };
};

export const usePlaceNoteOnHold = () => {
  const queryClient = useQueryClient();

  const mutation = useMutation({
    mutationFn: ({
      noteId,
      buyerId,
      reason,
      durationHours
    }: {
      noteId: number;
      buyerId: number;
      reason?: string;
      durationHours?: number;
    }) =>
      placeNoteOnHold(noteId, buyerId, reason, durationHours),
    onSuccess: (_, variables) => {
      // Invalidate relevant queries
      queryClient.invalidateQueries(['note', variables.noteId]);
      queryClient.invalidateQueries(['notes']);
      queryClient.invalidateQueries(['noteHistory', variables.noteId]);
    },
  });

  return mutation;
};

export const useReleaseNoteHold = () => {
  const queryClient = useQueryClient();

  const mutation = useMutation({
    mutationFn: (noteId: number) => releaseNoteHold(noteId),
    onSuccess: (_, noteId) => {
      // Invalidate relevant queries
      queryClient.invalidateQueries(['note', noteId]);
      queryClient.invalidateQueries(['notes']);
      queryClient.invalidateQueries(['noteHistory', noteId]);
    },
  });

  return mutation;
};

export const useCompleteTransaction = () => {
  const queryClient = useQueryClient();

  const mutation = useMutation({
    mutationFn: ({
      noteId,
      buyerId,
      soldPrice
    }: {
      noteId: number;
      buyerId: number;
      soldPrice?: number;
    }) =>
      completeTransaction(noteId, buyerId, soldPrice),
    onSuccess: (_, variables) => {
      // Invalidate relevant queries
      queryClient.invalidateQueries(['note', variables.noteId]);
      queryClient.invalidateQueries(['notes']);
      queryClient.invalidateQueries(['noteHistory', variables.noteId]);
    },
  });

  return mutation;
};
