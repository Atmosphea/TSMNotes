import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  getSavedSearches,
  getSavedSearchById,
  createSavedSearch,
  updateSavedSearch,
  deleteSavedSearch,
  getSharedSearch,
  toggleEmailNotifications,
  toggleSearchVisibility,
  getSavedSearchAnalytics,
  getMostUsedSearches,
  executeSavedSearch
} from '../api';
import { SavedSearch } from '../types';

export const useSavedSearches = () => {
  return useQuery(['savedSearches'], () => getSavedSearches(), {
    staleTime: 1000 * 60 * 5, // 5 minutes
  });
};

export const useSavedSearch = (id: number) => {
  return useQuery(
    ['savedSearch', id],
    () => getSavedSearchById(id),
    {
      enabled: !!id,
      staleTime: 1000 * 60 * 5, // 5 minutes
    }
  );
};

export const useSavedSearchAnalytics = (id: number) => {
  return useQuery(
    ['savedSearchAnalytics', id],
    () => getSavedSearchAnalytics(id),
    {
      enabled: !!id,
      staleTime: 1000 * 60 * 5, // 5 minutes
    }
  );
};

export const useMostUsedSearches = () => {
  return useQuery(['mostUsedSearches'], () => getMostUsedSearches(), {
    staleTime: 1000 * 60 * 15, // 15 minutes
  });
};

export const useExecuteSavedSearch = (id: number) => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: () => executeSavedSearch(id),
    onSuccess: () => {
      queryClient.invalidateQueries(['savedSearchAnalytics', id]);
    },
  });
};

export const useCreateSavedSearch = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (data: Omit<SavedSearch, 'id' | 'userId' | 'createdAt' | 'updatedAt'>) =>
      createSavedSearch(data),
    onSuccess: () => {
      queryClient.invalidateQueries(['savedSearches']);
    },
  });
};

export const useUpdateSavedSearch = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({ id, data }: { id: number; data: Partial<SavedSearch> }) =>
      updateSavedSearch(id, data),
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries(['savedSearches']);
      queryClient.invalidateQueries(['savedSearch', variables.id]);
    },
  });
};

export const useDeleteSavedSearch = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (id: number) => deleteSavedSearch(id),
    onSuccess: () => {
      queryClient.invalidateQueries(['savedSearches']);
    },
  });
};

export const useSharedSearch = (token: string) => {
  return useQuery(
    ['sharedSearch', token],
    () => getSharedSearch(token),
    {
      enabled: !!token,
      staleTime: 1000 * 60 * 5, // 5 minutes
    }
  );
};

export const useToggleSearchVisibility = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({ id, isPublic }: { id: number; isPublic: boolean }) =>
      toggleSearchVisibility(id, isPublic),
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries(['savedSearches']);
      queryClient.invalidateQueries(['savedSearch', variables.id]);
    },
  });
};

export const useToggleEmailNotifications = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({
      id,
      isEmailEnabled,
      notificationFrequency,
    }: {
      id: number;
      isEmailEnabled: boolean;
      notificationFrequency?: 'instant' | 'daily' | 'weekly';
    }) => toggleEmailNotifications(id, isEmailEnabled, notificationFrequency),
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries(['savedSearches']);
      queryClient.invalidateQueries(['savedSearch', variables.id]);
    },
  });
};
