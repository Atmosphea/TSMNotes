import { useState, useCallback, useMemo } from 'react';
import { FilterState, PaginationState, SortingState } from '../types';

export interface UseFiltersOptions {
  initialFilters?: FilterState;
  initialPage?: number;
  initialLimit?: number;
  initialSorting?: {
    sortBy?: string;
    sortDirection?: 'asc' | 'desc';
  };
}

export interface UseFiltersReturn {
  filters: FilterState;
  pagination: PaginationState;
  sorting: SortingState;
  updateFilter: (key: keyof FilterState, value: string | boolean | null) => void;
  updateFilters: (newFilters: Partial<FilterState>) => void;
  resetFilters: () => void;
  updatePage: (page: number) => void;
  updateLimit: (limit: number) => void;
  updateSorting: (sortBy: string, sortDirection?: 'asc' | 'desc') => void;
  toggleSortDirection: () => void;
  queryParams: Record<string, string | number | boolean | undefined>;
}

export const useFilters = (options: UseFiltersOptions = {}): UseFiltersReturn => {
  const {
    initialFilters = {},
    initialPage = 1,
    initialLimit = 10,
    initialSorting = { sortBy: 'createdAt', sortDirection: 'desc' },
  } = options;

  // State for filters, pagination, and sorting
  const [filters, setFilters] = useState<FilterState>(initialFilters);
  const [pagination, setPagination] = useState<PaginationState>({
    page: initialPage,
    limit: initialLimit,
  });
  const [sorting, setSorting] = useState<SortingState>(initialSorting);

  // Update a single filter
  const updateFilter = useCallback((key: keyof FilterState, value: string | boolean | null) => {
    setFilters((prev) => {
      // If value is null or empty string, remove the filter
      if (value === null || value === '') {
        const { [key]: _, ...rest } = prev;
        return rest;
      }
      return { ...prev, [key]: value };
    });

    // Reset to first page when filter changes
    setPagination((prev) => ({ ...prev, page: 1 }));
  }, []);

  // Update multiple filters at once
  const updateFilters = useCallback((newFilters: Partial<FilterState>) => {
    setFilters((prev) => {
      const updated = { ...prev };

      // Process each new filter
      Object.entries(newFilters).forEach(([key, value]) => {
        const filterKey = key as keyof FilterState;

        // If value is null or empty string, remove the filter
        if (value === null || value === '') {
          delete updated[filterKey];
        } else {
          // Type assertion to handle the assignment
          updated[filterKey] = value as FilterState[keyof FilterState];
        }
      });

      return updated;
    });

    // Reset to first page when filters change
    setPagination((prev) => ({ ...prev, page: 1 }));
  }, []);

  // Reset all filters to initial state
  const resetFilters = useCallback(() => {
    setFilters(initialFilters);
    setPagination({ page: initialPage, limit: initialLimit });
    setSorting(initialSorting);
  }, [initialFilters, initialPage, initialLimit, initialSorting]);

  // Update page number
  const updatePage = useCallback((page: number) => {
    setPagination((prev) => ({ ...prev, page }));
  }, []);

  // Update items per page
  const updateLimit = useCallback((limit: number) => {
    setPagination((prev) => ({ ...prev, limit, page: 1 }));
  }, []);

  // Update sorting options
  const updateSorting = useCallback((sortBy: string, sortDirection: 'asc' | 'desc' = 'asc') => {
    setSorting({ sortBy, sortDirection });

    // Reset to first page when sorting changes
    setPagination((prev) => ({ ...prev, page: 1 }));
  }, []);

  // Toggle sort direction (asc/desc)
  const toggleSortDirection = useCallback(() => {
    setSorting((prev) => ({
      ...prev,
      sortDirection: prev.sortDirection === 'asc' ? 'desc' : 'asc',
    }));
  }, []);

  // Combine all parameters for API query
  const queryParams = useMemo(() => {
    return {
      ...filters,
      page: pagination.page,
      limit: pagination.limit,
      ...(sorting.sortBy && { sortBy: sorting.sortBy }),
      ...(sorting.sortDirection && { sortDirection: sorting.sortDirection }),
    };
  }, [filters, pagination, sorting]);

  return {
    filters,
    pagination,
    sorting,
    updateFilter,
    updateFilters,
    resetFilters,
    updatePage,
    updateLimit,
    updateSorting,
    toggleSortDirection,
    queryParams,
  };
};
