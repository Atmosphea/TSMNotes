import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { createInquiry, getInquiries, getInquiry, replyToInquiry, revealPhoneNumber } from '../api';

export const useInquiries = (role: 'buyer' | 'seller' = 'buyer') => {
  const { data, isLoading, isError, error, refetch } = useQuery(
    ['inquiries', role],
    () => getInquiries(role),
    {
      staleTime: 5 * 60 * 1000, // 5 minutes
    }
  );

  return {
    inquiries: data?.data || [],
    isLoading,
    isError,
    error,
    refetch,
  };
};

export const useInquiry = (inquiryId: number) => {
  const { data, isLoading, isError, error, refetch } = useQuery(
    ['inquiry', inquiryId],
    () => getInquiry(inquiryId),
    {
      enabled: !!inquiryId,
      staleTime: 1 * 60 * 1000, // 1 minute
    }
  );

  return {
    inquiry: data?.data,
    isLoading,
    isError,
    error,
    refetch,
  };
};

export const useCreateInquiry = () => {
  const queryClient = useQueryClient();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const createInquiryFn = async (
    noteId: number,
    subject: string,
    message: string,
    phoneNumberRequested: boolean
  ) => {
    setIsSubmitting(true);
    setError(null);
    try {
      const result = await createInquiry(noteId, subject, message, phoneNumberRequested);
      queryClient.invalidateQueries(['inquiries']);
      return result;
    } catch (err) {
      setError('Failed to send inquiry. Please try again.');
      throw err;
    } finally {
      setIsSubmitting(false);
    }
  };

  return {
    createInquiry: createInquiryFn,
    isSubmitting,
    error,
  };
};

export const useReplyToInquiry = (inquiryId: number) => {
  const queryClient = useQueryClient();

  const mutation = useMutation({
    mutationFn: (message: string) => replyToInquiry(inquiryId, message),
    onSuccess: () => {
      queryClient.invalidateQueries(['inquiry', inquiryId]);
      queryClient.invalidateQueries(['inquiries']);
    },
  });

  return mutation;
};

export const useRevealPhoneNumber = (inquiryId: number) => {
  const queryClient = useQueryClient();

  const mutation = useMutation({
    mutationFn: () => revealPhoneNumber(inquiryId),
    onSuccess: () => {
      queryClient.invalidateQueries(['inquiry', inquiryId]);
    },
  });

  return mutation;
};
