import { PriceFormatterOptions } from '../types';

/**
 * Format a number as currency (USD by default)
 */
export const formatCurrency = (
  value: number | string | null | undefined,
  options: PriceFormatterOptions = {}
): string => {
  if (value === null || value === undefined) {
    return '';
  }

  const amount = typeof value === 'string' ? parseFloat(value) : value;

  if (isNaN(amount)) {
    return '';
  }

  const {
    minimumFractionDigits = 0,
    maximumFractionDigits = 2,
    notation = 'standard',
    compactDisplay = 'short',
  } = options;

  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits,
    maximumFractionDigits,
    notation,
    compactDisplay,
  }).format(amount);
};

/**
 * Format a percentage value (e.g., 0.15 => 15%)
 */
export const formatPercentage = (
  value: number | string | null | undefined,
  decimals: number = 1
): string => {
  if (value === null || value === undefined) {
    return '';
  }

  const percentage = typeof value === 'string' ? parseFloat(value) : value;

  if (isNaN(percentage)) {
    return '';
  }

  return percentage.toLocaleString('en-US', {
    style: 'percent',
    minimumFractionDigits: 0,
    maximumFractionDigits: decimals,
  });
};

/**
 * Format a date string
 */
export const formatDate = (dateStr: string): string => {
  const date = new Date(dateStr);

  // Check if date is today
  const today = new Date();
  const isToday = date.getDate() === today.getDate() &&
    date.getMonth() === today.getMonth() &&
    date.getFullYear() === today.getFullYear();

  if (isToday) {
    return `Today at ${date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
  }

  // Check if date is yesterday
  const yesterday = new Date(today);
  yesterday.setDate(yesterday.getDate() - 1);
  const isYesterday = date.getDate() === yesterday.getDate() &&
    date.getMonth() === yesterday.getMonth() &&
    date.getFullYear() === yesterday.getFullYear();

  if (isYesterday) {
    return `Yesterday at ${date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
  }

  // Format for dates within this year
  const isThisYear = date.getFullYear() === today.getFullYear();

  if (isThisYear) {
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }) + ' at ' +
      date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  }

  // Format for older dates
  return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
};

/**
 * Format a phone number to a standardized format: (XXX) XXX-XXXX
 */
export const formatPhoneNumber = (phone: string): string => {
  if (!phone) {
    return '';
  }

  // Remove all non-digit characters
  const cleaned = phone.replace(/\D/g, '');

  // Check if the input is of correct length
  const match = cleaned.match(/^(\d{3})(\d{3})(\d{4})$/);

  if (match) {
    return `(${match[1]}) ${match[2]}-${match[3]}`;
  }

  return phone;
};

/**
 * Truncate text with ellipsis if it exceeds the specified length
 */
export const truncateText = (text: string, maxLength: number): string => {
  if (!text) {
    return '';
  }

  if (text.length <= maxLength) {
    return text;
  }

  return `${text.substring(0, maxLength)}...`;
};

/**
 * Format a number as currency (USD)
 * (Legacy function - use formatCurrency instead)
 */
export const formatPrice = formatCurrency;

/**
 * Format a price label for display (e.g., "$12.3K" or "Make an Offer")
 */
export const formatPriceLabel = (
  price: number | null | undefined,
  isBestOffer = false,
  isFirmPrice = false
): string => {
  if (price === null || price === undefined || price === 0) {
    return 'Make an Offer';
  }

  const formattedPrice = formatCurrency(price);

  if (isFirmPrice) {
    return `${formattedPrice} Firm`;
  }

  if (isBestOffer) {
    return `${formattedPrice} or Best Offer`;
  }

  return formattedPrice;
};

/**
 * Format note type for display
 */
export const formatNoteType = (noteType: string): string => {
  switch (noteType) {
    case 'deed_of_trust':
      return 'Deed of Trust';
    case 'mortgage':
      return 'Mortgage';
    case 'contract_for_deed':
      return 'Contract For Deed (CFD)';
    case 'community_lands':
      return 'Community Lands';
    case 'texas_secured_notes':
      return 'Texas Secured Notes';
    default:
      return noteType?.replace(/_/g, ' ') || '';
  }
};

/**
 * Format property type for display
 */
export const formatPropertyType = (propertyType: string): string => {
  switch (propertyType) {
    case 'single_family':
      return 'Single Family';
    case 'multi_family':
      return 'Multi-Family';
    default:
      return propertyType
        ? propertyType.charAt(0).toUpperCase() + propertyType.slice(1).replace(/_/g, ' ')
        : '';
  }
};
