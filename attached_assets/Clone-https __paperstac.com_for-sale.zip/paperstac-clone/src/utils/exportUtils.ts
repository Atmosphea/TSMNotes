import { Note } from '../../server/types';
import { saveAs } from 'file-saver';
import * as XLSX from 'xlsx';

/**
 * Formats a note property for display in exports
 */
const formatNoteProperty = (value: any, type = 'text'): string => {
  if (value === null || value === undefined) {
    return '';
  }

  switch (type) {
    case 'currency':
      return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD',
      }).format(value);

    case 'percentage':
      return `${value}%`;

    case 'date':
      if (value instanceof Date) {
        return value.toLocaleDateString();
      }
      return new Date(value).toLocaleDateString();

    case 'enum':
      return value.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase());

    default:
      return String(value);
  }
};

/**
 * Prepares note data for CSV/Excel export
 */
const prepareNotesForExport = (notes: Note[]): Record<string, string>[] => {
  return notes.map(note => ({
    'Title': note.title,
    'Description': note.description,
    'Price': formatNoteProperty(note.price, 'currency'),
    'Note Type': formatNoteProperty(note.noteType, 'enum'),
    'Lien Position': formatNoteProperty(note.lienPosition, 'enum'),
    'Performance': formatNoteProperty(note.performance, 'enum'),
    'Listing Type': formatNoteProperty(note.listingType, 'enum'),
    'Availability': formatNoteProperty(note.availability, 'enum'),
    'Property Type': formatNoteProperty(note.propertyType, 'enum'),
    'Yield': note.yield ? formatNoteProperty(note.yield, 'percentage') : '',
    'LTV': note.ltv ? formatNoteProperty(note.ltv, 'percentage') : '',
    'Has Foreclosure': note.hasForeclosure ? 'Yes' : 'No',
    'Listed Date': formatNoteProperty(note.createdAt, 'date'),
  }));
};

/**
 * Export notes to CSV file
 */
export const exportNotesToCSV = (notes: Note[], fileName = 'notes-export.csv'): void => {
  const data = prepareNotesForExport(notes);

  if (data.length === 0) {
    console.warn('No data to export');
    return;
  }

  // Get headers from the first row
  const headers = Object.keys(data[0]);

  // Build CSV string
  let csv = headers.join(',') + '\n';

  // Add rows
  data.forEach(row => {
    const values = headers.map(header => {
      const value = row[header];
      // Escape quotes and wrap in quotes if the value contains commas or quotes
      if (value.includes(',') || value.includes('"')) {
        return `"${value.replace(/"/g, '""')}"`;
      }
      return value;
    });
    csv += values.join(',') + '\n';
  });

  // Create blob and download
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
  saveAs(blob, fileName);
};

/**
 * Export notes to Excel file
 */
export const exportNotesToExcel = (notes: Note[], fileName = 'notes-export.xlsx'): void => {
  const data = prepareNotesForExport(notes);

  if (data.length === 0) {
    console.warn('No data to export');
    return;
  }

  // Create workbook and worksheet
  const workbook = XLSX.utils.book_new();
  const worksheet = XLSX.utils.json_to_sheet(data);

  // Add worksheet to workbook
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Notes');

  // Create binary string and export
  const excelBuffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
  const blob = new Blob([excelBuffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
  saveAs(blob, fileName);
};

/**
 * Export notes to PDF file
 * Note: This is a simplified version that creates a basic PDF.
 * For more advanced PDF generation, consider using a library like jspdf or pdfmake.
 */
export const exportNotesToPDF = (notes: Note[], fileName = 'notes-export.pdf'): void => {
  // This is a placeholder. In a real implementation, you would:
  // 1. Use a PDF generation library (jspdf, pdfmake, etc.)
  // 2. Format the data appropriately
  // 3. Generate a PDF blob
  // 4. Use saveAs to download the file

  console.warn('PDF export is not fully implemented. Please use CSV or Excel export instead.');

  // Example implementation using jspdf would go here
  // For now, we'll just fall back to CSV export
  exportNotesToCSV(notes, fileName.replace('.pdf', '.csv'));
};
