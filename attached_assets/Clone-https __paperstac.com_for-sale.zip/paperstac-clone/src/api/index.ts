import { Note, NoteFilterParams, SavedSearch } from '../../server/types';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:3001/api';

// For development, we'll use mock data when API is unavailable
const MOCK_DATA = {
  notes: [
    {
      id: 1,
      title: 'Partial Deed of Trust Note',
      description: 'Partial note for sale. This note is secured by a home that far exceeds the safe loan to value criteria.',
      price: 12300,
      isBestOffer: false,
      isFirmPrice: true,
      noteType: 'deed_of_trust',
      lienPosition: '1st',
      performance: 'performing',
      listingType: 'single_asset',
      availability: 'available',
      yield: null,
      itb: 10,
      itv: 6,
      ltv: 60,
      propertyType: 'single_family',
      mainImageUrl: 'https://ext.same-assets.com/1375934874/1081212478.jpeg',
      hasForeclosure: false,
      createdAt: new Date(),
      updatedAt: new Date(),
    },
    {
      id: 2,
      title: 'Mortgage Note with Kicker',
      description: 'Receive $10,000 kicker upon payoff. The borrower has been flawless.',
      price: 23500,
      isBestOffer: true,
      isFirmPrice: false,
      noteType: 'mortgage',
      lienPosition: '1st',
      performance: 'performing',
      listingType: 'single_asset',
      availability: 'available',
      yield: 11.2,
      itb: 84,
      itv: 24,
      ltv: 29,
      propertyType: 'single_family',
      mainImageUrl: 'https://ext.same-assets.com/1375934874/3492014171.jpeg',
      hasForeclosure: false,
      createdAt: new Date(),
      updatedAt: new Date(),
    },
    {
      id: 3,
      title: 'Deed of Trust for Section 8 Housing',
      description: 'Big LTV, this was 2 structures high assessed value, investment loan to nonprofit that does section 8 housing, paid alot',
      price: 20000,
      isBestOffer: true,
      isFirmPrice: false,
      noteType: 'deed_of_trust',
      lienPosition: '1st',
      performance: 'performing',
      listingType: 'single_asset',
      availability: 'available',
      yield: 9.02,
      itb: 101,
      itv: 20,
      ltv: 20,
      propertyType: 'multi_family',
      mainImageUrl: 'https://ext.same-assets.com/1375934874/2447843993.jpeg',
      hasForeclosure: false,
      createdAt: new Date(),
      updatedAt: new Date(),
    },
    {
      id: 4,
      title: 'Professionally Managed Mortgage',
      description: 'professionally managed; 5 yrs payment history;currently is awrap but underlying mortgage will be paid off by seller at closing leaving the buyer with a first lien position',
      price: 151800,
      isBestOffer: true,
      isFirmPrice: false,
      noteType: 'mortgage',
      lienPosition: '1st',
      performance: 'performing',
      listingType: 'single_asset',
      availability: 'available',
      yield: 10.62,
      itb: 100,
      itv: 58,
      ltv: 58,
      propertyType: 'single_family',
      mainImageUrl: 'https://ext.same-assets.com/1375934874/433969011.jpeg',
      hasForeclosure: false,
      createdAt: new Date(),
      updatedAt: new Date(),
    },
    {
      id: 5,
      title: 'Land Rehab Deed of Trust',
      description: '20k down, closed at title company big land rehabed house in 2022 everything good here, small payments but great ltv',
      price: 25400,
      isBestOffer: true,
      isFirmPrice: false,
      noteType: 'deed_of_trust',
      lienPosition: '1st',
      performance: 'performing',
      listingType: 'single_asset',
      availability: 'available',
      yield: null,
      itb: 102,
      itv: 56,
      ltv: 56,
      propertyType: 'land',
      mainImageUrl: 'https://ext.same-assets.com/1375934874/3877104537.jpeg',
      hasForeclosure: false,
      createdAt: new Date(),
      updatedAt: new Date(),
    },
    {
      id: 6,
      title: 'Rental Property Deed of Trust',
      description: 'Note secured by a 1,260 sf single family home with four bedrooms and one bath on .36 acres. No Zillow value available, but home recently sold for $80,000 with $10K down. Home is a rental.',
      price: 36000,
      isBestOffer: true,
      isFirmPrice: false,
      noteType: 'deed_of_trust',
      lienPosition: '1st',
      performance: 'performing',
      listingType: 'single_asset',
      availability: 'available',
      yield: 6.61,
      itb: 51,
      itv: 45,
      ltv: 88,
      propertyType: 'single_family',
      mainImageUrl: 'https://ext.same-assets.com/1375934874/3291766570.jpeg',
      hasForeclosure: false,
      createdAt: new Date(),
      updatedAt: new Date(),
    },
    {
      id: 7,
      title: 'Equity-Rich Rental Property',
      description: 'This asset has equity and borrower skin in the game. Cash flowing heavy as rentals and fully protected with all legal docs in place.',
      price: 0,
      isBestOffer: true,
      isFirmPrice: false,
      noteType: 'mortgage',
      lienPosition: '1st',
      performance: 'performing',
      listingType: 'single_asset',
      availability: 'available',
      yield: null,
      itb: null,
      itv: null,
      ltv: 62,
      propertyType: 'single_family',
      mainImageUrl: 'https://ext.same-assets.com/1375934874/2144175907.jpeg',
      hasForeclosure: false,
      createdAt: new Date(),
      updatedAt: new Date(),
    },
  ]
};

// Helper to handle API requests
const apiRequest = async <T>(
  endpoint: string,
  options: RequestInit = {}
): Promise<T> => {
  try {
    const response = await fetch(`${API_URL}${endpoint}`, {
      headers: {
        'Content-Type': 'application/json',
        ...options.headers,
      },
      ...options,
    });

    if (!response.ok) {
      throw new Error(`API error: ${response.status}`);
    }

    return await response.json();
  } catch (error) {
    console.error('API request failed:', error);
    throw error;
  }
};

// API functions for notes
export const notesApi = {
  // Get notes with filtering
  getNotes: async (filters: NoteFilterParams = {}) => {
    try {
      // Build query string from filters
      const queryParams = new URLSearchParams();

      Object.entries(filters).forEach(([key, value]) => {
        if (value !== undefined && value !== null && value !== '') {
          queryParams.append(key, String(value));
        }
      });

      const queryString = queryParams.toString();
      const endpoint = `/notes${queryString ? `?${queryString}` : ''}`;

      return await apiRequest<{ data: Note[], pagination: any }>(endpoint);
    } catch (error) {
      console.error('Failed to fetch notes:', error);

      // Return mock data in development
      if (import.meta.env.DEV) {
        console.log('Using mock data');
        const filtered = MOCK_DATA.notes.filter(note => {
          // Apply filters to mock data
          let matches = true;

          if (filters.availability && note.availability !== filters.availability) {
            matches = false;
          }

          if (filters.listingType && note.listingType !== filters.listingType) {
            matches = false;
          }

          if (filters.lienPosition && note.lienPosition !== filters.lienPosition) {
            matches = false;
          }

          if (filters.performance && note.performance !== filters.performance) {
            matches = false;
          }

          if (filters.noteType && note.noteType !== filters.noteType) {
            matches = false;
          }

          if (filters.propertyType && note.propertyType !== filters.propertyType) {
            matches = false;
          }

          return matches;
        });

        return {
          data: filtered,
          pagination: {
            page: filters.page || 1,
            limit: filters.limit || 10,
            totalCount: filtered.length,
            totalPages: Math.ceil(filtered.length / (filters.limit || 10)),
          }
        };
      }

      throw error;
    }
  },

  // Get note by ID
  getNoteById: async (id: number) => {
    try {
      return await apiRequest<Note>(`/notes/${id}`);
    } catch (error) {
      console.error(`Failed to fetch note ${id}:`, error);

      // Return mock data in development
      if (import.meta.env.DEV) {
        const note = MOCK_DATA.notes.find(n => n.id === id);
        if (note) {
          return note;
        }
      }

      throw error;
    }
  },

  // Create a new note
  createNote: async (noteData: Omit<Note, 'id' | 'createdAt' | 'updatedAt'>) => {
    return await apiRequest<Note>('/notes', {
      method: 'POST',
      body: JSON.stringify(noteData),
    });
  },

  // Update a note
  updateNote: async (id: number, noteData: Partial<Note>) => {
    return await apiRequest<Note>(`/notes/${id}`, {
      method: 'PUT',
      body: JSON.stringify(noteData),
    });
  },

  // Delete a note
  deleteNote: async (id: number) => {
    return await apiRequest(`/notes/${id}`, {
      method: 'DELETE',
    });
  },
};

// API functions for saved searches
export const getSavedSearches = async () => {
  try {
    const response = await apiRequest<{ data: SavedSearch[] }>('/users/saved-searches');
    return response.data;
  } catch (error) {
    console.error('Failed to fetch saved searches:', error);
    throw error;
  }
};

export const getSavedSearchById = async (id: number) => {
  try {
    const response = await apiRequest<{ data: SavedSearch }>(`/users/saved-searches/${id}`);
    return response.data;
  } catch (error) {
    console.error(`Failed to fetch saved search ${id}:`, error);
    throw error;
  }
};

export const createSavedSearch = async (searchData: Omit<SavedSearch, 'id' | 'userId' | 'createdAt' | 'updatedAt'>) => {
  try {
    const response = await apiRequest<{ data: SavedSearch }>('/users/saved-searches', {
      method: 'POST',
      body: JSON.stringify(searchData),
    });
    return response.data;
  } catch (error) {
    console.error('Failed to create saved search:', error);
    throw error;
  }
};

export const updateSavedSearch = async (id: number, searchData: Partial<SavedSearch>) => {
  try {
    const response = await apiRequest<{ data: SavedSearch }>(`/users/saved-searches/${id}`, {
      method: 'PUT',
      body: JSON.stringify(searchData),
    });
    return response.data;
  } catch (error) {
    console.error(`Failed to update saved search ${id}:`, error);
    throw error;
  }
};

export const deleteSavedSearch = async (id: number) => {
  try {
    await apiRequest(`/users/saved-searches/${id}`, {
      method: 'DELETE',
    });
    return true;
  } catch (error) {
    console.error(`Failed to delete saved search ${id}:`, error);
    throw error;
  }
};

// Get a shared search by token (public access)
export const getSharedSearch = async (token: string) => {
  try {
    const response = await apiRequest<{ data: SavedSearch }>(`/users/shared-searches/${token}`);
    return response.data;
  } catch (error) {
    console.error(`Failed to fetch shared search with token ${token}:`, error);
    throw error;
  }
};

// Get analytics for a shared search
export const getSearchAnalytics = async (id: number) => {
  try {
    const response = await apiRequest<{
      data: {
        totalViews: number;
        uniqueViewers: number;
        viewsByDate: Record<string, number>;
        recentViews: {
          id: number;
          searchId: number;
          viewerIp?: string;
          userAgent?: string;
          referrer?: string;
          viewedAt: string;
        }[];
      }
    }>(`/users/saved-searches/${id}/analytics`);
    return response.data;
  } catch (error) {
    console.error(`Failed to fetch analytics for search ${id}:`, error);
    throw error;
  }
};

// Toggle public/private status for a saved search
export const toggleSearchVisibility = async (id: number, isPublic: boolean) => {
  try {
    const response = await apiRequest<{ data: SavedSearch }>(`/users/saved-searches/${id}`, {
      method: 'PUT',
      body: JSON.stringify({ isPublic }),
    });
    return response.data;
  } catch (error) {
    console.error(`Failed to toggle visibility for search ${id}:`, error);
    throw error;
  }
};

// Toggle email notifications for a saved search
export const toggleEmailNotifications = async (id: number, isEmailEnabled: boolean, notificationFrequency?: 'instant' | 'daily' | 'weekly') => {
  try {
    const updateData: { isEmailEnabled: boolean; notificationFrequency?: string } = {
      isEmailEnabled,
    };

    if (notificationFrequency) {
      updateData.notificationFrequency = notificationFrequency;
    }

    const response = await apiRequest<{ data: SavedSearch }>(`/users/saved-searches/${id}`, {
      method: 'PUT',
      body: JSON.stringify(updateData),
    });
    return response.data;
  } catch (error) {
    console.error(`Failed to toggle email notifications for search ${id}:`, error);
    throw error;
  }
};

// Saved search analytics functions
export const getSavedSearchAnalytics = async (searchId: number) => {
  try {
    const response = await fetch(`${API_URL}/users/saved-searches/${searchId}/analytics`, {
      method: 'GET',
      headers: getAuthHeader(),
    });

    if (!response.ok) {
      throw new Error('Failed to fetch saved search analytics');
    }

    return await response.json();
  } catch (error) {
    console.error('Error fetching saved search analytics:', error);
    throw error;
  }
};

export const getMostUsedSearches = async () => {
  try {
    const response = await fetch(`${API_URL}/users/saved-searches/analytics/most-used`, {
      method: 'GET',
      headers: getAuthHeader(),
    });

    if (!response.ok) {
      throw new Error('Failed to fetch most used searches');
    }

    return await response.json();
  } catch (error) {
    console.error('Error fetching most used searches:', error);
    throw error;
  }
};

export const executeSavedSearch = async (searchId: number) => {
  try {
    const response = await fetch(`${API_URL}/users/saved-searches/${searchId}/execute`, {
      method: 'POST',
      headers: getAuthHeader(),
    });

    if (!response.ok) {
      throw new Error('Failed to execute saved search');
    }

    return await response.json();
  } catch (error) {
    console.error('Error executing saved search:', error);
    throw error;
  }
};

// Inquiry API
export const createInquiry = async (noteId: number, subject: string, message: string, phoneNumberRequested: boolean) => {
  try {
    const response = await fetch(`${API_URL}/inquiries`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...getAuthHeader(),
      },
      body: JSON.stringify({
        noteId,
        subject,
        message,
        phoneNumberRequested,
      }),
    });

    if (!response.ok) {
      throw new Error('Failed to create inquiry');
    }

    return await response.json();
  } catch (error) {
    console.error('Error creating inquiry:', error);
    throw error;
  }
};

export const getInquiries = async (role: 'buyer' | 'seller' = 'buyer') => {
  try {
    const response = await fetch(`${API_URL}/inquiries?role=${role}`, {
      method: 'GET',
      headers: getAuthHeader(),
    });

    if (!response.ok) {
      throw new Error('Failed to fetch inquiries');
    }

    return await response.json();
  } catch (error) {
    console.error('Error fetching inquiries:', error);
    throw error;
  }
};

export const getInquiry = async (inquiryId: number) => {
  try {
    const response = await fetch(`${API_URL}/inquiries/${inquiryId}`, {
      method: 'GET',
      headers: getAuthHeader(),
    });

    if (!response.ok) {
      throw new Error('Failed to fetch inquiry');
    }

    return await response.json();
  } catch (error) {
    console.error('Error fetching inquiry:', error);
    throw error;
  }
};

export const replyToInquiry = async (inquiryId: number, message: string) => {
  try {
    const response = await fetch(`${API_URL}/inquiries/${inquiryId}/reply`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...getAuthHeader(),
      },
      body: JSON.stringify({ message }),
    });

    if (!response.ok) {
      throw new Error('Failed to reply to inquiry');
    }

    return await response.json();
  } catch (error) {
    console.error('Error replying to inquiry:', error);
    throw error;
  }
};

export const revealPhoneNumber = async (inquiryId: number) => {
  try {
    const response = await fetch(`${API_URL}/inquiries/${inquiryId}/reveal-phone`, {
      method: 'POST',
      headers: getAuthHeader(),
    });

    if (!response.ok) {
      throw new Error('Failed to reveal phone number');
    }

    return await response.json();
  } catch (error) {
    console.error('Error revealing phone number:', error);
    throw error;
  }
};

// Time-limited offer API functions
export const placeNoteOnHold = async (
  noteId: number,
  buyerId: number,
  reason?: string,
  durationHours: number = 48
) => {
  try {
    const response = await fetch(`${API_URL}/notes/hold`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...getAuthHeader(),
      },
      body: JSON.stringify({
        noteId,
        buyerId,
        reason,
        durationHours,
      }),
    });

    if (!response.ok) {
      throw new Error('Failed to place note on hold');
    }

    return await response.json();
  } catch (error) {
    console.error('Error placing note on hold:', error);
    throw error;
  }
};

export const releaseNoteHold = async (noteId: number) => {
  try {
    const response = await fetch(`${API_URL}/notes/release/${noteId}`, {
      method: 'POST',
      headers: getAuthHeader(),
    });

    if (!response.ok) {
      throw new Error('Failed to release note from hold');
    }

    return await response.json();
  } catch (error) {
    console.error('Error releasing note from hold:', error);
    throw error;
  }
};

export const completeTransaction = async (
  noteId: number,
  buyerId: number,
  soldPrice?: number
) => {
  try {
    const response = await fetch(`${API_URL}/notes/complete-transaction`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...getAuthHeader(),
      },
      body: JSON.stringify({
        noteId,
        buyerId,
        soldPrice,
      }),
    });

    if (!response.ok) {
      throw new Error('Failed to complete transaction');
    }

    return await response.json();
  } catch (error) {
    console.error('Error completing transaction:', error);
    throw error;
  }
};

export const getNoteTransactionHistory = async (noteId: number) => {
  try {
    const response = await fetch(`${API_URL}/notes/${noteId}/history`, {
      method: 'GET',
      headers: getAuthHeader(),
    });

    if (!response.ok) {
      throw new Error('Failed to fetch transaction history');
    }

    return await response.json();
  } catch (error) {
    console.error('Error fetching transaction history:', error);
    throw error;
  }
};
