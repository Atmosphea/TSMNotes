import { API_URL } from './config';

// Types
export interface UserProfile {
  id: number;
  email: string;
  firstName: string;
  lastName: string;
  companyName?: string;
  phoneNumber?: string;
  profileImageUrl?: string;
  bio?: string;
  address?: string;
  city?: string;
  state?: string;
  zipCode?: string;
  role: string;
  status: string;
  lastLogin?: string;
  createdAt: string;
}

export interface NotificationPreference {
  id: number;
  userId: number;
  notificationType: string;
  email: boolean;
  inApp: boolean;
}

export interface UpdateProfileData {
  firstName: string;
  lastName: string;
  companyName?: string;
  phoneNumber?: string;
  bio?: string;
  address?: string;
  city?: string;
  state?: string;
  zipCode?: string;
}

export interface UpdateNotificationPreferencesData {
  preferences: {
    notificationType: string;
    email: boolean;
    inApp: boolean;
  }[];
}

export interface UserResponse {
  message?: string;
  user: UserProfile;
  notificationPreferences?: NotificationPreference[];
}

// Helper for making API requests
const userRequest = async <T>(
  endpoint: string,
  token: string,
  options: RequestInit = {}
): Promise<T> => {
  try {
    const response = await fetch(`${API_URL}/users${endpoint}`, {
      credentials: 'include',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
        ...options.headers,
      },
      ...options,
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.message || 'An error occurred');
    }

    return data;
  } catch (error) {
    console.error('User API request failed:', error);
    throw error;
  }
};

// API functions for user profiles
export const userApi = {
  // Get current user profile
  getProfile: (token: string): Promise<UserResponse> => {
    return userRequest('/me', token);
  },

  // Update user profile
  updateProfile: (
    data: UpdateProfileData,
    token: string
  ): Promise<UserResponse> => {
    return userRequest('/me', token, {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  },

  // Upload profile image
  uploadProfileImage: (
    file: File,
    token: string
  ): Promise<{ message: string; profileImageUrl: string }> => {
    const formData = new FormData();
    formData.append('image', file);

    return fetch(`${API_URL}/users/me/profile-image`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
      },
      body: formData,
    }).then((response) => {
      if (!response.ok) {
        return response.json().then((data) => {
          throw new Error(data.message || 'Failed to upload profile image');
        });
      }
      return response.json();
    });
  },

  // Delete profile image
  deleteProfileImage: (
    token: string
  ): Promise<{ message: string }> => {
    return userRequest('/me/profile-image', token, {
      method: 'DELETE',
    });
  },

  // Update notification preferences
  updateNotificationPreferences: (
    data: UpdateNotificationPreferencesData,
    token: string
  ): Promise<{ message: string; notificationPreferences: NotificationPreference[] }> => {
    return userRequest('/me/notification-preferences', token, {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  },

  // Deactivate account
  deactivateAccount: (
    token: string
  ): Promise<{ message: string }> => {
    return userRequest('/me/deactivate', token, {
      method: 'POST',
    });
  },

  // Request account deletion
  requestAccountDeletion: (
    token: string
  ): Promise<{ message: string }> => {
    return userRequest('/me/delete', token, {
      method: 'POST',
    });
  },
};
