import { API_URL } from './config';

// Types
export interface RegisterData {
  email: string;
  password: string;
  firstName: string;
  lastName: string;
  companyName?: string;
  phoneNumber?: string;
  tosAccepted: boolean;
}

export interface LoginData {
  email: string;
  password: string;
}

export interface ForgotPasswordData {
  email: string;
}

export interface ResetPasswordData {
  token: string;
  password: string;
}

export interface VerifyEmailData {
  token: string;
}

export interface ChangePasswordData {
  currentPassword: string;
  newPassword: string;
}

export interface AuthResponse {
  message: string;
  user?: {
    id: number;
    email: string;
    firstName: string;
    role: string;
  };
  tokens?: {
    accessToken: string;
    refreshToken: string;
  };
}

// Helper for making API requests with proper error handling
const authRequest = async <T>(
  endpoint: string,
  options: RequestInit = {}
): Promise<T> => {
  try {
    const response = await fetch(`${API_URL}/auth${endpoint}`, {
      credentials: 'include',
      headers: {
        'Content-Type': 'application/json',
        ...options.headers,
      },
      ...options,
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.message || 'An error occurred');
    }

    return data;
  } catch (error) {
    console.error('Auth API request failed:', error);
    throw error;
  }
};

// Authentication API functions
export const authApi = {
  // Register a new user
  register: (data: RegisterData): Promise<AuthResponse> => {
    return authRequest('/register', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  // Login user
  login: (data: LoginData): Promise<AuthResponse> => {
    return authRequest('/login', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  // Logout user
  logout: (token: string): Promise<AuthResponse> => {
    return authRequest('/logout', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
  },

  // Verify email
  verifyEmail: (data: VerifyEmailData): Promise<AuthResponse> => {
    return authRequest('/verify-email', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  // Resend verification email
  resendVerification: (email: string): Promise<AuthResponse> => {
    return authRequest('/resend-verification', {
      method: 'POST',
      body: JSON.stringify({ email }),
    });
  },

  // Request password reset
  forgotPassword: (data: ForgotPasswordData): Promise<AuthResponse> => {
    return authRequest('/forgot-password', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  // Reset password
  resetPassword: (data: ResetPasswordData): Promise<AuthResponse> => {
    return authRequest('/reset-password', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  // Change password (authenticated)
  changePassword: (
    data: ChangePasswordData,
    token: string
  ): Promise<AuthResponse> => {
    return authRequest('/change-password', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify(data),
    });
  },
};
