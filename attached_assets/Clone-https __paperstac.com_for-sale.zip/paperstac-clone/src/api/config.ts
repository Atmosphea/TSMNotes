// API URL for the backend server
export const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:3001/api';

// Default request timeout in milliseconds
export const REQUEST_TIMEOUT = 10000; // 10 seconds
