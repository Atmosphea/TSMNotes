import { Route, Switch } from 'wouter';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { AuthProvider } from './context/AuthContext';
import ProtectedRoute from './components/auth/ProtectedRoute';

// Pages
import ForSalePage from './pages/ForSalePage';
import NoteDetailsPage from './pages/NoteDetailsPage';
import LoginPage from './pages/auth/LoginPage';
import RegisterPage from './pages/auth/RegisterPage';
import ForgotPasswordPage from './pages/auth/ForgotPasswordPage';
import ResetPasswordPage from './pages/auth/ResetPasswordPage';
import VerifyEmailPage from './pages/auth/VerifyEmailPage';
import SharedSearchPage from './pages/SharedSearchPage';
import InquiriesPage from './pages/inquiries/InquiriesPage';
import InquiryDetailPage from './pages/inquiries/InquiryDetailPage';
import SavedSearchAnalyticsPage from './pages/SavedSearchAnalyticsPage'; // Added import

// Create a query client for React Query
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false,
      retry: 1,
      staleTime: 1000 * 60 * 5, // 5 minutes
    },
  },
});

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <div className="min-h-screen bg-gray-50">
          <Switch>
            {/* Public Routes */}
            <Route path="/" component={ForSalePage} />
            <Route path="/for-sale" component={ForSalePage} />
            <Route path="/note/:id" component={NoteDetailsPage} />
            <Route path="/shared-search/:token" component={SharedSearchPage} />

            {/* Auth Routes */}
            <Route path="/login" component={LoginPage} />
            <Route path="/register" component={RegisterPage} />
            <Route path="/forgot-password" component={ForgotPasswordPage} />
            <Route path="/reset-password" component={ResetPasswordPage} />
            <Route path="/verify-email" component={VerifyEmailPage} />

            {/* Buyer dashboard routes */}
            <Route path="/dashboard/buyer" component={BuyerDashboardPage} />

            {/* Inquiry routes */}
            <Route path="/dashboard/inquiries" component={InquiriesPage} />
            <Route path="/dashboard/inquiries/:id" component={InquiryDetailPage} />

            {/* Saved search routes */}
            <Route path="/dashboard/saved-searches/:id/analytics" component={SavedSearchAnalyticsPage} /> {/* Added route */}

            {/* Protected Routes Example */}
            <Route path="/profile">
              <ProtectedRoute>
                <div className="flex min-h-screen items-center justify-center">
                  <div className="rounded-lg bg-white p-8 shadow-md">
                    <h1 className="text-2xl font-bold">Profile Page</h1>
                    <p className="mt-2 text-gray-600">This is a protected route. You must be logged in to view this page.</p>
                  </div>
                </div>
              </ProtectedRoute>
            </Route>

            {/* Admin Routes Example */}
            <Route path="/admin">
              <ProtectedRoute roles={['admin']}>
                <div className="flex min-h-screen items-center justify-center">
                  <div className="rounded-lg bg-white p-8 shadow-md">
                    <h1 className="text-2xl font-bold">Admin Dashboard</h1>
                    <p className="mt-2 text-gray-600">This is an admin-only route.</p>
                  </div>
                </div>
              </ProtectedRoute>
            </Route>

            {/* 404 Page */}
            <Route>
              <div className="flex min-h-screen flex-col items-center justify-center">
                <h1 className="text-6xl font-bold text-gray-900">404</h1>
                <p className="mt-2 text-xl text-gray-600">Page not found</p>
                <a
                  href="/"
                  className="mt-6 rounded-lg bg-blue-600 px-4 py-2 font-semibold text-white hover:bg-blue-700"
                >
                  Go Home
                </a>
              </div>
            </Route>
          </Switch>
        </div>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
