import { useState, useRef, useEffect } from 'react';
import { Link, useLocation } from 'wouter';
import { useAuth } from '../../context/AuthContext';

const Header = () => {
  const { isAuthenticated, user, logout } = useAuth();
  const [location] = useLocation();

  // Menu states
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);

  // Refs for dropdown menus
  const userMenuRef = useRef<HTMLDivElement>(null);
  const navMenuRefs = useRef<Record<string, HTMLDivElement | null>>({});

  // Close dropdowns when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      // Close user menu if clicking outside
      if (isUserMenuOpen &&
          userMenuRef.current &&
          !userMenuRef.current.contains(event.target as Node)) {
        setIsUserMenuOpen(false);
      }

      // Close nav dropdowns if clicking outside
      if (activeDropdown &&
          navMenuRefs.current[activeDropdown] &&
          !navMenuRefs.current[activeDropdown]?.contains(event.target as Node)) {
        setActiveDropdown(null);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isUserMenuOpen, activeDropdown]);

  // Handle user logout
  const handleLogout = async () => {
    try {
      await logout();
      setIsUserMenuOpen(false);
    } catch (error) {
      console.error('Logout failed:', error);
    }
  };

  // Toggle dropdown for navigation items
  const handleNavHover = (dropdownName: string) => {
    setActiveDropdown(activeDropdown === dropdownName ? null : dropdownName);
  };

  // Reset dropdowns when mouse leaves the navigation area
  const handleNavLeave = () => {
    setActiveDropdown(null);
  };

  // Register ref for a dropdown
  const registerNavRef = (name: string, ref: HTMLDivElement | null) => {
    navMenuRefs.current[name] = ref;
  };

  return (
    <header className="border-b-3 border-primary bg-white shadow-sm">
      <div className="container mx-auto">
        <div className="flex items-center justify-between py-4">
          {/* Logo */}
          <div className="flex items-center">
            <Link href="/" className="flex items-center">
              <img
                src="https://ext.same-assets.com/1679569698/338821772.svg"
                alt="Paperstac logo"
                className="h-10"
              />
            </Link>
          </div>

          {/* Desktop Navigation */}
          <nav
            className="hidden md:block"
            onMouseLeave={handleNavLeave}
          >
            <ul className="flex items-center space-x-8">
              {/* Marketplace */}
              <li
                className="relative"
                onMouseEnter={() => handleNavHover('marketplace')}
                ref={(ref) => registerNavRef('marketplace', ref)}
              >
                <Link
                  href="/for-sale"
                  className={`flex items-center font-display font-semibold text-lg ${
                    location === '/for-sale' || location === '/'
                      ? 'text-primary'
                      : 'text-foreground hover:text-primary'
                  }`}
                >
                  Marketplace
                  <svg
                    className={`ml-1 h-4 w-4 transition-transform ${activeDropdown === 'marketplace' ? 'rotate-180' : ''}`}
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 20 20"
                    fill="currentColor"
                  >
                    <path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" />
                  </svg>
                </Link>

                {/* Marketplace Dropdown */}
                {activeDropdown === 'marketplace' && (
                  <div className="absolute left-0 mt-2 w-48 origin-top-left animate-fadeIn rounded-md bg-white p-2 shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none">
                    <Link href="/for-sale">
                      <a className="block rounded-md px-4 py-2 text-sm text-foreground hover:bg-primary-light hover:text-primary transition-colors">
                        Listings
                      </a>
                    </Link>
                    <Link href="/post-listing">
                      <a className="block rounded-md px-4 py-2 text-sm text-foreground hover:bg-primary-light hover:text-primary transition-colors">
                        Post Listing
                      </a>
                    </Link>
                  </div>
                )}
              </li>

              {/* Profile */}
              <li
                className="relative"
                onMouseEnter={() => handleNavHover('profile')}
                ref={(ref) => registerNavRef('profile', ref)}
              >
                <Link
                  href="/profile"
                  className={`flex items-center font-display font-semibold text-lg ${
                    location.includes('/profile')
                      ? 'text-primary'
                      : 'text-foreground hover:text-primary'
                  }`}
                >
                  Profile
                </Link>
              </li>

              {/* Learn */}
              <li
                className="relative"
                onMouseEnter={() => handleNavHover('learn')}
                ref={(ref) => registerNavRef('learn', ref)}
              >
                <Link
                  href="/learn"
                  className={`flex items-center font-display font-semibold text-lg ${
                    location.includes('/learn')
                      ? 'text-primary'
                      : 'text-foreground hover:text-primary'
                  }`}
                >
                  Learn
                </Link>
              </li>
            </ul>
          </nav>

          {/* User Authentication Actions */}
          <div className="hidden items-center space-x-4 md:flex">
            {isAuthenticated ? (
              <div className="relative" ref={userMenuRef}>
                <button
                  onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                  className="flex items-center space-x-2 rounded-md border-2 border-primary bg-white px-4 py-2 text-sm font-semibold text-primary hover:bg-primary-light transition-colors"
                >
                  <span>{user?.firstName}</span>
                  <svg
                    className={`h-4 w-4 transform text-primary transition-transform ${isUserMenuOpen ? 'rotate-180' : ''}`}
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M19 9l-7 7-7-7"
                    />
                  </svg>
                </button>

                {isUserMenuOpen && (
                  <div className="absolute right-0 mt-2 w-56 origin-top-right animate-slideUp rounded-md bg-white shadow-lg ring-1 ring-black ring-opacity-5">
                    <div className="border-b border-gray-100 px-4 py-3">
                      <p className="text-sm font-semibold text-foreground">{user?.firstName} {user?.lastName}</p>
                      <p className="text-xs text-muted-foreground">{user?.email}</p>
                    </div>
                    <div className="py-2">
                      <Link href="/profile">
                        <a className="block px-4 py-2 text-sm text-foreground hover:bg-primary-light hover:text-primary transition-colors">
                          Profile Settings
                        </a>
                      </Link>
                      <Link href="/dashboard/saved-searches">
                        <a className="block px-4 py-2 text-sm text-foreground hover:bg-primary-light hover:text-primary transition-colors">
                          Saved Searches
                        </a>
                      </Link>
                      <Link href="/dashboard/inquiries">
                        <a className="block px-4 py-2 text-sm text-foreground hover:bg-primary-light hover:text-primary transition-colors">
                          My Inquiries
                        </a>
                      </Link>
                      <button
                        onClick={handleLogout}
                        className="block w-full px-4 py-2 text-left text-sm text-destructive hover:bg-destructive/10 transition-colors"
                      >
                        Sign Out
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <>
                <Link href="/login">
                  <a className="rounded-md border-2 border-primary bg-white px-4 py-2 font-semibold text-primary hover:bg-primary-light transition-colors">
                    Login
                  </a>
                </Link>
                <Link href="/register">
                  <a className="button-primary">
                    Sign Up
                  </a>
                </Link>
              </>
            )}
          </div>

          {/* Mobile Menu Button */}
          <div className="flex items-center md:hidden">
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="inline-flex items-center justify-center rounded-md p-2 text-foreground hover:bg-primary-light hover:text-primary"
            >
              <svg
                className={`h-6 w-6 ${isMobileMenuOpen ? 'hidden' : 'block'}`}
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              </svg>
              <svg
                className={`h-6 w-6 ${isMobileMenuOpen ? 'block' : 'hidden'}`}
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="border-t border-gray-200 md:hidden">
          <div className="space-y-1 p-4">
            {/* Marketplace Section */}
            <div className="mb-4">
              <button
                onClick={() => handleNavHover(activeDropdown === 'marketplace' ? '' : 'marketplace')}
                className="flex w-full items-center justify-between py-2 text-left text-lg font-display font-semibold text-foreground"
              >
                <span>Marketplace</span>
                <svg
                  className={`h-5 w-5 transform transition-transform ${activeDropdown === 'marketplace' ? 'rotate-180' : ''}`}
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M19 9l-7 7-7-7"
                  />
                </svg>
              </button>

              {activeDropdown === 'marketplace' && (
                <div className="ml-4 mt-2 space-y-2">
                  <Link href="/for-sale">
                    <a className="block py-2 pl-4 text-base text-foreground hover:text-primary border-l-2 border-gray-200 hover:border-primary transition-colors">
                      Listings
                    </a>
                  </Link>
                  <Link href="/post-listing">
                    <a className="block py-2 pl-4 text-base text-foreground hover:text-primary border-l-2 border-gray-200 hover:border-primary transition-colors">
                      Post Listing
                    </a>
                  </Link>
                </div>
              )}
            </div>

            {/* Profile Section */}
            <Link href="/profile">
              <a className="block py-2 text-lg font-display font-semibold text-foreground hover:text-primary">
                Profile
              </a>
            </Link>

            {/* Learn Section */}
            <Link href="/learn">
              <a className="block py-2 text-lg font-display font-semibold text-foreground hover:text-primary">
                Learn
              </a>
            </Link>

            {/* Authentication */}
            <div className="mt-6 border-t border-gray-200 pt-4">
              {isAuthenticated ? (
                <>
                  <div className="mb-4 flex items-center">
                    <div className="mr-3 h-10 w-10 rounded-full bg-primary-light flex items-center justify-center text-primary font-bold">
                      {user?.firstName?.charAt(0)}
                    </div>
                    <div>
                      <p className="font-semibold text-foreground">{user?.firstName} {user?.lastName}</p>
                      <p className="text-sm text-muted-foreground">{user?.email}</p>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Link href="/profile">
                      <a className="block py-2 text-base text-foreground hover:text-primary">
                        Profile Settings
                      </a>
                    </Link>
                    <Link href="/dashboard/saved-searches">
                      <a className="block py-2 text-base text-foreground hover:text-primary">
                        Saved Searches
                      </a>
                    </Link>
                    <Link href="/dashboard/inquiries">
                      <a className="block py-2 text-base text-foreground hover:text-primary">
                        My Inquiries
                      </a>
                    </Link>
                    <button
                      onClick={handleLogout}
                      className="mt-4 w-full rounded-md bg-destructive px-4 py-2 text-center text-base font-semibold text-destructive-foreground"
                    >
                      Sign Out
                    </button>
                  </div>
                </>
              ) : (
                <div className="flex flex-col space-y-3">
                  <Link href="/login">
                    <a className="rounded-md border-2 border-primary bg-white px-4 py-2 text-center font-semibold text-primary">
                      Login
                    </a>
                  </Link>
                  <Link href="/register">
                    <a className="button-primary text-center">
                      Sign Up
                    </a>
                  </Link>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;
