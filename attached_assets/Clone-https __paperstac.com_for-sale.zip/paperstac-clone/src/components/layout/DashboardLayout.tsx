import { ReactNode, useState } from 'react';
import { Link, useLocation } from 'wouter';
import { useAuth } from '../../context/AuthContext';
import Header from './Header';
import Footer from './Footer';

interface SidebarLink {
  to: string;
  label: string;
  icon: JSX.Element;
}

interface DashboardLayoutProps {
  children: ReactNode;
  title: string;
  links: SidebarLink[];
}

const DashboardLayout = ({ children, title, links }: DashboardLayoutProps) => {
  const [location] = useLocation();
  const { user } = useAuth();
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  return (
    <div className="flex min-h-screen flex-col">
      <Header />

      <div className="flex flex-1">
        {/* Sidebar */}
        <aside
          className={`bg-gray-800 transition-all duration-300 ${
            isSidebarOpen ? 'w-64' : 'w-16'
          }`}
        >
          <div className="flex h-full flex-col">
            {/* Sidebar Header */}
            <div className="flex h-16 items-center justify-between px-4">
              {isSidebarOpen && (
                <h2 className="text-lg font-bold text-white">{title}</h2>
              )}
              <button
                onClick={toggleSidebar}
                className="rounded-md p-1 text-gray-400 hover:bg-gray-700 hover:text-white"
              >
                <svg
                  className="h-6 w-6"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  {isSidebarOpen ? (
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M11 19l-7-7 7-7m8 14l-7-7 7-7"
                    />
                  ) : (
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M13 5l7 7-7 7M5 5l7 7-7 7"
                    />
                  )}
                </svg>
              </button>
            </div>

            {/* Sidebar Links */}
            <nav className="mt-5 flex-1 space-y-1 px-2">
              {links.map((link) => {
                const isActive = location === link.to;
                return (
                  <Link key={link.to} href={link.to}>
                    <a
                      className={`group flex items-center rounded-md px-2 py-2 text-sm font-medium ${
                        isActive
                          ? 'bg-gray-900 text-white'
                          : 'text-gray-300 hover:bg-gray-700 hover:text-white'
                      }`}
                    >
                      <div className="mr-3 h-6 w-6 flex-shrink-0 text-gray-400 group-hover:text-gray-300">
                        {link.icon}
                      </div>
                      {isSidebarOpen && <span>{link.label}</span>}
                    </a>
                  </Link>
                );
              })}
            </nav>

            {/* User Info */}
            {isSidebarOpen && (
              <div className="border-t border-gray-700 p-4">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <span className="inline-flex h-10 w-10 items-center justify-center rounded-full bg-gray-600">
                      <span className="text-lg font-medium text-white">
                        {user?.firstName?.charAt(0)}
                        {user?.lastName?.charAt(0)}
                      </span>
                    </span>
                  </div>
                  <div className="ml-3">
                    <p className="text-sm font-medium text-white">
                      {user?.firstName} {user?.lastName}
                    </p>
                    <p className="text-xs text-gray-300">{user?.email}</p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 overflow-auto bg-gray-100">
          <div className="container mx-auto px-4 py-6">
            {children}
          </div>
        </main>
      </div>

      <Footer />
    </div>
  );
};

export default DashboardLayout;
