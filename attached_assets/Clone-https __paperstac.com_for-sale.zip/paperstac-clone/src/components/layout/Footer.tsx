import { Link } from 'wouter';

const Footer = () => {
  return (
    <footer className="bg-gray-800 text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 gap-8 md:grid-cols-4">
          {/* Explore Section */}
          <div>
            <h3 className="mb-4 text-lg font-semibold">Explore</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/" className="text-gray-300 hover:text-white">
                  Home
                </Link>
              </li>
              <li>
                <Link href="/for-sale" className="text-gray-300 hover:text-white">
                  For Sale
                </Link>
              </li>
              <li>
                <Link href="/about" className="text-gray-300 hover:text-white">
                  About Us
                </Link>
              </li>
              <li>
                <Link href="/login" className="text-gray-300 hover:text-white">
                  Login
                </Link>
              </li>
              <li>
                <a
                  href="https://support.paperstac.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-gray-300 hover:text-white"
                >
                  Knowledge Base
                </a>
              </li>
              <li>
                <a
                  href="https://academy.paperstac.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-gray-300 hover:text-white"
                >
                  Academy
                </a>
              </li>
            </ul>
          </div>

          {/* Follow Us Section */}
          <div>
            <h3 className="mb-4 text-lg font-semibold">Follow Us</h3>
            <ul className="space-y-2">
              <li>
                <a
                  href="https://facebook.com/paperstac"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-gray-300 hover:text-white"
                >
                  Facebook
                </a>
              </li>
              <li>
                <a
                  href="https://twitter.com/paperstac"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-gray-300 hover:text-white"
                >
                  Twitter
                </a>
              </li>
              <li>
                <a
                  href="https://youtube.com/paperstac"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-gray-300 hover:text-white"
                >
                  YouTube
                </a>
              </li>
              <li>
                <a
                  href="https://linkedin.com/company/paperstac"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-gray-300 hover:text-white"
                >
                  LinkedIn
                </a>
              </li>
              <li>
                <a
                  href="https://instagram.com/paperstac"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-gray-300 hover:text-white"
                >
                  Instagram
                </a>
              </li>
              <li>
                <a
                  href="https://podcast.paperstac.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-gray-300 hover:text-white"
                >
                  Podcast
                </a>
              </li>
            </ul>
          </div>

          {/* Contact Section */}
          <div>
            <h3 className="mb-4 text-lg font-semibold">Contact</h3>
            <address className="not-italic text-gray-300">
              <p>Paperstac</p>
              <p>1516 Hillcrest St, Ste 306</p>
              <p>Orlando, FL 32803</p>
              <p className="mt-2">
                <a href="mailto:hello@paperstac.com" className="text-gray-300 hover:text-white">
                  hello@paperstac.com
                </a>
              </p>
              <p>
                <a href="tel:4079309749" className="text-gray-300 hover:text-white">
                  407-930-9749
                </a>
              </p>
            </address>
          </div>

          {/* Latest News Section */}
          <div>
            <h3 className="mb-4 text-lg font-semibold">Latest News</h3>
            <div className="space-y-4">
              <div className="flex items-start">
                <img
                  src="https://ext.same-assets.com/1247681252/1015491578.png"
                  alt="Note Investor Guide"
                  className="mr-3 h-16 w-16 rounded object-cover"
                />
                <div>
                  <Link href="/blog/note-investor-guide" className="text-gray-300 hover:text-white">
                    Note Investor Guide: Winning Transactions as a Buyer on Paperstac
                  </Link>
                  <p className="mt-1 text-sm text-gray-400">March 18, 2025, 5:22PM</p>
                </div>
              </div>
              <div className="flex items-start">
                <img
                  src="https://ext.same-assets.com/1375934874/3512790830.png"
                  alt="Market Report"
                  className="mr-3 h-16 w-16 rounded object-cover"
                />
                <div>
                  <Link href="/blog/2024-report" className="text-gray-300 hover:text-white">
                    Paperstac's 2024 End of Year Market Report
                  </Link>
                  <p className="mt-1 text-sm text-gray-400">February 27, 2025, 10:30AM</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer Bottom */}
        <div className="mt-12 flex flex-col items-center border-t border-gray-700 pt-8 md:flex-row md:justify-between">
          <div className="mb-4 md:mb-0">
            <img
              src="https://ext.same-assets.com/1679569698/338821772.svg"
              alt="Paperstac logo"
              className="h-6"
            />
          </div>
          <div className="text-center text-sm text-gray-400">
            <p>Copyright © {new Date().getFullYear()} Paperstac Inc. All rights reserved.</p>
            <div className="mt-2 space-x-4">
              <Link href="/privacy-policy" className="text-gray-400 hover:text-white">
                Privacy Policy
              </Link>
              <Link href="/terms" className="text-gray-400 hover:text-white">
                Terms and Conditions
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
