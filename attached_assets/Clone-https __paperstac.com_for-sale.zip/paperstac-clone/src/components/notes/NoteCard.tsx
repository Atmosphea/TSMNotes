import { Link } from 'wouter';
import { Note } from '../../types';
import { formatPrice, formatPercentage, formatPriceLabel, formatNoteType, truncateText } from '../../utils/formatters';

interface NoteCardProps {
  note: Note;
}

const MetricItem = ({ label, value }: { label: string; value: string }) => (
  <div>
    <div className="text-sm font-medium text-gray-500">{label}:</div>
    <div className="font-medium">{value}</div>
  </div>
);

const NoteCard = ({ note }: NoteCardProps) => {
  const {
    id,
    title,
    description,
    price,
    isBestOffer,
    isFirmPrice,
    noteType,
    lienPosition,
    performance,
    yield: yieldValue,
    itb,
    itv,
    ltv,
    mainImageUrl,
    availability,
  } = note;

  // Format values for display
  const formattedPrice = formatPriceLabel(price, isBestOffer, isFirmPrice);
  const formattedYield = yieldValue !== null && yieldValue !== undefined ? formatPercentage(yieldValue) : 'N/A';
  const formattedITB = itb !== null && itb !== undefined ? formatPercentage(itb) : 'N/A';
  const formattedITV = itv !== null && itv !== undefined ? formatPercentage(itv) : 'N/A';
  const formattedLTV = ltv !== null && ltv !== undefined ? formatPercentage(ltv) : 'N/A';
  const formattedNoteType = formatNoteType(noteType);
  const truncatedDescription = truncateText(description, 100);

  return (
    <div className="overflow-hidden rounded-lg border border-gray-200 bg-white shadow-sm transition-all hover:shadow-md">
      <Link href={`/note/${id}`} className="block">
        <div className="relative h-48 overflow-hidden bg-gray-100">
          {mainImageUrl ? (
            <img
              src={mainImageUrl}
              alt={title}
              className="h-full w-full object-cover"
            />
          ) : (
            <div className="flex h-full w-full items-center justify-center bg-gray-200 text-gray-400">
              No Image
            </div>
          )}
          <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-gray-900 to-transparent p-4 text-white">
            <div className="text-lg font-bold">{formattedPrice}</div>
          </div>

          {/* Status overlay */}
          {availability !== 'available' && (
            <div className={`absolute top-0 right-0 m-2 rounded-full px-3 py-1 text-xs font-bold uppercase ${
              availability === 'on_hold'
                ? 'bg-amber-500 text-white'
                : availability === 'sold'
                  ? 'bg-red-600 text-white'
                  : 'bg-blue-600 text-white'
            }`}>
              {availability === 'on_hold' ? 'On Hold' : availability === 'sold' ? 'Sold' : 'Pending'}
            </div>
          )}
        </div>
      </Link>

      <div className="p-4">
        <div className="flex justify-between">
          <div className="mb-2 text-xs font-semibold uppercase tracking-wider text-blue-600">
            {formattedNoteType}
          </div>
          <div className="text-xs font-medium text-gray-500">
            {lienPosition} Lien • {performance === 'performing' ? 'Performing' : 'Non-Performing'}
          </div>
        </div>

        <h3 className="mb-2 text-lg font-bold">
          <Link href={`/note/${id}`} className="text-gray-900 hover:text-blue-600">
            {title}
          </Link>
        </h3>

        <p className="mb-4 text-sm text-gray-600">{truncatedDescription}</p>

        <div className="grid grid-cols-2 gap-3 border-t border-gray-100 pt-4 sm:grid-cols-4">
          <MetricItem label="Yield" value={formattedYield} />
          <MetricItem label="ITB" value={formattedITB} />
          <MetricItem label="ITV" value={formattedITV} />
          <MetricItem label="LTV" value={formattedLTV} />
        </div>
      </div>
    </div>
  );
};

export default NoteCard;
