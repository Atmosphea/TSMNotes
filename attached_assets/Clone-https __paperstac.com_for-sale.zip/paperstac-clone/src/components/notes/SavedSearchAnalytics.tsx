import { useState } from 'react';
import { useSavedSearchAnalytics, useExecuteSavedSearch } from '../../hooks/useSavedSearches';
import { formatDate } from '../../utils/formatters';
import { SavedSearchAnalyticsSummary, SavedSearchAction } from '../../types';

interface SavedSearchAnalyticsProps {
  searchId: number;
}

const SavedSearchAnalytics = ({ searchId }: SavedSearchAnalyticsProps) => {
  const { data, isLoading, isError } = useSavedSearchAnalytics(searchId);
  const executeMutation = useExecuteSavedSearch(searchId);

  const [isExecuting, setIsExecuting] = useState(false);
  const [executionResult, setExecutionResult] = useState<{
    count: number;
    executionTimeMs: number;
  } | null>(null);

  const summary = data?.data?.summary as SavedSearchAnalyticsSummary | undefined;

  const handleExecuteSearch = async () => {
    setIsExecuting(true);
    try {
      const result = await executeMutation.mutateAsync();
      setExecutionResult({
        count: result.data.count,
        executionTimeMs: result.data.executionTimeMs,
      });
    } catch (error) {
      console.error('Error executing search:', error);
    } finally {
      setIsExecuting(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex h-40 items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (isError) {
    return (
      <div className="rounded-lg bg-red-50 p-4 text-center">
        <h3 className="mb-2 text-lg font-medium text-red-800">Error</h3>
        <p className="text-red-700">Failed to load analytics data.</p>
      </div>
    );
  }

  if (!summary) {
    return (
      <div className="rounded-lg bg-gray-50 p-4 text-center">
        <p className="text-gray-700">No analytics data available for this search.</p>
      </div>
    );
  }

  const formatActionName = (action: string): string => {
    switch (action) {
      case 'view':
        return 'Viewed';
      case 'execute':
        return 'Executed';
      case 'create_alert':
        return 'Alert Created';
      case 'modify':
        return 'Modified';
      case 'share':
        return 'Shared';
      case 'export':
        return 'Exported';
      default:
        return action.charAt(0).toUpperCase() + action.slice(1);
    }
  };

  // Get the dates for the last 7 days
  const last7Days = Array.from({ length: 7 }, (_, i) => {
    const date = new Date();
    date.setDate(date.getDate() - (6 - i));
    return date.toISOString().split('T')[0];
  });

  // Format the usage data for the chart
  const usageData = last7Days.map(date => ({
    date,
    count: summary.usageByDate[date] || 0,
  }));

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <div className="rounded-lg border border-gray-200 bg-white p-4 shadow-sm">
          <div className="text-sm font-medium text-gray-500">Total Usage</div>
          <div className="mt-1 text-2xl font-bold">{summary.totalUsage}</div>
        </div>

        <div className="rounded-lg border border-gray-200 bg-white p-4 shadow-sm">
          <div className="text-sm font-medium text-gray-500">Avg Matches</div>
          <div className="mt-1 text-2xl font-bold">
            {summary.matchRates.avgMatches ? summary.matchRates.avgMatches.toFixed(1) : 'N/A'}
          </div>
        </div>

        <div className="rounded-lg border border-gray-200 bg-white p-4 shadow-sm">
          <div className="text-sm font-medium text-gray-500">Max Matches</div>
          <div className="mt-1 text-2xl font-bold">
            {summary.matchRates.maxMatches || 'N/A'}
          </div>
        </div>

        <div className="rounded-lg border border-gray-200 bg-white p-4 shadow-sm">
          <div className="text-sm font-medium text-gray-500">Last Used</div>
          <div className="mt-1 text-lg font-bold">
            {formatDate(summary.lastUsed)}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <div className="rounded-lg border border-gray-200 bg-white p-4 shadow-sm">
            <h3 className="mb-4 text-lg font-medium text-gray-900">Usage Over Time</h3>

            {/* Simple bar chart */}
            <div className="h-64">
              <div className="flex h-56 items-end justify-between space-x-2">
                {usageData.map((day) => (
                  <div key={day.date} className="flex flex-1 flex-col items-center">
                    <div
                      className="w-full bg-blue-500 transition-all"
                      style={{
                        height: `${Math.max(4, (day.count / Math.max(...usageData.map(d => d.count), 1)) * 100)}%`,
                        minHeight: day.count ? '1rem' : '0',
                      }}
                    ></div>
                    <div className="mt-2 text-xs text-gray-500">
                      {day.date.split('-')[2]}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        <div>
          <div className="rounded-lg border border-gray-200 bg-white p-4 shadow-sm">
            <h3 className="mb-4 text-lg font-medium text-gray-900">Actions</h3>

            <div className="space-y-4">
              {Object.entries(summary.usageByAction || {}).map(([action, count]) => (
                <div key={action} className="flex items-center justify-between">
                  <div className="text-sm text-gray-700">{formatActionName(action)}</div>
                  <div className="font-medium">{count}</div>
                </div>
              ))}

              <button
                onClick={handleExecuteSearch}
                disabled={isExecuting}
                className="mt-4 w-full rounded-md bg-blue-600 py-2 text-sm font-medium text-white hover:bg-blue-700 disabled:bg-blue-400"
              >
                {isExecuting ? 'Running...' : 'Execute Search Now'}
              </button>

              {executionResult && (
                <div className="mt-4 rounded-lg bg-green-50 p-3 text-sm">
                  <div className="font-medium text-green-800">Search Results</div>
                  <div className="mt-1 text-green-700">
                    Found {executionResult.count} matches in {executionResult.executionTimeMs}ms
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SavedSearchAnalytics;
