import { FilterState } from '../../types';
import { useState } from 'react';
import SavedSearches from './SavedSearches';

interface FilterSidebarProps {
  filters: FilterState;
  onFilterChange: (key: string, value: string | boolean | null) => void;
  onFilterReset: () => void;
  onUpdateFilters: (newFilters: FilterState) => void;
}

const FilterSidebar = ({
  filters,
  onFilterChange,
  onFilterReset,
  onUpdateFilters
}: FilterSidebarProps) => {
  const [expandedSection, setExpandedSection] = useState<string | null>('availability');

  const toggleSection = (section: string) => {
    setExpandedSection((prev) => (prev === section ? null : section));
  };

  // Helper to render filter options
  const renderFilterOptions = (
    section: string,
    options: { value: string; label: string; count?: number }[]
  ) => {
    const currentValue = filters[section] as string | undefined;

    return (
      <div className="mt-2 space-y-2">
        {options.map((option) => (
          <label key={option.value} className="flex items-center">
            <input
              type="radio"
              name={section}
              value={option.value}
              checked={currentValue === option.value}
              onChange={() => onFilterChange(section, option.value)}
              className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
            />
            <span className="ml-2 text-sm text-gray-700">
              {option.label}
              {option.count !== undefined && (
                <span className="ml-1 text-xs text-gray-500">({option.count})</span>
              )}
            </span>
          </label>
        ))}
        {currentValue && (
          <button
            onClick={() => onFilterChange(section, null)}
            className="mt-1 text-xs text-blue-600 hover:text-blue-800"
          >
            Clear
          </button>
        )}
      </div>
    );
  };

  // Helper to render range filter
  const renderRangeFilter = (
    section: string,
    label: string,
    minKey: string,
    maxKey: string,
    step = 1,
    unit = ''
  ) => {
    const minValue = filters[minKey] as string | undefined;
    const maxValue = filters[maxKey] as string | undefined;

    return (
      <div className="border-b border-gray-200 py-4">
        <button
          onClick={() => toggleSection(section)}
          className="flex w-full items-center justify-between text-left"
        >
          <h3 className="text-sm font-medium text-gray-900">{label}</h3>
          <span className="text-gray-500">
            {expandedSection === section ? (
              <svg
                className="h-5 w-5"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 15l7-7 7 7" />
              </svg>
            ) : (
              <svg
                className="h-5 w-5"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
              </svg>
            )}
          </span>
        </button>
        {expandedSection === section && (
          <div className="mt-4 space-y-3">
            <div className="flex space-x-2">
              <div className="w-1/2">
                <label htmlFor={`min-${minKey}`} className="block text-xs text-gray-500">
                  Min {unit}
                </label>
                <input
                  type="number"
                  id={`min-${minKey}`}
                  value={minValue || ''}
                  onChange={(e) => onFilterChange(minKey, e.target.value)}
                  step={step}
                  min={0}
                  className="mt-1 w-full rounded-md border border-gray-300 px-2 py-1 text-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                  placeholder="Min"
                />
              </div>
              <div className="w-1/2">
                <label htmlFor={`max-${maxKey}`} className="block text-xs text-gray-500">
                  Max {unit}
                </label>
                <input
                  type="number"
                  id={`max-${maxKey}`}
                  value={maxValue || ''}
                  onChange={(e) => onFilterChange(maxKey, e.target.value)}
                  step={step}
                  min={0}
                  className="mt-1 w-full rounded-md border border-gray-300 px-2 py-1 text-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                  placeholder="Max"
                />
              </div>
            </div>
            {(minValue || maxValue) && (
              <button
                onClick={() => {
                  onFilterChange(minKey, null);
                  onFilterChange(maxKey, null);
                }}
                className="text-xs text-blue-600 hover:text-blue-800"
              >
                Clear
              </button>
            )}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="rounded-lg border border-gray-200 bg-white shadow-sm">
      <div className="border-b border-gray-200 bg-gray-50 p-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-medium text-gray-900">Filters</h2>
          <button
            onClick={onFilterReset}
            className="text-sm text-blue-600 hover:text-blue-800"
          >
            Reset All
          </button>
        </div>
      </div>

      <div className="divide-y divide-gray-200">
        {/* Saved Searches section */}
        <SavedSearches
          filters={filters}
          onApplySearch={onUpdateFilters}
        />

        {/* Availability */}
        <div className="border-b border-gray-200 py-4 px-4">
          <button
            onClick={() => toggleSection('availability')}
            className="flex w-full items-center justify-between text-left"
          >
            <h3 className="text-sm font-medium text-gray-900">Availability</h3>
            <span className="text-gray-500">
              {expandedSection === 'availability' ? (
                <svg
                  className="h-5 w-5"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 15l7-7 7 7" />
                </svg>
              ) : (
                <svg
                  className="h-5 w-5"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              )}
            </span>
          </button>
          {expandedSection === 'availability' &&
            renderFilterOptions('availability', [
              { value: 'all', label: 'All' },
              { value: 'available', label: 'Available' },
              { value: 'pending_sale', label: 'Pending Sale' },
            ])}
        </div>

        {/* ... Rest of existing filter sections ... */}
        {/* Listing Type */}
        <div className="border-b border-gray-200 py-4 px-4">
          <button
            onClick={() => toggleSection('listingType')}
            className="flex w-full items-center justify-between text-left"
          >
            <h3 className="text-sm font-medium text-gray-900">Listing Type</h3>
            <span className="text-gray-500">
              {expandedSection === 'listingType' ? (
                <svg
                  className="h-5 w-5"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 15l7-7 7 7" />
                </svg>
              ) : (
                <svg
                  className="h-5 w-5"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              )}
            </span>
          </button>
          {expandedSection === 'listingType' &&
            renderFilterOptions('listingType', [
              { value: 'all', label: 'All' },
              { value: 'single_asset', label: 'Single Asset' },
              { value: 'asset_pool', label: 'Asset Pool' },
            ])}
        </div>

        {/* Lien Position */}
        <div className="border-b border-gray-200 py-4 px-4">
          <button
            onClick={() => toggleSection('lienPosition')}
            className="flex w-full items-center justify-between text-left"
          >
            <h3 className="text-sm font-medium text-gray-900">Lien Position</h3>
            <span className="text-gray-500">
              {expandedSection === 'lienPosition' ? (
                <svg
                  className="h-5 w-5"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 15l7-7 7 7" />
                </svg>
              ) : (
                <svg
                  className="h-5 w-5"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              )}
            </span>
          </button>
          {expandedSection === 'lienPosition' &&
            renderFilterOptions('lienPosition', [
              { value: 'all', label: 'All' },
              { value: '1st', label: '1st', count: 148 },
              { value: '2nd', label: '2nd', count: 104 },
            ])}
        </div>

        {/* Performance */}
        <div className="border-b border-gray-200 py-4 px-4">
          <button
            onClick={() => toggleSection('performance')}
            className="flex w-full items-center justify-between text-left"
          >
            <h3 className="text-sm font-medium text-gray-900">Performance</h3>
            <span className="text-gray-500">
              {expandedSection === 'performance' ? (
                <svg
                  className="h-5 w-5"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 15l7-7 7 7" />
                </svg>
              ) : (
                <svg
                  className="h-5 w-5"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              )}
            </span>
          </button>
          {expandedSection === 'performance' &&
            renderFilterOptions('performance', [
              { value: 'all', label: 'All' },
              { value: 'performing', label: 'Performing' },
              { value: 'non_performing', label: 'Non-Performing' },
            ])}
        </div>

        {/* Note Type */}
        <div className="border-b border-gray-200 py-4 px-4">
          <button
            onClick={() => toggleSection('noteType')}
            className="flex w-full items-center justify-between text-left"
          >
            <h3 className="text-sm font-medium text-gray-900">Note Type</h3>
            <span className="text-gray-500">
              {expandedSection === 'noteType' ? (
                <svg
                  className="h-5 w-5"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 15l7-7 7 7" />
                </svg>
              ) : (
                <svg
                  className="h-5 w-5"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              )}
            </span>
          </button>
          {expandedSection === 'noteType' &&
            renderFilterOptions('noteType', [
              { value: 'all', label: 'All' },
              { value: 'deed_of_trust', label: 'Deed of Trust', count: 75 },
              { value: 'mortgage', label: 'Mortgage', count: 53 },
              { value: 'contract_for_deed', label: 'Contract For Deed (CFD)', count: 36 },
              { value: 'community_lands', label: 'Community Lands', count: 15 },
              { value: 'texas_secured_notes', label: 'Texas Secured Notes', count: 9 },
            ])}
        </div>

        {/* Property Type */}
        <div className="border-b border-gray-200 py-4 px-4">
          <button
            onClick={() => toggleSection('propertyType')}
            className="flex w-full items-center justify-between text-left"
          >
            <h3 className="text-sm font-medium text-gray-900">Property Type</h3>
            <span className="text-gray-500">
              {expandedSection === 'propertyType' ? (
                <svg
                  className="h-5 w-5"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 15l7-7 7 7" />
                </svg>
              ) : (
                <svg
                  className="h-5 w-5"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              )}
            </span>
          </button>
          {expandedSection === 'propertyType' &&
            renderFilterOptions('propertyType', [
              { value: 'all', label: 'All' },
              { value: 'single_family', label: 'Single Family', count: 82 },
              { value: 'land', label: 'Land', count: 61 },
              { value: 'multi_family', label: 'Multi-Family', count: 6 },
              { value: 'condominium', label: 'Condominium', count: 7 },
              { value: 'commercial', label: 'Commercial', count: 5 },
              { value: 'other', label: 'Other', count: 3 },
            ])}
        </div>

        {/* Price Range */}
        {renderRangeFilter('price', 'Price Range', 'minPrice', 'maxPrice', 1000, '$')}

        {/* Yield Range */}
        {renderRangeFilter('yield', 'Yield Range', 'minYield', 'maxYield', 0.1, '%')}

        {/* LTV Range */}
        {renderRangeFilter('ltv', 'LTV Range', 'minLtv', 'maxLtv', 1, '%')}

        {/* State Type */}
        <div className="border-b border-gray-200 py-4 px-4">
          <button
            onClick={() => toggleSection('stateType')}
            className="flex w-full items-center justify-between text-left"
          >
            <h3 className="text-sm font-medium text-gray-900">State Type</h3>
            <span className="text-gray-500">
              {expandedSection === 'stateType' ? (
                <svg
                  className="h-5 w-5"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 15l7-7 7 7" />
                </svg>
              ) : (
                <svg
                  className="h-5 w-5"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              )}
            </span>
          </button>
          {expandedSection === 'stateType' &&
            renderFilterOptions('stateType', [
              { value: 'all', label: 'All' },
              { value: 'judicial', label: 'Judicial State', count: 148 },
              { value: 'non_judicial', label: 'Non-Judicial State', count: 104 },
            ])}
        </div>

        {/* Foreclosure */}
        <div className="py-4 px-4">
          <div className="flex items-center">
            <input
              id="hasForeclosure"
              type="checkbox"
              checked={!!filters.hasForeclosure}
              onChange={(e) => onFilterChange('hasForeclosure', e.target.checked)}
              className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
            />
            <label htmlFor="hasForeclosure" className="ml-2 text-sm text-gray-700">
              Has Foreclosure
            </label>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FilterSidebar;
