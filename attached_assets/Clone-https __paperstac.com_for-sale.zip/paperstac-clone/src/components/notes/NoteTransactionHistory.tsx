import { useState } from 'react';
import { NoteTransactionHistory as TransactionHistory } from '../../types';
import { formatDate } from '../../utils/formatters';

interface NoteTransactionHistoryProps {
  history: TransactionHistory[];
  isLoading?: boolean;
}

const NoteTransactionHistory = ({ history, isLoading = false }: NoteTransactionHistoryProps) => {
  const [isExpanded, setIsExpanded] = useState(false);

  if (isLoading) {
    return (
      <div className="py-4 text-center">
        <div className="mx-auto h-6 w-6 animate-spin rounded-full border-2 border-gray-300 border-t-blue-600"></div>
      </div>
    );
  }

  if (history.length === 0) {
    return (
      <div className="py-4 text-center text-gray-500">
        No transaction history available
      </div>
    );
  }

  // Show only the last 3 items when collapsed
  const displayItems = isExpanded ? history : history.slice(0, 3);

  return (
    <div className="rounded-lg border border-gray-200 bg-white">
      <div className="border-b border-gray-200 px-4 py-3">
        <h3 className="text-lg font-medium text-gray-900">Transaction History</h3>
      </div>

      <ul className="divide-y divide-gray-200">
        {displayItems.map((item) => (
          <li key={item.id} className="px-4 py-3">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <div className="flex items-center">
                  <StatusIndicator status={item.status} />
                  <span className="ml-2 font-medium">{getStatusTitle(item.status)}</span>
                </div>
                {item.reason && (
                  <p className="mt-1 text-sm text-gray-600">{item.reason}</p>
                )}
                {item.buyerId && (
                  <p className="mt-1 text-sm text-gray-500">
                    Buyer ID: {item.buyerId}
                  </p>
                )}
                {item.expiresAt && (
                  <p className="mt-1 text-sm text-gray-500">
                    Expires: {formatDate(item.expiresAt)}
                  </p>
                )}
              </div>
              <div className="ml-4 text-right text-sm text-gray-500">
                {formatDate(item.createdAt)}
              </div>
            </div>
          </li>
        ))}
      </ul>

      {history.length > 3 && (
        <div className="border-t border-gray-200 px-4 py-2 text-center">
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="text-sm font-medium text-blue-600 hover:text-blue-800"
          >
            {isExpanded ? 'Show Less' : `Show ${history.length - 3} More`}
          </button>
        </div>
      )}
    </div>
  );
};

const StatusIndicator = ({ status }: { status: string }) => {
  let bgColor = 'bg-gray-500';

  switch (status) {
    case 'available':
      bgColor = 'bg-green-500';
      break;
    case 'on_hold':
      bgColor = 'bg-amber-500';
      break;
    case 'pending_sale':
      bgColor = 'bg-blue-500';
      break;
    case 'sold':
      bgColor = 'bg-red-500';
      break;
  }

  return <span className={`h-3 w-3 rounded-full ${bgColor}`}></span>;
};

const getStatusTitle = (status: string): string => {
  switch (status) {
    case 'available':
      return 'Available';
    case 'on_hold':
      return 'Placed On Hold';
    case 'pending_sale':
      return 'Pending Sale';
    case 'sold':
      return 'Sold';
    default:
      return status.charAt(0).toUpperCase() + status.slice(1);
  }
};

export default NoteTransactionHistory;
