import { useState } from 'react';
import { useSavedSearches } from '../../hooks/useSavedSearches';
import { FilterState, SavedSearch } from '../../types';
import { useAuth } from '../../context/AuthContext';

interface SavedSearchesProps {
  filters: FilterState;
  onApplySearch: (filters: FilterState) => void;
}

const SavedSearches = ({ filters, onApplySearch }: SavedSearchesProps) => {
  const { isAuthenticated, user } = useAuth();
  const [isCreating, setIsCreating] = useState(false);
  const [searchName, setSearchName] = useState('');
  const [isEmailEnabled, setIsEmailEnabled] = useState(false);
  const [notificationFrequency, setNotificationFrequency] = useState<'instant' | 'daily' | 'weekly'>('daily');
  const [isPublic, setIsPublic] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [expandedSection, setExpandedSection] = useState<boolean>(false);
  const [expandedSearchId, setExpandedSearchId] = useState<number | null>(null);
  const [shareUrl, setShareUrl] = useState<string | null>(null);
  const [copySuccess, setCopySuccess] = useState(false);

  const {
    savedSearches,
    isLoading,
    createSavedSearch,
    deleteSavedSearch,
    toggleEmailNotifications,
    toggleSearchVisibility,
    applySavedSearch,
    getShareUrl,
  } = useSavedSearches();

  const toggleSection = () => {
    setExpandedSection(!expandedSection);
  };

  const toggleSearchOptions = (searchId: number) => {
    setExpandedSearchId(expandedSearchId === searchId ? null : searchId);
    setShareUrl(null);
    setCopySuccess(false);
  };

  const handleSaveSearch = async () => {
    if (!searchName.trim()) {
      setError('Please enter a name for your search');
      return;
    }

    try {
      setError(null);
      await createSavedSearch.mutateAsync({
        name: searchName,
        filters,
        isEmailEnabled,
        notificationFrequency,
        isPublic,
      });
      setSearchName('');
      setIsEmailEnabled(false);
      setNotificationFrequency('daily');
      setIsPublic(false);
      setIsCreating(false);
    } catch (err) {
      if (err instanceof Error) {
        setError(err.message);
      } else {
        setError('Failed to save search');
      }
    }
  };

  const handleDeleteSearch = async (id: number) => {
    try {
      await deleteSavedSearch.mutateAsync(id);
      if (expandedSearchId === id) {
        setExpandedSearchId(null);
      }
    } catch (err) {
      console.error('Failed to delete search:', err);
    }
  };

  const handleApplySearch = (savedSearch: SavedSearch) => {
    const newFilters = applySavedSearch(savedSearch);
    onApplySearch(newFilters);
  };

  const handleToggleEmailNotifications = async (id: number, enabled: boolean, frequency?: 'instant' | 'daily' | 'weekly') => {
    try {
      await toggleEmailNotifications.mutateAsync({
        id,
        isEmailEnabled: enabled,
        notificationFrequency: frequency,
      });
    } catch (err) {
      console.error('Failed to toggle email notifications:', err);
    }
  };

  const handleToggleSearchVisibility = async (id: number, isPublic: boolean) => {
    try {
      await toggleSearchVisibility.mutateAsync({ id, isPublic });
    } catch (err) {
      console.error('Failed to toggle search visibility:', err);
    }
  };

  const handleShareSearch = async (savedSearch: SavedSearch) => {
    // Get the share URL for the search
    const url = getShareUrl(savedSearch);
    setShareUrl(url);

    if (url) {
      try {
        await navigator.clipboard.writeText(url);
        setCopySuccess(true);
        setTimeout(() => setCopySuccess(false), 3000);
      } catch (err) {
        console.error('Failed to copy URL:', err);
      }
    }
  };

  // If not authenticated, don't render anything
  if (!isAuthenticated) {
    return null;
  }

  return (
    <div className="border-b border-gray-200 py-4 px-4">
      <button
        onClick={toggleSection}
        className="flex w-full items-center justify-between text-left"
      >
        <h3 className="text-sm font-medium text-gray-900">Saved Searches</h3>
        <span className="text-gray-500">
          {expandedSection ? (
            <svg
              className="h-5 w-5"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 15l7-7 7 7" />
            </svg>
          ) : (
            <svg
              className="h-5 w-5"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
            </svg>
          )}
        </span>
      </button>

      {expandedSection && (
        <div className="mt-4">
          {/* Save current search */}
          {!isCreating ? (
            <button
              onClick={() => setIsCreating(true)}
              className="mb-4 flex w-full items-center justify-center rounded-md bg-blue-600 px-3 py-2 text-sm font-medium text-white shadow-sm hover:bg-blue-700"
            >
              <svg
                className="mr-2 h-4 w-4"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M12 6v6m0 0v6m0-6h6m-6 0H6"
                />
              </svg>
              Save Current Search
            </button>
          ) : (
            <div className="mb-4 space-y-3 rounded-md border border-gray-200 bg-gray-50 p-3">
              <div>
                <label htmlFor="searchName" className="block text-xs text-gray-500">
                  Search Name
                </label>
                <input
                  id="searchName"
                  type="text"
                  value={searchName}
                  onChange={(e) => setSearchName(e.target.value)}
                  placeholder="Enter search name"
                  className="mt-1 w-full rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                />
              </div>

              {/* Email notification options */}
              <div className="rounded-md bg-white p-2">
                <div className="flex items-center justify-between">
                  <label className="flex items-center">
                    <input
                      type="checkbox"
                      checked={isEmailEnabled}
                      onChange={(e) => setIsEmailEnabled(e.target.checked)}
                      className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                    />
                    <span className="ml-2 text-sm text-gray-700">Email notifications</span>
                  </label>
                </div>

                {isEmailEnabled && (
                  <div className="mt-2">
                    <label className="block text-xs text-gray-500">
                      Notification Frequency
                    </label>
                    <select
                      value={notificationFrequency}
                      onChange={(e) => setNotificationFrequency(e.target.value as any)}
                      className="mt-1 w-full rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                    >
                      <option value="instant">Instant (as soon as new notes match)</option>
                      <option value="daily">Daily digest</option>
                      <option value="weekly">Weekly digest</option>
                    </select>
                  </div>
                )}
              </div>

              {/* Sharing options */}
              <div className="flex items-center">
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    checked={isPublic}
                    onChange={(e) => setIsPublic(e.target.checked)}
                    className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                  />
                  <span className="ml-2 text-sm text-gray-700">Make this search public (shareable)</span>
                </label>
              </div>

              {error && <p className="text-xs text-red-600">{error}</p>}

              <div className="flex space-x-2">
                <button
                  onClick={handleSaveSearch}
                  disabled={createSavedSearch.isPending}
                  className="flex-1 rounded-md bg-blue-600 px-3 py-2 text-sm font-medium text-white shadow-sm hover:bg-blue-700 disabled:opacity-50"
                >
                  {createSavedSearch.isPending ? 'Saving...' : 'Save'}
                </button>
                <button
                  onClick={() => {
                    setIsCreating(false);
                    setSearchName('');
                    setIsEmailEnabled(false);
                    setNotificationFrequency('daily');
                    setIsPublic(false);
                    setError(null);
                  }}
                  className="flex-1 rounded-md border border-gray-300 bg-white px-3 py-2 text-sm font-medium text-gray-700 shadow-sm hover:bg-gray-50"
                >
                  Cancel
                </button>
              </div>
            </div>
          )}

          {/* List of saved searches */}
          {isLoading ? (
            <div className="flex justify-center py-4">
              <div className="h-5 w-5 animate-spin rounded-full border-2 border-blue-600 border-t-transparent"></div>
            </div>
          ) : savedSearches.length === 0 ? (
            <p className="py-2 text-sm text-gray-500">No saved searches yet.</p>
          ) : (
            <ul className="space-y-3">
              {savedSearches.map((savedSearch) => (
                <li
                  key={savedSearch.id}
                  className="space-y-2 rounded-md border border-gray-200 bg-white shadow-sm"
                >
                  <div className="flex items-center justify-between rounded-t-md bg-gray-50 px-3 py-2">
                    <div className="flex items-center">
                      <button
                        onClick={() => handleApplySearch(savedSearch)}
                        className="text-left text-sm font-medium text-gray-700 hover:text-blue-600"
                      >
                        {savedSearch.name}
                      </button>
                      {savedSearch.isEmailEnabled && (
                        <span className="ml-2 rounded-full bg-blue-100 px-2 py-0.5 text-xs text-blue-800">
                          <svg
                            className="mr-1 inline-block h-3 w-3"
                            fill="none"
                            stroke="currentColor"
                            viewBox="0 0 24 24"
                            xmlns="http://www.w3.org/2000/svg"
                          >
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              strokeWidth={2}
                              d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"
                            />
                          </svg>
                          {savedSearch.notificationFrequency || 'daily'}
                        </span>
                      )}
                      {savedSearch.isPublic && (
                        <span className="ml-2 rounded-full bg-green-100 px-2 py-0.5 text-xs text-green-800">
                          <svg
                            className="mr-1 inline-block h-3 w-3"
                            fill="none"
                            stroke="currentColor"
                            viewBox="0 0 24 24"
                            xmlns="http://www.w3.org/2000/svg"
                          >
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              strokeWidth={2}
                              d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1"
                            />
                          </svg>
                          shared
                        </span>
                      )}
                    </div>
                    <div className="flex items-center space-x-1">
                      <button
                        onClick={() => toggleSearchOptions(savedSearch.id)}
                        className="rounded p-1 text-gray-500 hover:bg-gray-100 hover:text-gray-700"
                        aria-label="Search options"
                      >
                        <svg
                          className="h-4 w-4"
                          fill="none"
                          stroke="currentColor"
                          viewBox="0 0 24 24"
                          xmlns="http://www.w3.org/2000/svg"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M12 5v.01M12 12v.01M12 19v.01M12 6a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2z"
                          />
                        </svg>
                      </button>
                      <button
                        onClick={() => handleDeleteSearch(savedSearch.id)}
                        className="rounded p-1 text-gray-500 hover:bg-gray-100 hover:text-red-600"
                        aria-label="Delete saved search"
                      >
                        <svg
                          className="h-4 w-4"
                          fill="none"
                          stroke="currentColor"
                          viewBox="0 0 24 24"
                          xmlns="http://www.w3.org/2000/svg"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"
                          />
                        </svg>
                      </button>
                    </div>
                  </div>

                  {expandedSearchId === savedSearch.id && (
                    <div className="border-t border-gray-100 px-3 py-2">
                      {/* Email notification toggle */}
                      <div className="mb-2 flex items-center justify-between">
                        <div className="flex items-center">
                          <input
                            id={`email-notifications-${savedSearch.id}`}
                            type="checkbox"
                            checked={savedSearch.isEmailEnabled || false}
                            onChange={(e) => handleToggleEmailNotifications(
                              savedSearch.id,
                              e.target.checked,
                              savedSearch.notificationFrequency as any
                            )}
                            className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                          />
                          <label
                            htmlFor={`email-notifications-${savedSearch.id}`}
                            className="ml-2 text-sm text-gray-700"
                          >
                            Email notifications
                          </label>
                        </div>

                        {savedSearch.isEmailEnabled && (
                          <select
                            value={savedSearch.notificationFrequency || 'daily'}
                            onChange={(e) => handleToggleEmailNotifications(
                              savedSearch.id,
                              true,
                              e.target.value as any
                            )}
                            className="ml-2 rounded-md border border-gray-300 px-2 py-1 text-xs focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                          >
                            <option value="instant">Instant</option>
                            <option value="daily">Daily</option>
                            <option value="weekly">Weekly</option>
                          </select>
                        )}
                      </div>

                      {/* Sharing toggle */}
                      <div className="mb-2 flex items-center justify-between">
                        <div className="flex items-center">
                          <input
                            id={`share-search-${savedSearch.id}`}
                            type="checkbox"
                            checked={savedSearch.isPublic || false}
                            onChange={(e) => handleToggleSearchVisibility(savedSearch.id, e.target.checked)}
                            className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                          />
                          <label
                            htmlFor={`share-search-${savedSearch.id}`}
                            className="ml-2 text-sm text-gray-700"
                          >
                            Public (shareable)
                          </label>
                        </div>

                        {savedSearch.isPublic && (
                          <button
                            onClick={() => handleShareSearch(savedSearch)}
                            className="rounded-md bg-blue-100 px-2 py-1 text-xs font-medium text-blue-700 hover:bg-blue-200"
                          >
                            Share
                          </button>
                        )}
                      </div>

                      {/* Share URL display */}
                      {shareUrl && savedSearch.isPublic && (
                        <div className="mt-2 flex items-center rounded-md bg-gray-50 p-2">
                          <input
                            type="text"
                            value={shareUrl}
                            readOnly
                            className="w-full rounded border-gray-300 bg-white px-2 py-1 text-xs"
                          />
                          <button
                            onClick={() => {
                              navigator.clipboard.writeText(shareUrl);
                              setCopySuccess(true);
                              setTimeout(() => setCopySuccess(false), 3000);
                            }}
                            className="ml-2 rounded-md bg-gray-200 px-2 py-1 text-xs font-medium text-gray-700 hover:bg-gray-300"
                          >
                            {copySuccess ? 'Copied!' : 'Copy'}
                          </button>
                        </div>
                      )}
                    </div>
                  )}
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
    </div>
  );
};

export default SavedSearches;
