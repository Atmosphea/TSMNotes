import { useState } from 'react';
import { Note, User } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { usePlaceNoteOnHold, useReleaseNoteHold, useCompleteTransaction } from '../../hooks/useNoteTransactions';
import { formatDate } from '../../utils/formatters';

interface NoteTransactionActionsProps {
  note: Note;
  buyer?: User;
  onSuccess?: () => void;
}

const NoteTransactionActions = ({ note, buyer, onSuccess }: NoteTransactionActionsProps) => {
  const { user } = useAuth();
  const placeOnHoldMutation = usePlaceNoteOnHold();
  const releaseHoldMutation = useReleaseNoteHold();
  const completeTransactionMutation = useCompleteTransaction();

  const [showReleaseConfirm, setShowReleaseConfirm] = useState(false);
  const [showCompleteConfirm, setShowCompleteConfirm] = useState(false);
  const [soldPrice, setSoldPrice] = useState<string>(note.price?.toString() || '');

  const isSeller = user?.id === note.sellerId;
  const isBuyer = user?.id === note.onHoldForBuyerId;
  const isOnHold = note.availability === 'on_hold';
  const isPending = note.availability === 'pending_sale';
  const isAvailable = note.availability === 'available';
  const isSold = note.availability === 'sold';

  const canPlace = isSeller && isAvailable && buyer;
  const canRelease = (isSeller || isBuyer) && isOnHold;
  const canComplete = isSeller && isOnHold;

  const handlePlaceOnHold = async () => {
    if (!buyer) return;

    try {
      await placeOnHoldMutation.mutateAsync({
        noteId: note.id,
        buyerId: buyer.id,
        reason: `Reserved for ${buyer.firstName} ${buyer.lastName}`,
      });

      if (onSuccess) onSuccess();
    } catch (error) {
      console.error('Failed to place note on hold:', error);
    }
  };

  const handleReleaseHold = async () => {
    try {
      await releaseHoldMutation.mutateAsync(note.id);
      setShowReleaseConfirm(false);

      if (onSuccess) onSuccess();
    } catch (error) {
      console.error('Failed to release note from hold:', error);
    }
  };

  const handleCompleteTransaction = async () => {
    if (!note.onHoldForBuyerId) return;

    try {
      const price = parseFloat(soldPrice);
      if (isNaN(price) || price <= 0) {
        alert('Please enter a valid price');
        return;
      }

      await completeTransactionMutation.mutateAsync({
        noteId: note.id,
        buyerId: note.onHoldForBuyerId,
        soldPrice: price,
      });

      setShowCompleteConfirm(false);

      if (onSuccess) onSuccess();
    } catch (error) {
      console.error('Failed to complete transaction:', error);
    }
  };

  // If the note is on hold, show details about the hold
  if (isOnHold) {
    return (
      <div className="space-y-4">
        <div className="rounded-lg border border-amber-200 bg-amber-50 p-4">
          <div className="mb-2 flex items-center">
            <div className="mr-2 h-3 w-3 rounded-full bg-amber-500"></div>
            <h3 className="font-bold text-amber-800">Note On Hold</h3>
          </div>

          <p className="mb-2 text-sm text-amber-700">
            This note is currently reserved and not available for general purchase.
            The hold expires in {formatDate(note.onHoldUntil || '')}.
          </p>

          {canRelease && (
            <div className="mt-3">
              {showReleaseConfirm ? (
                <div className="space-y-2">
                  <p className="text-sm font-medium text-amber-800">
                    Are you sure you want to release this hold? The note will be available to all buyers.
                  </p>
                  <div className="flex space-x-2">
                    <button
                      onClick={handleReleaseHold}
                      disabled={releaseHoldMutation.isLoading}
                      className="rounded-md bg-amber-600 px-3 py-1 text-sm font-medium text-white hover:bg-amber-700 disabled:opacity-70"
                    >
                      {releaseHoldMutation.isLoading ? 'Processing...' : 'Yes, Release'}
                    </button>
                    <button
                      onClick={() => setShowReleaseConfirm(false)}
                      className="rounded-md border border-amber-600 px-3 py-1 text-sm font-medium text-amber-600 hover:bg-amber-50"
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              ) : (
                <button
                  onClick={() => setShowReleaseConfirm(true)}
                  className="rounded-md bg-amber-100 px-3 py-1 text-sm font-medium text-amber-800 hover:bg-amber-200"
                >
                  Release Hold
                </button>
              )}
            </div>
          )}

          {canComplete && (
            <div className="mt-3">
              {showCompleteConfirm ? (
                <div className="space-y-2">
                  <p className="text-sm font-medium text-amber-800">
                    Complete this transaction? The note will be marked as sold and removed from the marketplace.
                  </p>
                  <div className="flex items-center space-x-2">
                    <span className="text-sm text-amber-800">Sale Price: $</span>
                    <input
                      type="number"
                      value={soldPrice}
                      onChange={(e) => setSoldPrice(e.target.value)}
                      className="w-32 rounded-md border border-amber-300 bg-white px-2 py-1 text-sm"
                      min="0"
                      step="0.01"
                    />
                  </div>
                  <div className="flex space-x-2">
                    <button
                      onClick={handleCompleteTransaction}
                      disabled={completeTransactionMutation.isLoading}
                      className="rounded-md bg-green-600 px-3 py-1 text-sm font-medium text-white hover:bg-green-700 disabled:opacity-70"
                    >
                      {completeTransactionMutation.isLoading ? 'Processing...' : 'Complete Sale'}
                    </button>
                    <button
                      onClick={() => setShowCompleteConfirm(false)}
                      className="rounded-md border border-amber-600 px-3 py-1 text-sm font-medium text-amber-600 hover:bg-amber-50"
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              ) : (
                <button
                  onClick={() => setShowCompleteConfirm(true)}
                  className="rounded-md bg-green-600 px-3 py-1 text-sm font-medium text-white hover:bg-green-700"
                >
                  Complete Transaction
                </button>
              )}
            </div>
          )}
        </div>
      </div>
    );
  }

  // If the note is available and current user is the seller, show the option to put on hold
  if (canPlace) {
    return (
      <div className="space-y-2">
        <button
          onClick={handlePlaceOnHold}
          disabled={placeOnHoldMutation.isLoading}
          className="w-full rounded-lg border border-amber-600 py-2 font-medium text-amber-600 hover:bg-amber-50 disabled:opacity-70"
        >
          {placeOnHoldMutation.isLoading ? 'Processing...' : `Reserve for ${buyer.firstName} ${buyer.lastName}`}
        </button>
        <p className="text-xs text-gray-500">
          This will place the note on hold for 48 hours exclusively for this buyer.
        </p>
      </div>
    );
  }

  // If the note is sold, indicate that
  if (isSold && isSeller) {
    return (
      <div className="rounded-lg border border-green-200 bg-green-50 p-4">
        <div className="mb-2 flex items-center">
          <div className="mr-2 h-3 w-3 rounded-full bg-green-500"></div>
          <h3 className="font-bold text-green-800">Note Sold</h3>
        </div>
        <p className="text-sm text-green-700">
          This note has been sold and is no longer available in the marketplace.
        </p>
      </div>
    );
  }

  // For cases where no action is available
  return null;
};

export default NoteTransactionActions;
