import { useState } from 'react';
import { Note } from '../../../server/types';
import { exportNotesToCSV, exportNotesToExcel, exportNotesToPDF } from '../../utils/exportUtils';

interface SearchExportProps {
  notes: Note[];
  totalCount: number;
  showAllRecords?: boolean;
  onExportAll?: () => Promise<Note[]>;
  isLoading?: boolean;
}

const SearchExport = ({
  notes,
  totalCount,
  showAllRecords = false,
  onExportAll,
  isLoading = false
}: SearchExportProps) => {
  const [exportFormat, setExportFormat] = useState<'csv' | 'excel' | 'pdf'>('csv');
  const [exportLoading, setExportLoading] = useState(false);
  const [exportError, setExportError] = useState<string | null>(null);

  const handleExport = async () => {
    setExportLoading(true);
    setExportError(null);

    try {
      let dataToExport = notes;

      // If we're exporting all and there's more data than what we have loaded
      if (!showAllRecords && onExportAll && totalCount > notes.length) {
        try {
          dataToExport = await onExportAll();
        } catch (error) {
          console.error('Failed to fetch all notes for export:', error);
          setExportError('Failed to fetch all notes for export. Exporting current page only.');
          dataToExport = notes; // Fall back to current page
        }
      }

      // Generate filename with current date
      const dateStr = new Date().toISOString().split('T')[0];
      const filename = `paperstac-notes-${dateStr}`;

      // Export according to selected format
      switch (exportFormat) {
        case 'csv':
          exportNotesToCSV(dataToExport, `${filename}.csv`);
          break;
        case 'excel':
          exportNotesToExcel(dataToExport, `${filename}.xlsx`);
          break;
        case 'pdf':
          exportNotesToPDF(dataToExport, `${filename}.pdf`);
          break;
      }
    } catch (error) {
      console.error('Export error:', error);
      setExportError('An error occurred during export. Please try again.');
    } finally {
      setExportLoading(false);
    }
  };

  return (
    <div className="mt-4 rounded-lg border border-gray-200 bg-white p-4 shadow-sm">
      <h3 className="mb-3 text-lg font-medium text-gray-900">Export Results</h3>

      <div className="mb-3 flex items-center">
        <span className="mr-3 text-sm text-gray-600">Format:</span>
        <div className="flex space-x-3">
          <label className="flex items-center">
            <input
              type="radio"
              name="exportFormat"
              value="csv"
              checked={exportFormat === 'csv'}
              onChange={() => setExportFormat('csv')}
              className="h-4 w-4 border-gray-300 text-blue-600 focus:ring-blue-500"
            />
            <span className="ml-2 text-sm text-gray-700">CSV</span>
          </label>
          <label className="flex items-center">
            <input
              type="radio"
              name="exportFormat"
              value="excel"
              checked={exportFormat === 'excel'}
              onChange={() => setExportFormat('excel')}
              className="h-4 w-4 border-gray-300 text-blue-600 focus:ring-blue-500"
            />
            <span className="ml-2 text-sm text-gray-700">Excel</span>
          </label>
          <label className="flex items-center">
            <input
              type="radio"
              name="exportFormat"
              value="pdf"
              checked={exportFormat === 'pdf'}
              onChange={() => setExportFormat('pdf')}
              className="h-4 w-4 border-gray-300 text-blue-600 focus:ring-blue-500"
            />
            <span className="ml-2 text-sm text-gray-700">PDF</span>
          </label>
        </div>
      </div>

      {exportError && (
        <div className="mb-3 rounded-md bg-red-50 p-2 text-sm text-red-600">
          {exportError}
        </div>
      )}

      <div className="flex items-center justify-between">
        <div className="text-sm text-gray-600">
          {showAllRecords
            ? `Exporting all ${totalCount} records`
            : `Exporting ${notes.length} of ${totalCount} records`}
        </div>
        <button
          onClick={handleExport}
          disabled={isLoading || exportLoading || notes.length === 0}
          className="rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white shadow-sm hover:bg-blue-700 disabled:bg-blue-300"
        >
          {exportLoading ? (
            <>
              <span className="mr-2 inline-block h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent"></span>
              Exporting...
            </>
          ) : (
            'Export'
          )}
        </button>
      </div>
    </div>
  );
};

export default SearchExport;
