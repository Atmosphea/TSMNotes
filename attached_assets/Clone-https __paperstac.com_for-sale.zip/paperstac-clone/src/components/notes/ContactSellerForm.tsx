import { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useCreateInquiry } from '../../hooks/useInquiries';

interface ContactSellerFormProps {
  noteId: number;
  onSuccess?: () => void;
}

const ContactSellerForm = ({ noteId, onSuccess }: ContactSellerFormProps) => {
  const { user, isAuthenticated } = useAuth();
  const { createInquiry, isSubmitting, error: submitError } = useCreateInquiry();

  const [isOpen, setIsOpen] = useState(false);
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [phoneNumberRequested, setPhoneNumberRequested] = useState(false);
  const [validationError, setValidationError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    setValidationError(null);
    setSuccessMessage(null);

    if (!subject.trim()) {
      setValidationError('Please enter a subject');
      return;
    }

    if (!message.trim()) {
      setValidationError('Please enter a message');
      return;
    }

    try {
      await createInquiry(noteId, subject, message, phoneNumberRequested);
      setSuccessMessage('Your inquiry has been sent successfully!');
      setSubject('');
      setMessage('');
      setPhoneNumberRequested(false);

      // Close the form after a short delay
      setTimeout(() => {
        setIsOpen(false);
        if (onSuccess) onSuccess();
      }, 2000);
    } catch (error) {
      // Error is already handled in the hook
      console.error('Failed to send inquiry:', error);
    }
  };

  if (!isOpen) {
    return (
      <button
        onClick={() => setIsOpen(true)}
        className="w-full rounded-lg bg-blue-600 py-3 font-semibold text-white hover:bg-blue-700 transition-colors"
      >
        Contact Seller
      </button>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="rounded-lg border border-blue-200 bg-blue-50 p-4 text-center">
        <p className="text-blue-800">Please log in to contact the seller.</p>
        <button
          onClick={() => setIsOpen(false)}
          className="mt-2 rounded bg-white px-3 py-1 text-sm font-medium text-blue-600 hover:bg-gray-100"
        >
          Close
        </button>
      </div>
    );
  }

  return (
    <div className="rounded-lg border border-gray-200 bg-white p-4 shadow-sm">
      <div className="mb-3 flex items-center justify-between">
        <h3 className="text-lg font-semibold">Contact Seller</h3>
        <button
          onClick={() => setIsOpen(false)}
          className="rounded-full p-1 text-gray-500 hover:bg-gray-100 hover:text-gray-700"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
          </svg>
        </button>
      </div>

      {successMessage && (
        <div className="mb-4 rounded-lg bg-green-50 p-3 text-green-800">
          {successMessage}
        </div>
      )}

      {(validationError || submitError) && (
        <div className="mb-4 rounded-lg bg-red-50 p-3 text-red-800">
          {validationError || submitError}
        </div>
      )}

      <form onSubmit={handleSubmit}>
        <div className="mb-4">
          <label htmlFor="subject" className="mb-1 block text-sm font-medium text-gray-700">
            Subject
          </label>
          <input
            type="text"
            id="subject"
            value={subject}
            onChange={(e) => setSubject(e.target.value)}
            className="w-full rounded-md border border-gray-300 p-2 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
            disabled={isSubmitting}
          />
        </div>

        <div className="mb-4">
          <label htmlFor="message" className="mb-1 block text-sm font-medium text-gray-700">
            Message
          </label>
          <textarea
            id="message"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            rows={4}
            className="w-full rounded-md border border-gray-300 p-2 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
            disabled={isSubmitting}
          ></textarea>
        </div>

        <div className="mb-4">
          <div className="flex items-center">
            <input
              type="checkbox"
              id="requestPhone"
              checked={phoneNumberRequested}
              onChange={(e) => setPhoneNumberRequested(e.target.checked)}
              className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
              disabled={isSubmitting}
            />
            <label htmlFor="requestPhone" className="ml-2 block text-sm text-gray-700">
              Request seller's phone number
            </label>
          </div>
        </div>

        <button
          type="submit"
          className="w-full rounded-lg bg-blue-600 py-2 font-semibold text-white hover:bg-blue-700 disabled:bg-blue-400 transition-colors"
          disabled={isSubmitting}
        >
          {isSubmitting ? 'Sending...' : 'Send Inquiry'}
        </button>
      </form>
    </div>
  );
};

export default ContactSellerForm;
