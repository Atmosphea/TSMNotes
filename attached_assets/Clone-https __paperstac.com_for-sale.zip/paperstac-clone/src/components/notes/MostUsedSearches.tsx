import { useState } from 'react';
import { Link } from 'wouter';
import { useMostUsedSearches } from '../../hooks/useSavedSearches';
import { SavedSearch } from '../../types';
import { formatDate } from '../../utils/formatters';

interface MostUsedSearchesProps {
  limit?: number;
  onSelectSearch?: (search: SavedSearch) => void;
}

const MostUsedSearches = ({ limit = 5, onSelectSearch }: MostUsedSearchesProps) => {
  const { data, isLoading, isError } = useMostUsedSearches();

  if (isLoading) {
    return (
      <div className="flex h-20 items-center justify-center">
        <div className="h-6 w-6 animate-spin rounded-full border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (isError) {
    return (
      <div className="rounded-lg border border-red-200 bg-red-50 p-3 text-center text-sm text-red-800">
        Failed to load most used searches
      </div>
    );
  }

  const searches = data?.data || [];
  const displaySearches = searches.slice(0, limit);

  if (displaySearches.length === 0) {
    return (
      <div className="rounded-lg border border-gray-200 bg-gray-50 p-3 text-center text-sm text-gray-600">
        No saved searches found
      </div>
    );
  }

  return (
    <div className="rounded-lg border border-gray-200 bg-white shadow-sm">
      <div className="border-b border-gray-200 px-4 py-3">
        <h3 className="text-lg font-medium text-gray-900">Most Used Searches</h3>
      </div>

      <ul className="divide-y divide-gray-200">
        {displaySearches.map((search: any) => (
          <li key={search.id} className="px-4 py-3 hover:bg-gray-50">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
              <div>
                <span className="text-md font-medium text-gray-900">{search.name}</span>

                <div className="mt-1 flex flex-wrap gap-2">
                  {search.noteType && (
                    <span className="rounded-full bg-blue-100 px-2 py-0.5 text-xs font-medium text-blue-800">
                      {formatNoteType(search.noteType)}
                    </span>
                  )}

                  {search.propertyType && (
                    <span className="rounded-full bg-green-100 px-2 py-0.5 text-xs font-medium text-green-800">
                      {formatPropertyType(search.propertyType)}
                    </span>
                  )}

                  {search.hasForeclosure && (
                    <span className="rounded-full bg-orange-100 px-2 py-0.5 text-xs font-medium text-orange-800">
                      Foreclosure
                    </span>
                  )}

                  {(search.minPrice || search.maxPrice) && (
                    <span className="rounded-full bg-purple-100 px-2 py-0.5 text-xs font-medium text-purple-800">
                      {search.minPrice ? '$' + search.minPrice.toLocaleString() : '$0'}
                      {' - '}
                      {search.maxPrice ? '$' + search.maxPrice.toLocaleString() : 'Any'}
                    </span>
                  )}
                </div>
              </div>

              <div className="mt-2 flex flex-col items-end sm:mt-0">
                <span className="rounded-full bg-gray-100 px-2 py-0.5 text-xs font-medium text-gray-800">
                  Used {search.usageCount} times
                </span>

                <div className="mt-2 flex space-x-2">
                  <Link
                    href={`/dashboard/saved-searches/${search.id}/analytics`}
                    className="rounded bg-blue-50 px-2 py-1 text-xs font-medium text-blue-700 hover:bg-blue-100"
                  >
                    Analytics
                  </Link>

                  {onSelectSearch && (
                    <button
                      onClick={() => onSelectSearch(search)}
                      className="rounded bg-green-50 px-2 py-1 text-xs font-medium text-green-700 hover:bg-green-100"
                    >
                      Use This Search
                    </button>
                  )}
                </div>
              </div>
            </div>
          </li>
        ))}
      </ul>

      {searches.length > limit && (
        <div className="border-t border-gray-200 p-3 text-center">
          <Link
            href="/dashboard/saved-searches"
            className="text-sm font-medium text-blue-600 hover:text-blue-800"
          >
            View All Saved Searches
          </Link>
        </div>
      )}
    </div>
  );
};

// Helper functions for formatting
const formatNoteType = (noteType: string): string => {
  return noteType.split('_').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
};

const formatPropertyType = (propertyType: string): string => {
  return propertyType.split('_').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
};

export default MostUsedSearches;
