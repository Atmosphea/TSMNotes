import { useState } from 'react';
import { Inquiry, InquiryReply } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { useReplyToInquiry, useRevealPhoneNumber } from '../../hooks/useInquiries';
import { formatDate } from '../../utils/formatters';

interface InquiryDetailsCardProps {
  inquiry: Inquiry;
  onReplySuccess?: () => void;
}

const InquiryDetailsCard = ({ inquiry, onReplySuccess }: InquiryDetailsCardProps) => {
  const { user } = useAuth();
  const [replyText, setReplyText] = useState('');
  const replyMutation = useReplyToInquiry(inquiry.id);
  const revealPhoneMutation = useRevealPhoneNumber(inquiry.id);

  const isBuyer = user?.id === inquiry.buyerId;
  const isSeller = inquiry.note?.sellerId === user?.id;

  const buyer = inquiry.buyer;
  const note = inquiry.note;

  const handleSubmitReply = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!replyText.trim()) return;

    try {
      await replyMutation.mutateAsync(replyText);
      setReplyText('');
      if (onReplySuccess) onReplySuccess();
    } catch (error) {
      console.error('Failed to send reply:', error);
    }
  };

  const handleRevealPhone = async () => {
    try {
      const result = await revealPhoneMutation.mutateAsync();
      alert(`Phone number: ${result.phoneNumber}`);
    } catch (error) {
      console.error('Failed to reveal phone number:', error);
    }
  };

  return (
    <div className="space-y-6">
      {/* Inquiry Header */}
      <div className="rounded-lg border border-gray-200 bg-white p-5 shadow-sm">
        <div className="mb-4 flex items-center justify-between">
          <h3 className="text-lg font-semibold">{inquiry.subject}</h3>
          <span className="text-sm text-gray-500">{formatDate(inquiry.createdAt)}</span>
        </div>

        <div className="mb-4 flex flex-wrap items-center gap-2">
          <span className="flex items-center rounded-full bg-gray-100 px-3 py-1 text-xs font-medium text-gray-700">
            {inquiry.status === 'new' ? (
              <span className="mr-1 h-2 w-2 rounded-full bg-green-500"></span>
            ) : inquiry.status === 'viewed' ? (
              <span className="mr-1 h-2 w-2 rounded-full bg-blue-500"></span>
            ) : inquiry.status === 'replied' ? (
              <span className="mr-1 h-2 w-2 rounded-full bg-purple-500"></span>
            ) : (
              <span className="mr-1 h-2 w-2 rounded-full bg-gray-500"></span>
            )}
            Status: {inquiry.status.charAt(0).toUpperCase() + inquiry.status.slice(1)}
          </span>

          {inquiry.phoneNumberRequested && (
            <span className="rounded-full bg-blue-100 px-3 py-1 text-xs font-medium text-blue-700">
              Phone Number Requested
            </span>
          )}

          {inquiry.phoneNumberRevealed && (
            <span className="rounded-full bg-green-100 px-3 py-1 text-xs font-medium text-green-700">
              Phone Number Revealed
            </span>
          )}
        </div>

        <div className="mb-4 rounded-md bg-gray-50 p-4">
          <div className="mb-1 flex items-center">
            <div className="mr-2 h-8 w-8 overflow-hidden rounded-full bg-gray-200">
              {buyer?.profileImageUrl ? (
                <img src={buyer.profileImageUrl} alt={`${buyer.firstName}'s avatar`} className="h-full w-full object-cover" />
              ) : (
                <div className="flex h-full w-full items-center justify-center bg-blue-100 text-blue-500">
                  {buyer?.firstName?.[0]}
                </div>
              )}
            </div>
            <span className="font-medium">
              {buyer?.firstName} {buyer?.lastName}
              {buyer?.companyName && <span className="ml-1 text-sm text-gray-500">({buyer.companyName})</span>}
            </span>
          </div>
          <div className="mt-2 whitespace-pre-line text-gray-700">{inquiry.message}</div>
        </div>

        {/* Note Info */}
        <div className="mb-4 rounded border border-gray-200 p-3">
          <div className="mb-1 text-sm font-medium text-gray-500">Regarding Note:</div>
          <div className="flex items-center justify-between">
            <div>
              <div className="font-medium">{note?.title}</div>
              <div className="text-sm text-gray-500">${note?.price.toLocaleString()}</div>
            </div>
            <a
              href={`/note/${note?.id}`}
              target="_blank"
              rel="noopener noreferrer"
              className="rounded bg-blue-50 px-3 py-1 text-sm font-medium text-blue-600 hover:bg-blue-100"
            >
              View Note
            </a>
          </div>
        </div>

        {/* Phone number reveal for seller */}
        {isSeller && inquiry.phoneNumberRequested && !inquiry.phoneNumberRevealed && (
          <div className="mb-4 rounded-lg border border-blue-200 bg-blue-50 p-4">
            <div className="mb-2 font-medium text-blue-800">Phone Number Request</div>
            <p className="mb-3 text-sm text-blue-700">
              The buyer has requested your phone number. If you wish to proceed with this inquiry, you can reveal your phone number.
            </p>
            <button
              onClick={handleRevealPhone}
              disabled={revealPhoneMutation.isLoading}
              className="rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700 disabled:bg-blue-400"
            >
              {revealPhoneMutation.isLoading ? 'Processing...' : 'Reveal My Phone Number'}
            </button>
          </div>
        )}
      </div>

      {/* Replies */}
      {inquiry.replies && inquiry.replies.length > 0 && (
        <div className="rounded-lg border border-gray-200 bg-white p-5 shadow-sm">
          <h3 className="mb-4 text-lg font-semibold">Conversation</h3>

          <div className="space-y-4">
            {inquiry.replies.map((reply: InquiryReply) => (
              <div
                key={reply.id}
                className={`rounded-lg p-4 ${
                  reply.userId === user?.id ? 'ml-8 bg-blue-50' : 'mr-8 bg-gray-50'
                }`}
              >
                <div className="mb-1 flex items-center justify-between">
                  <div className="flex items-center">
                    <div className="mr-2 h-6 w-6 overflow-hidden rounded-full bg-gray-200">
                      {reply.user?.profileImageUrl ? (
                        <img src={reply.user.profileImageUrl} alt="Avatar" className="h-full w-full object-cover" />
                      ) : (
                        <div className="flex h-full w-full items-center justify-center bg-blue-100 text-blue-500">
                          {reply.user?.firstName?.[0]}
                        </div>
                      )}
                    </div>
                    <span className="text-sm font-medium">
                      {reply.user?.firstName} {reply.user?.lastName}
                    </span>
                  </div>
                  <span className="text-xs text-gray-500">{formatDate(reply.createdAt)}</span>
                </div>
                <div className="mt-1 whitespace-pre-line text-gray-700">{reply.message}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Reply form */}
      <div className="rounded-lg border border-gray-200 bg-white p-5 shadow-sm">
        <h3 className="mb-4 text-lg font-semibold">Reply</h3>

        <form onSubmit={handleSubmitReply}>
          <div className="mb-4">
            <textarea
              value={replyText}
              onChange={(e) => setReplyText(e.target.value)}
              placeholder="Type your reply here..."
              rows={4}
              className="w-full rounded-md border border-gray-300 p-2 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
              disabled={replyMutation.isLoading}
            ></textarea>
          </div>

          <div className="flex justify-end">
            <button
              type="submit"
              disabled={replyMutation.isLoading || !replyText.trim()}
              className="rounded-md bg-blue-600 px-4 py-2 font-medium text-white hover:bg-blue-700 disabled:bg-blue-400"
            >
              {replyMutation.isLoading ? 'Sending...' : 'Send Reply'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default InquiryDetailsCard;
