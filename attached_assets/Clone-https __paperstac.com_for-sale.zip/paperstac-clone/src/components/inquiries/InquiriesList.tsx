import { useEffect, useState } from 'react';
import { Link } from 'wouter';
import { Inquiry } from '../../types';
import { formatDate } from '../../utils/formatters';

interface InquiriesListProps {
  inquiries: Inquiry[];
  role?: 'buyer' | 'seller';
  isLoading?: boolean;
}

const InquiriesList = ({ inquiries, role = 'buyer', isLoading = false }: InquiriesListProps) => {
  if (isLoading) {
    return (
      <div className="flex h-40 items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (inquiries.length === 0) {
    return (
      <div className="rounded-lg border border-gray-200 bg-gray-50 p-8 text-center">
        <svg
          xmlns="http://www.w3.org/2000/svg"
          className="mx-auto mb-4 h-12 w-12 text-gray-400"
          fill="none"
          viewBox="0 0 24 24"
          stroke="currentColor"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={1.5}
            d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z"
          />
        </svg>
        <h3 className="mb-1 text-lg font-medium text-gray-900">No inquiries yet</h3>
        <p className="text-gray-600">
          {role === 'buyer'
            ? 'When you contact sellers about notes, your inquiries will appear here.'
            : 'When buyers contact you about your notes, inquiries will appear here.'}
        </p>
      </div>
    );
  }

  return (
    <div className="overflow-hidden rounded-lg border border-gray-200 bg-white">
      <table className="min-w-full divide-y divide-gray-200">
        <thead className="bg-gray-50">
          <tr>
            <th
              scope="col"
              className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500"
            >
              Subject / Note
            </th>
            <th
              scope="col"
              className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500"
            >
              {role === 'buyer' ? 'Seller' : 'Buyer'}
            </th>
            <th
              scope="col"
              className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500"
            >
              Status
            </th>
            <th
              scope="col"
              className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500"
            >
              Date
            </th>
            <th scope="col" className="relative px-6 py-3">
              <span className="sr-only">View</span>
            </th>
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-200 bg-white">
          {inquiries.map((inquiry) => {
            // For buyer role, we need seller info from the note
            const counterparty = role === 'buyer'
              ? inquiry.note?.seller
              : inquiry.buyer;

            // Status indicator color
            let statusColor = 'bg-gray-100 text-gray-800';
            if (inquiry.status === 'new') statusColor = 'bg-green-100 text-green-800';
            else if (inquiry.status === 'viewed') statusColor = 'bg-blue-100 text-blue-800';
            else if (inquiry.status === 'replied') statusColor = 'bg-purple-100 text-purple-800';

            // Unread indicator
            const isUnread = !inquiry.isRead;

            return (
              <tr key={inquiry.id} className={isUnread ? 'bg-blue-50' : ''}>
                <td className="whitespace-nowrap px-6 py-4">
                  <div className="text-sm font-medium text-gray-900">
                    {inquiry.subject}
                  </div>
                  <div className="text-sm text-gray-500">{inquiry.note?.title}</div>
                </td>
                <td className="whitespace-nowrap px-6 py-4">
                  <div className="flex items-center">
                    <div className="h-8 w-8 flex-shrink-0 overflow-hidden rounded-full bg-gray-200">
                      {counterparty?.profileImageUrl ? (
                        <img src={counterparty.profileImageUrl} alt="" className="h-full w-full object-cover" />
                      ) : (
                        <div className="flex h-full w-full items-center justify-center bg-blue-100 text-blue-600">
                          {counterparty?.firstName?.[0]}
                        </div>
                      )}
                    </div>
                    <div className="ml-3">
                      <div className="text-sm font-medium text-gray-900">
                        {counterparty?.firstName} {counterparty?.lastName}
                      </div>
                      {counterparty?.companyName && (
                        <div className="text-sm text-gray-500">{counterparty.companyName}</div>
                      )}
                    </div>
                  </div>
                </td>
                <td className="whitespace-nowrap px-6 py-4">
                  <span
                    className={`inline-flex rounded-full px-2 text-xs font-semibold leading-5 ${statusColor}`}
                  >
                    {inquiry.status.charAt(0).toUpperCase() + inquiry.status.slice(1)}
                  </span>
                  {inquiry.phoneNumberRequested && (
                    <span className="ml-2 inline-flex rounded-full bg-blue-100 px-2 text-xs font-semibold leading-5 text-blue-800">
                      Phone
                    </span>
                  )}
                </td>
                <td className="whitespace-nowrap px-6 py-4 text-sm text-gray-500">
                  {formatDate(inquiry.createdAt)}
                </td>
                <td className="whitespace-nowrap px-6 py-4 text-right text-sm font-medium">
                  <Link
                    href={`/dashboard/inquiries/${inquiry.id}`}
                    className="text-blue-600 hover:text-blue-900"
                  >
                    View
                  </Link>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
};

export default InquiriesList;
