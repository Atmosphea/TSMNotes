// Re-export the types from the server
export * from '../../server/types';

// Query state for the notes list
export interface NotesQueryState {
  isLoading: boolean;
  isError: boolean;
  error: Error | null;
  data: {
    notes: any[];
    pagination: {
      page: number;
      limit: number;
      totalCount: number;
      totalPages: number;
    }
  } | null;
}

// Filter state for notes search
export interface FilterState {
  availability?: string;
  listingType?: string;
  lienPosition?: string;
  performance?: string;
  noteType?: string;
  seller?: string;
  minPrice?: string;
  maxPrice?: string;
  propertyType?: string;
  minYield?: string;
  maxYield?: string;
  minLtv?: string;
  maxLtv?: string;
  hasForeclosure?: boolean;
  stateType?: string;
  [key: string]: string | boolean | undefined;
}

// Pagination state
export interface PaginationState {
  page: number;
  limit: number;
}

// Sorting state
export interface SortingState {
  sortBy?: string;
  sortDirection?: 'asc' | 'desc';
}

// Filter option format for UI components
export interface FilterOption {
  value: string;
  label: string;
  count?: number;
}

// Note card props
export interface NoteCardProps {
  note: any;
  onClick?: () => void;
}

// Filter sidebar props
export interface FilterSidebarProps {
  filters: FilterState;
  onFilterChange: (filterName: string, value: string | boolean | null) => void;
  filterCounts: {
    noteTypes: { value: string; label: string; count: number }[];
    lienPositions: { value: string; label: string; count: number }[];
    propertyTypes: { value: string; label: string; count: number }[];
    // etc.
  };
  isLoading?: boolean;
}

// Price formatter options
export interface PriceFormatterOptions {
  minimumFractionDigits?: number;
  maximumFractionDigits?: number;
  notation?: 'standard' | 'scientific' | 'engineering' | 'compact';
  compactDisplay?: 'short' | 'long';
}

// Inquiry status
export type InquiryStatus = 'new' | 'viewed' | 'replied' | 'closed';

// Inquiry
export interface Inquiry {
  id: number;
  buyerId: number;
  noteId: number;
  subject: string;
  message: string;
  status: InquiryStatus;
  isRead: boolean;
  phoneNumberRequested: boolean;
  phoneNumberRevealed: boolean;
  createdAt: string;
  updatedAt: string;

  // Relations that may be included when fetching
  buyer?: User;
  note?: Note;
  replies?: InquiryReply[];
}

// Inquiry Reply
export interface InquiryReply {
  id: number;
  inquiryId: number;
  userId: number;
  message: string;
  isRead: boolean;
  createdAt: string;

  // Relations that may be included when fetching
  user?: User;
}

// Update the availability type to include 'on_hold'
export type Availability = 'available' | 'on_hold' | 'pending_sale' | 'sold';

// Add note transaction history type
export interface NoteTransactionHistory {
  id: number;
  noteId: number;
  status: Availability;
  buyerId?: number;
  reason?: string;
  expiresAt?: string;
  createdAt: string;
  createdBy: number;

  // Relations
  buyer?: User;
  creator?: User;
}

// Saved search analytics action types
export type SavedSearchAction = 'view' | 'execute' | 'create_alert' | 'modify' | 'share' | 'export';

// Saved search analytics
export interface SavedSearchAnalytics {
  id: number;
  searchId: number;
  userId: number;
  action: SavedSearchAction;
  countMatches?: number;
  executionTimeMs?: number;
  createdAt: string;
}

// Saved search analytics summary
export interface SavedSearchAnalyticsSummary {
  searchId: number;
  totalUsage: number;
  usageByAction: Record<SavedSearchAction, number>;
  matchRates: {
    avgMatches: number;
    maxMatches: number;
    totalMatches: number;
  };
  usageByDate: Record<string, number>;
  lastUsed: string;
}
