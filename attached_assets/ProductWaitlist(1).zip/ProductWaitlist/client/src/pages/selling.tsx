import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Link } from "wouter";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormMessage, FormLabel, FormDescription } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { toast, useToast } from "@/hooks/use-toast";
import { 
  FileText,
  X,
  ChevronRight,
  Pencil
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { formatCurrency } from "@/lib/utils";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { useLocation } from "wouter";

// Property type options
const propertyTypes = [
  "Single Family",
  "Multi-Family",
  "Condo",
  "Townhouse",
  "Commercial",
  "Land",
  "Other"
];

// Form schema for the note listing
const noteListingFormSchema = z.object({
  sellerId: z.number(),
  loanAmount: z.number().min(1000, "Loan amount must be at least $1,000"),
  interestRate: z.number().min(0.1, "Interest rate must be greater than 0.1%").max(25, "Interest rate must be less than 25%"),
  loanTerm: z.number().min(1, "Loan term must be at least 1 month"),
  paymentAmount: z.number().min(10, "Payment amount must be at least $10"),
  timeHeld: z.number().min(1, "Time held must be at least 1 month"),
  remainingPayments: z.number().min(1, "Remaining payments must be at least 1"),
  propertyAddress: z.string().min(5, "Property address must be at least 5 characters"),
  askingPrice: z.number().min(1000, "Asking price must be at least $1,000"),
  propertyType: z.string().min(1, "Please select a property type"),
  description: z.string().min(20, "Description must be at least 20 characters"),
  status: z.string().default("draft"),
});

type NoteListingFormValues = z.infer<typeof noteListingFormSchema>;

// Interface for user listings
interface NoteListing {
  id: number;
  sellerId: number;
  propertyAddress: string;
  propertyType: string;
  loanAmount: number;
  interestRate: number;
  loanTerm: number;
  paymentAmount: number;
  timeHeld: number;
  remainingPayments: number;
  askingPrice: number;
  description: string;
  status: string;
  createdAt: Date;
}

// NoteCard component for the listings grid
const NoteCard = ({ 
  listing,
  isCondensed = false,
  onDelete,
  onEdit
}: { 
  listing: NoteListing,
  isCondensed?: boolean,
  onDelete?: (id: number) => void,
  onEdit?: (listing: NoteListing) => void
}) => {
  const [showDetails, setShowDetails] = useState(false);
  const { data: documents } = useQuery({
    queryKey: ["documents", listing.id],
    queryFn: async () => {
      const response = await fetch(`/api/note-documents/listing/${listing.id}`);
      return response.json();
    },
    enabled: showDetails
  });

  return (
    <>
      <div 
        className={`relative rounded-lg overflow-hidden cursor-pointer ${isCondensed ? 'aspect-[1.618/1]' : ''}`}
        style={isCondensed && listing.status !== "active" ? { opacity: 0.6 } : {}}
        onClick={() => setShowDetails(true)}
      >
        <Card className={`h-full border border-gray-800 hover:border-white transition-all duration-300 overflow-hidden backdrop-blur-md ${isCondensed ? 'bg-black/40' : 'bg-black/60'}`}>
          {isCondensed && (
            <div className="absolute top-2 right-2 flex gap-2">
              <Badge className={listing.status === "active" ? "bg-green-600" : "bg-gray-600"}>
                {listing.status === "active" ? "Live" : "Draft"}
              </Badge>
              {onEdit && (
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-6 w-6 rounded-full hover:bg-blue-500/20 hover:text-blue-500"
                  onClick={(e) => {
                    e.stopPropagation();
                    onEdit(listing);
                  }}
                >
                  <Pencil className="h-4 w-4" />
                </Button>
              )}
              {onDelete && (
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-6 w-6 rounded-full hover:bg-red-500/20 hover:text-red-500"
                  onClick={(e) => {
                    e.stopPropagation();
                    onDelete(listing.id);
                  }}
                >
                  <X className="h-4 w-4" />
                </Button>
              )}
            </div>
          )}
          
          <CardHeader className="pb-2">
            <CardTitle className={`${isCondensed ? 'text-base' : 'text-xl'} truncate`}>
              {listing.propertyType}
            </CardTitle>
            <p className={`text-gray-400 ${isCondensed ? 'text-xs' : 'text-sm'} truncate`}>
              {listing.propertyAddress}
            </p>
          </CardHeader>
          
          <CardContent className={`space-y-3 ${isCondensed ? 'p-3' : 'p-6'}`}>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <p className={`text-gray-400 ${isCondensed ? 'text-[10px]' : 'text-xs'}`}>Value</p>
                <p className={isCondensed ? 'text-sm font-medium' : 'font-medium'}>
                  {formatCurrency(listing.loanAmount)}
                </p>
              </div>
              <div>
                <p className={`text-gray-400 ${isCondensed ? 'text-[10px]' : 'text-xs'}`}>Rate</p>
                <p className={isCondensed ? 'text-sm font-medium' : 'font-medium'}>
                  {listing.interestRate}%
                </p>
              </div>
            </div>
            
            {!isCondensed && (
              <>
                <div>
                  <p className="text-xs text-gray-400">Monthly Payment</p>
                  <p className="font-medium">{formatCurrency(listing.paymentAmount)}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-400">Remaining Term</p>
                  <p className="font-medium">{listing.remainingPayments} months</p>
                </div>
              </>
            )}
          </CardContent>
        </Card>
      </div>

      <Dialog open={showDetails} onOpenChange={setShowDetails}>
        <DialogContent className="sm:max-w-[800px]">
          <DialogHeader>
            <DialogTitle>{listing.propertyType}</DialogTitle>
            <DialogDescription>{listing.propertyAddress}</DialogDescription>
          </DialogHeader>
          
          <Tabs defaultValue="details">
            <TabsList>
              <TabsTrigger value="details">Details</TabsTrigger>
              <TabsTrigger value="documents">Documents</TabsTrigger>
            </TabsList>
            
            <TabsContent value="details" className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h4 className="text-sm font-medium text-gray-400">Loan Amount</h4>
                  <p className="text-lg font-medium">{formatCurrency(listing.loanAmount)}</p>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-gray-400">Interest Rate</h4>
                  <p className="text-lg font-medium">{listing.interestRate}%</p>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-gray-400">Monthly Payment</h4>
                  <p className="text-lg font-medium">{formatCurrency(listing.paymentAmount)}</p>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-gray-400">Asking Price</h4>
                  <p className="text-lg font-medium">{formatCurrency(listing.askingPrice)}</p>
                </div>
              </div>
              
              <div>
                <h4 className="text-sm font-medium text-gray-400 mb-2">Description</h4>
                <p>{listing.description}</p>
              </div>
            </TabsContent>
            
            <TabsContent value="documents" className="space-y-4">
              {documents?.data?.length === 0 ? (
                <div className="text-center py-8">
                  <FileText className="w-12 h-12 mx-auto text-muted-foreground opacity-50 mb-2" />
                  <p className="text-muted-foreground">No documents available</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {documents?.data?.map((doc: any) => (
                    <div key={doc.id} className="flex items-center justify-between p-3 border rounded">
                      <div className="flex items-center">
                        <FileText className="w-5 h-5 mr-3 text-primary" />
                        <div>
                          <p className="font-medium">{doc.fileName}</p>
                          <p className="text-xs text-muted-foreground">
                            {doc.documentType} • {(doc.fileSize / 1024).toFixed(0)} KB
                          </p>
                        </div>
                      </div>
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={async (e) => {
                          e.preventDefault();
                          try {
                            const response = await fetch(`/api/note-documents/download/${doc.id}`);
                            if (!response.ok) throw new Error('Download failed');
                            
                            const blob = await response.blob();
                            const url = window.URL.createObjectURL(blob);
                            const a = document.createElement('a');
                            a.href = url;
                            a.download = doc.fileName;
                            document.body.appendChild(a);
                            a.click();
                            window.URL.revokeObjectURL(url);
                            document.body.removeChild(a);
                          } catch (error) {
                            toast({
                              title: "Error",
                              description: "Failed to download document",
                              variant: "destructive",
                            });
                          }
                        }}
                      >
                        Download
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </TabsContent>
          </Tabs>
        </DialogContent>
      </Dialog>
    </>
  );
};

const SellingPage = () => {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("listings");
  const [documents, setDocuments] = useState<File[]>([]);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [editingListing, setEditingListing] = useState<NoteListing | null>(null);
  const [, setLocation] = useLocation();
  
  // Get the user from localStorage
  const user = JSON.parse(localStorage.getItem("user") || "{}");

  // Initialize form with default values
  const form = useForm<NoteListingFormValues>({
    resolver: zodResolver(noteListingFormSchema),
    defaultValues: {
      sellerId: Number(user.id), // Explicitly convert to number
      loanAmount: 100000,
      interestRate: 6.5,
      loanTerm: 360,
      paymentAmount: 632.07,
      timeHeld: 24,
      remainingPayments: 336,
      propertyAddress: "",
      askingPrice: 75000,
      propertyType: "Single Family",
      description: "",
      status: "draft",
    },
  });
  
  // First, get the queryClient
  const queryClient = useQueryClient();
  
  // Define the query with proper key
  const { data: userListings } = useQuery({
    queryKey: ["userListings"],
    queryFn: async () => {
      const response = await apiRequest("GET", `/api/note-listings/seller/${user.id}`);
      const data = await response.json();
      return data.data;
    }
  });
  
  // Update mutations with optimistic updates
  const { mutate: createListing } = useMutation({
    mutationFn: async (values: NoteListingFormValues) => {
      const user = JSON.parse(localStorage.getItem("user") || "{}");
      
      // First create the listing
      const response = await apiRequest("POST", "/api/note-listings", values, {
        headers: {
          'Content-Type': 'application/json',
          'user': JSON.stringify(user)
        }
      });
      const listingData = await response.json();
      
      // If there are files to upload, handle them
      if (documents.length > 0) {
        const formData = new FormData();
        
        // Important: append each file individually
        for (const file of documents) {
          formData.append('files', file, file.name); // Include original filename
        }
        formData.append('listingId', listingData.data.id.toString());
        
        // Log the FormData contents
        for (const [key, value] of Array.from(formData.entries())) {
          console.log(`FormData entry - ${key}:`, value);
        }

        const uploadResponse = await fetch('/api/note-documents', {
          method: 'POST',
          body: formData,
          headers: {
            'user': JSON.stringify(user)
          }
        });

        if (!uploadResponse.ok) {
          throw new Error('Failed to upload files');
        }
      }

      return listingData;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['userListings'] });
      setIsCreateDialogOpen(false);
      setDocuments([]); // Clear the documents array
      form.reset();
      toast({
        title: "Success",
        description: "Listing created successfully",
      });
    },
    onError: (error) => {
      console.error('Error:', error);
      toast({
        title: "Error",
        description: "Failed to create listing",
        variant: "destructive",
      });
    }
  });
  
  const { mutate: deleteListing } = useMutation({
    mutationFn: async (id: number) => {
      const response = await apiRequest("DELETE", `/api/note-listings/${id}`);
      return response.json();
    },
    onSuccess: (_, deletedId) => {
      queryClient.setQueryData(["userListings"], (old: NoteListing[] = []) => 
        old.filter(listing => listing.id !== deletedId)
      );
    }
  });
  
  const { mutate: updateListing } = useMutation({
    mutationFn: async (values: NoteListingFormValues & { id: number }) => {
      const response = await apiRequest("PUT", `/api/note-listings/${values.id}`, values);
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.setQueryData(["userListings"], (old: NoteListing[] = []) => 
        old.map(listing => listing.id === data.data.id ? data.data : listing)
      );
      toast({
        title: "Success",
        description: "Listing updated successfully",
      });
      setEditingListing(null); // Close the dialog
      form.reset(); // Reset the form
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to update listing",
        variant: "destructive",
      });
    }
  });
  
  // Add this mutation for file uploads
  const { mutate: uploadDocuments } = useMutation({
    mutationFn: async ({ files, listingId }: { files: File[], listingId: number }) => {
      const formData = new FormData();
      files.forEach(file => formData.append('files', file));
      formData.append('listingId', listingId.toString());
      
      const response = await fetch('/api/note-documents', {
        method: 'POST',
        body: formData,
      });
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Success",
        description: "Documents uploaded successfully",
      });
      // Optionally refresh documents list
      queryClient.invalidateQueries({ queryKey: ['documents'] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to upload documents",
        variant: "destructive",
      });
    }
  });
  
  function onSubmit(values: NoteListingFormValues) {
    createListing(values);
  }
  
  // Update the file input handler
  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (files && files.length > 0) {
      // Store the actual File objects directly from the FileList
      setDocuments(Array.from(files));
      
      toast({
        title: "Files selected",
        description: `${files.length} file(s) ready for upload`,
      });
    }
  };
  
  const calculateMonthlyPayment = (loanAmount: number, interestRate: number, loanTerm: number) => {
    // Monthly interest rate
    const monthlyRate = interestRate / 100 / 12;
    // Calculate monthly payment using the formula: P * r * (1+r)^n / ((1+r)^n - 1)
    const payment = loanAmount * monthlyRate * Math.pow(1 + monthlyRate, loanTerm) / (Math.pow(1 + monthlyRate, loanTerm) - 1);
    return payment;
  };
  
  // Calculate ROI
  const calculateROI = (form: any) => {
    const values = form.getValues();
    const { askingPrice, paymentAmount, remainingPayments } = values;
    
    if (!askingPrice || !paymentAmount || !remainingPayments) return 0;
    
    const totalPayments = paymentAmount * remainingPayments;
    const profit = totalPayments - askingPrice;
    const roi = (profit / askingPrice) * 100;
    
    return roi;
  };
  
  // Watch form values for real-time preview
  const watchAll = form.watch();
  
  // When loan amount, interest rate, or term changes, recalculate payment amount
  const updatePaymentAmount = () => {
    const loanAmount = form.getValues("loanAmount");
    const interestRate = form.getValues("interestRate");
    const loanTerm = form.getValues("loanTerm");
    
    if (loanAmount && interestRate && loanTerm) {
      const payment = calculateMonthlyPayment(loanAmount, interestRate, loanTerm);
      form.setValue("paymentAmount", parseFloat(payment.toFixed(2)));
    }
  };
  
  const handleDelete = (id: number) => {
    deleteListing(id);
  };
  
  const activeListings = userListings && userListings.length > 0 ? userListings : [];
  
  // Custom input style with animated caret
  const customInputClass = `
    w-full 
    bg-transparent 
    border-none 
    focus:ring-0 
    focus:outline-none 
    py-3 
    text-lg 
    placeholder-gray-500
    caret-pink-500
    animate-caret
  `;

  // Add the caret animation to the CSS
  useEffect(() => {
    const style = document.createElement('style');
    style.innerHTML = `
      @keyframes caretBlink {
        0%, 70% { opacity: 1; }
        71%, 100% { opacity: 0; }
      }
      .animate-caret::after {
        content: '';
        position: absolute;
        right: -2px;
        top: 50%;
        transform: translateY(-50%);
        width: 2px;
        height: 24px;
        background: linear-gradient(to bottom, #a855f7, #ec4899);
        animation: caretBlink 1s infinite;
      }
    `;
    document.head.appendChild(style);
    return () => {
      document.head.removeChild(style);
    };
  }, []);

  const handleEdit = (listing: NoteListing) => {
    setEditingListing(listing);
    form.reset(listing); // Reset form with listing data
  };

  const handleUpdate = (values: NoteListingFormValues) => {
    if (editingListing) {
      updateListing({ ...values, id: editingListing.id });
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("user");
    setLocation("/");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-violet-800 to-fuchsia-900 text-white">
      <div className="container mx-auto px-4 py-16">
        <div className="flex justify-end mb-8">
          <Button 
            onClick={handleLogout}
            variant="outline"
            className="text-white border-white/20 hover:bg-white/10"
          >
            Logout
          </Button>
        </div>

        <div className="space-y-12">
          <div className="text-center">
            <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
              Sell Your Mortgage Note
            </h1>
            <p className="text-lg text-gray-200 mt-2 max-w-2xl mx-auto">
              Complete the form below to create your listing and get top dollar for your note
            </p>
          </div>
          
          <Button 
            onClick={() => setIsCreateDialogOpen(true)}
            className="mb-8 bg-gradient-to-r from-purple-500 to-pink-500"
          >
            Create New Listing
          </Button>

          <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
            <DialogContent className="sm:max-w-[800px]">
              <DialogHeader>
                <DialogTitle>Create New Listing</DialogTitle>
                <DialogDescription>
                  Fill out the form below to create a new note listing.
                </DialogDescription>
              </DialogHeader>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="propertyAddress"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Property Address</FormLabel>
                          <FormControl>
                            <Input placeholder="Property Address" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="propertyType"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Property Type</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <SelectTrigger>
                              <SelectValue placeholder="Select property type" />
                            </SelectTrigger>
                            <SelectContent>
                              {propertyTypes.map((type) => (
                                <SelectItem key={type} value={type}>{type}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="loanAmount"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Loan Amount</FormLabel>
                          <FormControl>
                            <Input type="number" {...field} onChange={e => {
                              field.onChange(+e.target.value);
                              setTimeout(updatePaymentAmount, 100);
                            }} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="askingPrice"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Asking Price</FormLabel>
                          <FormControl>
                            <Input type="number" {...field} onChange={e => field.onChange(+e.target.value)} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="interestRate"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Interest Rate (%)</FormLabel>
                          <FormControl>
                            <Input type="number" step="0.125" {...field} onChange={e => {
                              field.onChange(+e.target.value);
                              setTimeout(updatePaymentAmount, 100);
                            }} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="loanTerm"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Loan Term (months)</FormLabel>
                          <FormControl>
                            <Input type="number" {...field} onChange={e => {
                              field.onChange(+e.target.value);
                              setTimeout(updatePaymentAmount, 100);
                            }} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="paymentAmount"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Monthly Payment</FormLabel>
                          <FormControl>
                            <Input type="number" step="0.01" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="timeHeld"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Time Held (months)</FormLabel>
                          <FormControl>
                            <Input type="number" {...field} onChange={e => field.onChange(+e.target.value)} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="remainingPayments"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Remaining Payments</FormLabel>
                          <FormControl>
                            <Input type="number" {...field} onChange={e => field.onChange(+e.target.value)} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="description"
                      render={({ field }) => (
                        <FormItem className="col-span-2">
                          <FormLabel>Description</FormLabel>
                          <FormControl>
                            <Textarea placeholder="Note Description" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      name="documents"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Upload Documents</FormLabel>
                          <FormControl>
                            <Input
                              type="file"
                              multiple
                              accept=".pdf,.doc,.docx"
                              onChange={handleFileUpload}
                            />
                          </FormControl>
                          <FormDescription>
                            Upload up to 5 documents (PDF, DOC, DOCX)
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  <DialogFooter>
                    <Button variant="outline" type="button" onClick={() => setIsCreateDialogOpen(false)}>
                      Cancel
                    </Button>
                    <Button type="submit">Create Listing</Button>
                  </DialogFooter>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
          
          <div className="py-10 border-t border-purple-500/20">
            <h2 className="text-3xl font-bold mb-8 bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
              Your Note Listings
            </h2>
            
            <Tabs defaultValue="listings" className="w-full">
              <TabsList className="grid grid-cols-3 max-w-md mb-8">
                <TabsTrigger 
                  value="listings" 
                  className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-500 data-[state=active]:to-pink-500 data-[state=active]:text-white"
                >
                  Your Listings
                </TabsTrigger>
                <TabsTrigger 
                  value="market" 
                  className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-500 data-[state=active]:to-pink-500 data-[state=active]:text-white"
                >
                  Market
                </TabsTrigger>
                <TabsTrigger 
                  value="sold" 
                  className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-500 data-[state=active]:to-pink-500 data-[state=active]:text-white"
                >
                  Sold
                </TabsTrigger>
              </TabsList>
              
              <TabsContent value="listings" className="mt-0">
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
                  {userListings && userListings
                    .filter((listing: NoteListing) => listing.status === "active")
                    .map((listing: NoteListing) => (
                      <NoteCard 
                        key={listing.id} 
                        listing={listing} 
                        isCondensed={true}
                        onDelete={handleDelete}
                        onEdit={handleEdit}
                      />
                  ))}
                </div>
              </TabsContent>
              
              <TabsContent value="market" className="mt-0">
                <div className="text-center py-6">
                  <p className="text-gray-400">Explore the marketplace to see what other notes are available</p>
                  <Button 
                    className="mt-4 bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 border-none"
                    asChild
                  >
                    <Link href="/marketplace">
                      Browse Marketplace <ChevronRight className="ml-1 h-4 w-4" />
                    </Link>
                  </Button>
                </div>
              </TabsContent>
              
              <TabsContent value="sold" className="mt-0">
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
                  {userListings && userListings
                    .filter((listing: NoteListing) => listing.status === "sold")
                    .map((listing: NoteListing) => (
                      <NoteCard key={listing.id} listing={listing} isCondensed={true} onDelete={(id) => {
                        // Implement the delete logic here
                      }} />
                  ))}
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>

      {editingListing && (
        <Dialog open={!!editingListing} onOpenChange={() => setEditingListing(null)}>
          <DialogContent className="sm:max-w-[800px]">
            <DialogHeader>
              <DialogTitle>Edit Listing</DialogTitle>
              <DialogDescription>
                Make changes to your listing here. Click save when you're done.
              </DialogDescription>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(handleUpdate)} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="propertyAddress"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Property Address</FormLabel>
                        <FormControl>
                          <Input placeholder="Property Address" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="propertyType"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Property Type</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select property type" />
                          </SelectTrigger>
                          <SelectContent>
                            {propertyTypes.map((type) => (
                              <SelectItem key={type} value={type}>{type}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="loanAmount"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Loan Amount</FormLabel>
                        <FormControl>
                          <Input type="number" {...field} onChange={e => {
                            field.onChange(+e.target.value);
                            setTimeout(updatePaymentAmount, 100);
                          }} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="askingPrice"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Asking Price</FormLabel>
                        <FormControl>
                          <Input type="number" {...field} onChange={e => field.onChange(+e.target.value)} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="interestRate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Interest Rate (%)</FormLabel>
                        <FormControl>
                          <Input type="number" step="0.125" {...field} onChange={e => {
                            field.onChange(+e.target.value);
                            setTimeout(updatePaymentAmount, 100);
                          }} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="loanTerm"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Loan Term (months)</FormLabel>
                        <FormControl>
                          <Input type="number" {...field} onChange={e => {
                            field.onChange(+e.target.value);
                            setTimeout(updatePaymentAmount, 100);
                          }} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="paymentAmount"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Monthly Payment</FormLabel>
                        <FormControl>
                          <Input type="number" step="0.01" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="timeHeld"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Time Held (months)</FormLabel>
                        <FormControl>
                          <Input type="number" {...field} onChange={e => field.onChange(+e.target.value)} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="remainingPayments"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Remaining Payments</FormLabel>
                        <FormControl>
                          <Input type="number" {...field} onChange={e => field.onChange(+e.target.value)} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem className="col-span-2">
                        <FormLabel>Description</FormLabel>
                        <FormControl>
                          <Textarea placeholder="Note Description" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    name="documents"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Upload Additional Documents</FormLabel>
                        <FormControl>
                          <Input
                            type="file"
                            multiple
                            accept=".pdf,.doc,.docx"
                            onChange={async (e) => {
                              const files = Array.from(e.target.files || []);
                              if (files.length > 0 && editingListing) {
                                const formData = new FormData();
                                files.forEach(file => formData.append('files', file));
                                formData.append('listingId', editingListing.id.toString());

                                try {
                                  const response = await fetch('/api/note-documents', {
                                    method: 'POST',
                                    body: formData,
                                    headers: {
                                      'user': JSON.stringify(user)
                                    }
                                  });

                                  if (!response.ok) throw new Error('Upload failed');

                                  toast({
                                    title: "Success",
                                    description: "Documents uploaded successfully",
                                  });
                                  
                                  // Refresh documents list
                                  queryClient.invalidateQueries({ queryKey: ['documents'] });
                                } catch (error) {
                                  toast({
                                    title: "Error",
                                    description: "Failed to upload documents",
                                    variant: "destructive",
                                  });
                                }
                              }
                            }}
                          />
                        </FormControl>
                        <FormDescription>
                          Upload additional documents (PDF, DOC, DOCX)
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <DialogFooter>
                  <Button variant="outline" type="button" onClick={() => setEditingListing(null)}>
                    Cancel
                  </Button>
                  <Button type="submit">Save Changes</Button>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
};

export default SellingPage;