import { Route, Switch, useLocation } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import LoginPage from "./pages/login";
import RegisterPage from "./pages/register";
import SellingPage from "./pages/selling";
import MarketplacePage from "./pages/marketplace";
import NoteDetailPage from "./pages/note-detail";
import LandingPage from "./pages/landing";
import { Toaster } from "./components/ui/toaster";

// Create a client
const queryClient = new QueryClient();

export default function App() {
  const [location] = useLocation();

  // Only check auth for protected routes
  const isAuthenticated = !!localStorage.getItem("user");
  const isAuthPage = location === "/login" || location === "/register";
  const isProtectedRoute = location === "/selling" || location.startsWith("/note/");

  // Redirect to login only for protected routes
  if (!isAuthenticated && isProtectedRoute) {
    return <LoginPage />;
  }

  return (
    <QueryClientProvider client={queryClient}>
      <Switch>
        <Route path="/" component={LandingPage} />
        <Route path="/marketplace" component={MarketplacePage} />
        <Route path="/login" component={LoginPage} />
        <Route path="/register" component={RegisterPage} />
        <Route path="/selling" component={SellingPage} />
        <Route path="/note/:id" component={NoteDetailPage} />
      </Switch>
      <Toaster />
    </QueryClientProvider>
  );
}
