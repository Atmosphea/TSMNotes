import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertWaitlistEntrySchema, 
  insertNoteListingSchema, 
  insertNoteDocumentSchema,
  insertUserSchema 
} from "@shared/schema";
import { z } from "zod";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";
import bcrypt from "bcrypt";
import multer from "multer";
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { dirname } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Create uploads directory if it doesn't exist
const uploadsDir = path.join(__dirname, '../uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

// Configure multer storage
const uploadStorage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, uploadsDir)
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({ 
  storage: uploadStorage,
  limits: {
    fileSize: 50 * 1024 * 1024 // 50MB limit
  },
  fileFilter: (req: Express.Request, file: Express.Multer.File, cb: multer.FileFilterCallback) => {
    const allowedTypes = ['.pdf', '.doc', '.docx'];
    const ext = path.extname(file.originalname).toLowerCase();
    if (allowedTypes.includes(ext)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type. Only PDF, DOC, and DOCX files are allowed.'));
    }
  }
});

// Function to add sample note listings
async function addSampleListings() {
  const listings = await storage.getAllNoteListings();
  
  // Only add sample data if there are no listings yet
  if (listings.length === 0) {
    // Create a sample user first
    // Using type assertion to work around schema constraints for sample data
    const sampleUser = await storage.createUser({
      username: "sample_investor",
      email: "investor@notetrade.com",
      password: await bcrypt.hash("password123", 10),
      firstName: "Jane",
      lastName: "Smith",
      company: "Investment Partners LLC",
      phone: "555-123-4567",
      role: "seller"
    } as any);
    
    // Create some sample note listings with type assertion
    await storage.createNoteListing({
      sellerId: sampleUser.id,
      loanAmount: 150000,
      interestRate: 7.25,
      loanTerm: 360,
      paymentAmount: 1023.12,
      timeHeld: 18,
      remainingPayments: 342,
      propertyType: "Single Family",
      propertyAddress: "123 Oak Lane, Austin, TX 78701",
      askingPrice: 125000,
      status: "active",
      description: "Well-performing note with a strong payment history. Property is in an excellent neighborhood with rising property values."
    } as any);
    
    await storage.createNoteListing({
      sellerId: sampleUser.id,
      loanAmount: 85000,
      interestRate: 6.5,
      loanTerm: 240,
      paymentAmount: 635.75,
      timeHeld: 24,
      remainingPayments: 216,
      propertyType: "Condo",
      propertyAddress: "456 Pine Street #302, Seattle, WA 98101",
      askingPrice: 70000,
      status: "active",
      description: "Seasoned note backed by a renovated condo in downtown Seattle. Borrower has excellent credit and perfect payment history."
    } as any);
    
    await storage.createNoteListing({
      sellerId: sampleUser.id,
      loanAmount: 225000,
      interestRate: 8.1,
      loanTerm: 300,
      paymentAmount: 1560.42,
      timeHeld: 36,
      remainingPayments: 264,
      propertyType: "Multi-Family",
      propertyAddress: "789 Maple Ave, Chicago, IL 60611",
      askingPrice: 195000,
      status: "active",
      description: "High-yield note secured by a well-maintained duplex in a rapidly appreciating area of Chicago. Strong rental income supports payments."
    } as any);
    
    // Add sample document for the first listing with type assertion
    await storage.createNoteDocument({
      noteListingId: 1,
      fileName: "Loan_Agreement.pdf",
      fileSize: 2048,
      documentType: "Loan Agreement",
      documentUrl: "https://example.com/docs/loan_agreement.pdf",
      uploadedById: sampleUser.id
    } as any);
    
    await storage.createNoteDocument({
      noteListingId: 1,
      fileName: "Property_Appraisal.pdf",
      fileSize: 4096,
      documentType: "Appraisal",
      documentUrl: "https://example.com/docs/appraisal.pdf",
      uploadedById: sampleUser.id
    } as any);
  }
}

const emailSchema = z.string().email("Please enter a valid email address");

export async function registerRoutes(app: Express): Promise<Server> {
  // Add sample listings on startup
  await addSampleListings();
  // Waitlist API route
  app.post("/api/waitlist", async (req, res) => {
    try {
      const data = insertWaitlistEntrySchema.parse(req.body);
      
      // Check if email already exists in waitlist
      const existingEntry = await storage.getWaitlistEntryByEmail(data.email);
      if (existingEntry) {
        return res.status(409).json({ 
          success: false, 
          message: "This email is already on our waitlist." 
        });
      }
      
      const waitlistEntry = await storage.createWaitlistEntry(data);
      
      return res.status(201).json({ 
        success: true, 
        message: "Successfully added to waitlist", 
        data: { 
          email: waitlistEntry.email,
          role: waitlistEntry.role
        } 
      });
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ 
          success: false, 
          message: validationError.message 
        });
      }
      
      console.error("Error adding to waitlist:", error);
      return res.status(500).json({ 
        success: false, 
        message: "An error occurred while joining the waitlist. Please try again." 
      });
    }
  });

  // Validate email route (used for client-side validation)
  app.post("/api/validate-email", (req, res) => {
    try {
      const { email } = req.body;
      emailSchema.parse(email);
      return res.status(200).json({ 
        valid: true 
      });
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ 
          valid: false, 
          message: "Please enter a valid email address" 
        });
      }
      return res.status(500).json({ 
        valid: false, 
        message: "An error occurred during validation" 
      });
    }
  });

  // Get waitlist count
  app.get("/api/waitlist/count", async (req, res) => {
    try {
      const entries = await storage.getAllWaitlistEntries();
      return res.status(200).json({ 
        count: entries.length 
      });
    } catch (error) {
      console.error("Error getting waitlist count:", error);
      return res.status(500).json({ 
        message: "An error occurred while getting waitlist count" 
      });
    }
  });
  
  // Note Listing API Routes
  
  // Get all note listings
  app.get("/api/note-listings", async (req, res) => {
    try {
      const listings = await storage.getAllNoteListings();
      return res.status(200).json({ 
        success: true, 
        data: listings 
      });
    } catch (error) {
      console.error("Error getting note listings:", error);
      return res.status(500).json({ 
        success: false, 
        message: "An error occurred while fetching note listings" 
      });
    }
  });
  
  // Get note listing by ID
  app.get("/api/note-listings/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ 
          success: false, 
          message: "Invalid note listing ID" 
        });
      }
      
      const listing = await storage.getNoteListingById(id);
      if (!listing) {
        return res.status(404).json({ 
          success: false, 
          message: "Note listing not found" 
        });
      }
      
      return res.status(200).json({ 
        success: true, 
        data: listing 
      });
    } catch (error) {
      console.error("Error getting note listing:", error);
      return res.status(500).json({ 
        success: false, 
        message: "An error occurred while fetching the note listing" 
      });
    }
  });
  
  // Get note listings by seller ID
  app.get("/api/note-listings/seller/:sellerId", async (req, res) => {
    try {
      const sellerId = parseInt(req.params.sellerId);
      if (isNaN(sellerId)) {
        return res.status(400).json({ 
          success: false, 
          message: "Invalid seller ID" 
        });
      }
      
      const listings = await storage.getNoteListingsBySellerId(sellerId);
      return res.status(200).json({ 
        success: true, 
        data: listings 
      });
    } catch (error) {
      console.error("Error getting seller's note listings:", error);
      return res.status(500).json({ 
        success: false, 
        message: "An error occurred while fetching seller's note listings" 
      });
    }
  });
  
  // Create a new note listing
  app.post("/api/note-listings", async (req, res) => {
    // Force immediate console output
    process.stdout.write('\n=== POST /api/note-listings ===\n');
    process.stdout.write(`Headers: ${JSON.stringify(req.headers, null, 2)}\n`);
    process.stdout.write(`Body: ${JSON.stringify(req.body, null, 2)}\n`);

    try {
      const data = insertNoteListingSchema.parse(req.body);
      const user = JSON.parse(req.headers['user'] as string || '{}');
      
      process.stdout.write(`Parsed data: ${JSON.stringify(data, null, 2)}\n`);
      process.stdout.write(`Parsed user: ${JSON.stringify(user, null, 2)}\n`);
      process.stdout.write(`Types: ${JSON.stringify({
        sellerIdType: typeof data.sellerId,
        userIdType: typeof user.id,
        sellerId: data.sellerId,
        userId: user.id
      }, null, 2)}\n`);

      if (Number(data.sellerId) !== Number(user.id)) {
        // Log the mismatch
        process.stdout.write(`ID MISMATCH: sellerId=${data.sellerId}, userId=${user.id}\n`);
        return res.status(403).json({
          success: false,
          message: "Unauthorized: Can only create listings for yourself"
        });
      }
      
      const listing = await storage.createNoteListing(data);
      return res.status(201).json({ 
        success: true, 
        message: "Note listing created successfully", 
        data: listing 
      });
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ 
          success: false, 
          message: validationError.message 
        });
      }
      
      console.error("Error creating note listing:", error);
      return res.status(500).json({ 
        success: false, 
        message: "An error occurred while creating the note listing" 
      });
    }
  });
  
  // Update a note listing
  app.put("/api/note-listings/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ 
          success: false, 
          message: "Invalid listing ID" 
        });
      }

      // Get the existing listing to verify ownership
      const existingListing = await storage.getNoteListingById(id);
      if (!existingListing) {
        return res.status(404).json({
          success: false,
          message: "Listing not found"
        });
      }

      // Verify the user owns this listing
      const user = JSON.parse(req.headers['user'] as string || '{}');
      if (existingListing.sellerId !== user.id) {
        return res.status(403).json({
          success: false,
          message: "Unauthorized: Can only update your own listings"
        });
      }

      // Update the listing
      const updatedListing = await storage.updateNoteListing(id, req.body);
      
      return res.status(200).json({
        success: true,
        message: "Listing updated successfully",
        data: updatedListing
      });
    } catch (error) {
      console.error("Error updating note listing:", error);
      return res.status(500).json({
        success: false,
        message: "An error occurred while updating the listing"
      });
    }
  });
  
  // Delete a note listing
  app.delete("/api/note-listings/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ 
          success: false, 
          message: "Invalid note listing ID" 
        });
      }
      
      const deleted = await storage.deleteNoteListing(id);
      if (!deleted) {
        return res.status(404).json({ 
          success: false, 
          message: "Note listing not found" 
        });
      }
      
      return res.status(200).json({ 
        success: true, 
        message: "Note listing deleted successfully" 
      });
    } catch (error) {
      console.error("Error deleting note listing:", error);
      return res.status(500).json({ 
        success: false, 
        message: "An error occurred while deleting the note listing" 
      });
    }
  });
  
  // Document API Routes
  
  // Get documents for a listing
  app.get("/api/note-documents/listing/:id", async (req: Request, res) => {
    try {
      const documents = await storage.getNoteDocuments(parseInt(req.params.id));
      return res.json({
        success: true,
        data: documents
      });
    } catch (error) {
      console.error("Error fetching documents:", error);
      return res.status(500).json({
        success: false,
        message: "Failed to fetch documents"
      });
    }
  });
  
  // Create a new document
  app.post("/api/note-documents", upload.array('files', 5), async (req: Request & { files?: Express.Multer.File[] }, res) => {
    try {
      console.log("Upload request received");
      console.log("Files:", req.files);
      console.log("Body:", req.body);
      console.log("Upload directory:", uploadsDir);

      if (!req.files || req.files.length === 0) {
        return res.status(400).json({
          success: false,
          message: "No files uploaded"
        });
      }

      const uploadedDocs = await Promise.all(req.files.map(file => {
        console.log("Processing file:", file);
        return storage.createNoteDocument({
          noteListingId: parseInt(req.body.listingId),
          fileName: file.filename,
          fileSize: file.size,
          documentType: req.body.documentType || "Loan Agreement",
          documentUrl: file.path,
          uploadedById: JSON.parse(req.headers['user'] as string || '{}').id
        });
      }));

      return res.status(201).json({
        success: true,
        data: uploadedDocs
      });
    } catch (error) {
      console.error("Error uploading files:", error);
      return res.status(500).json({
        success: false,
        message: "Failed to upload files"
      });
    }
  });
  
  // Delete a document
  app.delete("/api/note-documents/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ 
          success: false, 
          message: "Invalid document ID" 
        });
      }
      
      const deleted = await storage.deleteNoteDocument(id);
      if (!deleted) {
        return res.status(404).json({ 
          success: false, 
          message: "Document not found" 
        });
      }
      
      return res.status(200).json({ 
        success: true, 
        message: "Document deleted successfully" 
      });
    } catch (error) {
      console.error("Error deleting document:", error);
      return res.status(500).json({ 
        success: false, 
        message: "An error occurred while deleting the document" 
      });
    }
  });
  
  // Download a document
  app.get("/api/note-documents/download/:id", async (req: Request, res) => {
    try {
      const doc = await storage.getNoteDocument(parseInt(req.params.id));
      if (!doc) {
        return res.status(404).json({
          success: false,
          message: "Document not found"
        });
      }

      console.log("Document path:", doc.documentUrl);
      console.log("Document exists:", fs.existsSync(doc.documentUrl));

      // Check if file exists
      if (!fs.existsSync(doc.documentUrl)) {
        return res.status(404).json({
          success: false,
          message: "File not found on server"
        });
      }

      // Get the file extension and set the correct content type
      const ext = path.extname(doc.fileName).toLowerCase();
      let contentType = 'application/octet-stream';
      
      switch (ext) {
        case '.pdf':
          contentType = 'application/pdf';
          break;
        case '.doc':
          contentType = 'application/msword';
          break;
        case '.docx':
          contentType = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';
          break;
      }

      // Set appropriate headers
      res.setHeader('Content-Type', contentType);
      res.setHeader('Content-Disposition', `attachment; filename="${doc.fileName}"`);

      // Send the file directly
      res.sendFile(doc.documentUrl, { root: '/' });

    } catch (error) {
      console.error("Error downloading document:", error);
      return res.status(500).json({
        success: false,
        message: "Failed to download document"
      });
    }
  });
  
  // User API Routes
  
  // Get user by ID
  app.get("/api/users/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ 
          success: false, 
          message: "Invalid user ID" 
        });
      }
      
      const user = await storage.getUser(id);
      if (!user) {
        return res.status(404).json({ 
          success: false, 
          message: "User not found" 
        });
      }
      
      // Don't return password hash or other sensitive information
      const { password, ...safeUser } = user;
      
      return res.status(200).json({ 
        success: true, 
        data: safeUser
      });
    } catch (error) {
      console.error("Error getting user:", error);
      return res.status(500).json({ 
        success: false, 
        message: "An error occurred while fetching the user" 
      });
    }
  });

  // Login route
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      const user = await storage.getUserByUsername(username);
      
      if (!user) {
        return res.status(401).json({ 
          success: false, 
          message: "Invalid credentials" 
        });
      }

      const isValid = await bcrypt.compare(password, user.password);
      if (!isValid) {
        return res.status(401).json({ 
          success: false, 
          message: "Invalid credentials" 
        });
      }

      const { password: _, ...safeUser } = user;
      return res.status(200).json({ 
        success: true, 
        data: safeUser 
      });
    } catch (error) {
      console.error("Login error:", error);
      return res.status(500).json({ 
        success: false, 
        message: "An error occurred during login" 
      });
    }
  });

  // Register route
  app.post("/api/auth/register", async (req, res) => {
    try {
      const data = insertUserSchema.parse(req.body);
      const hashedPassword = await bcrypt.hash(data.password, 10);
      
      const user = await storage.createUser({
        ...data,
        password: hashedPassword
      });

      const { password: _, ...safeUser } = user;
      return res.status(201).json({ 
        success: true, 
        data: safeUser 
      });
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ 
          success: false, 
          message: fromZodError(error).message 
        });
      }
      
      console.error("Registration error:", error);
      return res.status(500).json({ 
        success: false, 
        message: "An error occurred during registration" 
      });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
