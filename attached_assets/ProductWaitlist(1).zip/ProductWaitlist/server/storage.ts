import { 
  users, 
  waitlistEntries, 
  messages, 
  notes,
  noteListings,
  noteDocuments,
  type User, 
  type InsertUser, 
  type WaitlistEntry, 
  type InsertWaitlistEntry,
  type Message,
  type InsertMessage,
  type Note,
  type InsertNote,
  type NoteListing,
  type InsertNoteListing,
  type NoteDocument,
  type InsertNoteDocument
} from "@shared/schema";
import { eq, desc } from "drizzle-orm";
import { db, DbStorage } from './db';

// modify the interface with any CRUD methods
// you might need

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<InsertUser>): Promise<User | undefined>;
  
  // Waitlist operations
  createWaitlistEntry(entry: InsertWaitlistEntry): Promise<WaitlistEntry>;
  getWaitlistEntryByEmail(email: string): Promise<WaitlistEntry | undefined>;
  getAllWaitlistEntries(): Promise<WaitlistEntry[]>;
  
  // Message operations
  createMessage(message: InsertMessage): Promise<Message>;
  getMessagesByUserId(userId: number): Promise<Message[]>;
  
  // Note Listing operations
  createNoteListing(listing: InsertNoteListing): Promise<NoteListing>;
  getNoteListingById(id: number): Promise<NoteListing | undefined>;
  getNoteListingsBySellerId(sellerId: number): Promise<NoteListing[]>;
  getAllNoteListings(): Promise<NoteListing[]>;
  updateNoteListing(id: number, listing: Partial<InsertNoteListing>): Promise<NoteListing | undefined>;
  deleteNoteListing(id: number): Promise<boolean>;
  
  // Note Document operations
  createNoteDocument(document: InsertNoteDocument): Promise<NoteDocument>;
  getNoteDocumentsByListingId(noteListingId: number): Promise<NoteDocument[]>;
  getNoteDocuments(listingId: number): Promise<NoteDocument[]>;
  getNoteDocument(id: number): Promise<NoteDocument | undefined>;
  deleteNoteDocument(id: number): Promise<boolean>;
  
  // Legacy Note operations
  createNote(note: InsertNote): Promise<Note>;
  getNoteById(id: number): Promise<Note | undefined>;
  getNotesByUserId(userId: number): Promise<Note[]>;
  getAllNotes(): Promise<Note[]>;
  updateNote(id: number, note: Partial<InsertNote>): Promise<Note | undefined>;
  deleteNote(id: number): Promise<boolean>;
}

export const storage = new DbStorage();
