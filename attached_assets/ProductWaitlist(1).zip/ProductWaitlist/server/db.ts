import { drizzle } from 'drizzle-orm/node-postgres';
import pg from 'pg';
const { Pool } = pg;
import { IStorage } from './storage';
import { 
  users, 
  waitlistEntries, 
  messages, 
  notes,
  noteListings,
  noteDocuments,
  type User, 
  type InsertUser, 
  type WaitlistEntry, 
  type InsertWaitlistEntry,
  type Message,
  type InsertMessage,
  type Note,
  type InsertNote,
  type NoteListing,
  type InsertNoteListing,
  type NoteDocument,
  type InsertNoteDocument
} from '@shared/schema';
import { eq, desc } from 'drizzle-orm';

// Create a PostgreSQL connection pool
const pool = new Pool({
  user: 'postgres',
  password: '123456',
  host: 'localhost',
  port: 5432,
  database: 'notetrade'
});

// Create and export the Drizzle instance
export const db = drizzle(pool);

export class DbStorage implements IStorage {
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async createUser(user: InsertUser): Promise<User> {
    const [newUser] = await db.insert(users).values({
      ...user,
      createdAt: new Date()
    }).returning();
    return newUser;
  }

  async updateUser(id: number, user: Partial<InsertUser>): Promise<User | undefined> {
    const [updatedUser] = await db.update(users)
      .set(user)
      .where(eq(users.id, id))
      .returning();
    return updatedUser;
  }

  // Waitlist operations
  async createWaitlistEntry(entry: InsertWaitlistEntry): Promise<WaitlistEntry> {
    const [newEntry] = await db.insert(waitlistEntries)
      .values({
        ...entry,
        createdAt: new Date()
      })
      .returning();
    return newEntry;
  }

  async getWaitlistEntryByEmail(email: string): Promise<WaitlistEntry | undefined> {
    const [entry] = await db.select()
      .from(waitlistEntries)
      .where(eq(waitlistEntries.email, email));
    return entry;
  }

  async getAllWaitlistEntries(): Promise<WaitlistEntry[]> {
    return await db.select().from(waitlistEntries);
  }

  // Message operations
  async createMessage(message: InsertMessage): Promise<Message> {
    const [newMessage] = await db.insert(messages)
      .values({
        ...message,
        read: false,
        createdAt: new Date()
      })
      .returning();
    return newMessage;
  }

  async getMessagesByUserId(userId: number): Promise<Message[]> {
    return await db.select()
      .from(messages)
      .where(
        eq(messages.senderId, userId) || 
        eq(messages.receiverId, userId)
      );
  }

  // Note Listing operations
  async createNoteListing(listing: InsertNoteListing): Promise<NoteListing> {
    const [newListing] = await db.insert(noteListings)
      .values({
        ...listing,
        status: 'active',
        createdAt: new Date(),
        updatedAt: new Date()
      })
      .returning();
    return newListing;
  }

  async getNoteListingById(id: number): Promise<NoteListing | undefined> {
    const [listing] = await db.select()
      .from(noteListings)
      .where(eq(noteListings.id, id));
    return listing;
  }

  async getNoteListingsBySellerId(sellerId: number): Promise<NoteListing[]> {
    return await db.select()
      .from(noteListings)
      .where(eq(noteListings.sellerId, sellerId));
  }

  async getAllNoteListings(): Promise<NoteListing[]> {
    return await db.select()
      .from(noteListings)
      .orderBy(desc(noteListings.createdAt));
  }

  async updateNoteListing(id: number, listing: Partial<InsertNoteListing>): Promise<NoteListing | undefined> {
    const [updatedListing] = await db.update(noteListings)
      .set({
        ...listing,
        updatedAt: new Date()
      })
      .where(eq(noteListings.id, id))
      .returning();
    return updatedListing;
  }

  async deleteNoteListing(id: number): Promise<boolean> {
    const [deleted] = await db.delete(noteListings)
      .where(eq(noteListings.id, id))
      .returning();
    return !!deleted;
  }

  // Note Document operations
  async createNoteDocument(document: InsertNoteDocument): Promise<NoteDocument> {
    const [newDocument] = await db.insert(noteDocuments)
      .values({
        ...document,
        uploadedAt: new Date()
      })
      .returning();
    return newDocument;
  }

  async getNoteDocumentsByListingId(noteListingId: number): Promise<NoteDocument[]> {
    return await db.select()
      .from(noteDocuments)
      .where(eq(noteDocuments.noteListingId, noteListingId));
  }

  async deleteNoteDocument(id: number): Promise<boolean> {
    const [deleted] = await db.delete(noteDocuments)
      .where(eq(noteDocuments.id, id))
      .returning();
    return !!deleted;
  }

  // Legacy Note operations
  async createNote(note: InsertNote): Promise<Note> {
    const [newNote] = await db.insert(notes)
      .values({
        ...note,
        active: true,
        createdAt: new Date()
      })
      .returning();
    return newNote;
  }

  async getNoteById(id: number): Promise<Note | undefined> {
    const [note] = await db.select()
      .from(notes)
      .where(eq(notes.id, id));
    return note;
  }

  async getNotesByUserId(userId: number): Promise<Note[]> {
    return await db.select()
      .from(notes)
      .where(eq(notes.userId, userId));
  }

  async getAllNotes(): Promise<Note[]> {
    return await db.select().from(notes);
  }

  async updateNote(id: number, note: Partial<InsertNote>): Promise<Note | undefined> {
    const [updatedNote] = await db.update(notes)
      .set(note)
      .where(eq(notes.id, id))
      .returning();
    return updatedNote;
  }

  async deleteNote(id: number): Promise<boolean> {
    const [deleted] = await db.delete(notes)
      .where(eq(notes.id, id))
      .returning();
    return !!deleted;
  }

  async getNoteDocuments(listingId: number): Promise<NoteDocument[]> {
    return await db
      .select()
      .from(noteDocuments)
      .where(eq(noteDocuments.noteListingId, listingId));
  }

  async getNoteDocument(id: number): Promise<NoteDocument | undefined> {
    const [doc] = await db
      .select()
      .from(noteDocuments)
      .where(eq(noteDocuments.id, id));
    return doc;
  }
}